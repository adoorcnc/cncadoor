import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { useAuth } from '../context/AuthContext';
import { ProductItem } from '../types';
import { 
  Package, 
  CheckCircle2, 
  Clock, 
  MessageSquare, 
  Heart, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  MapPin, 
  Maximize2,
  X,
  Layers,
  Ruler
} from 'lucide-react';

interface ReadyMadeProductsProps {
  onOrderProduct: (product: ProductItem) => void;
  onRequestCustomization: (productTitle: string) => void;
}

export const ReadyMadeProducts: React.FC<ReadyMadeProductsProps> = ({
  onOrderProduct,
  onRequestCustomization
}) => {
  const { readyMadeProducts, businessConfig } = useStore();
  const { toggleSaveItem, isItemSaved } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedProductForModal, setSelectedProductForModal] = useState<ProductItem | null>(null);
  const [activeImageIndex, setActiveImageIndex] = useState<number>(0);

  const categories = ['All', 'Ready-made Doors', 'Pooja Mandapams', 'Carved Wall Panels'];

  const filteredProducts = selectedCategory === 'All' 
    ? readyMadeProducts 
    : readyMadeProducts.filter(p => p.category.toLowerCase().includes(selectedCategory.toLowerCase()) || p.name.toLowerCase().includes(selectedCategory.toLowerCase()));

  const handleWhatsAppOrder = (product: ProductItem) => {
    const text = `*Order Inquiry for Ready-Made Product - CNCADOOR*\n\n` +
      `*Product:* ${product.name}\n` +
      `*Price:* ${product.price || 'Direct Workshop Rate'}\n` +
      `*Wood:* ${product.woodType}\n` +
      `*Size:* ${product.dimensionsNote}\n` +
      `*Availability:* ${product.leadTime || 'In Stock'}\n\n` +
      `Hello, I would like to purchase / verify stock for this ready-made item. I understand customer pickup is required directly from your Adoor workshop (no delivery). Please share workshop pickup timing and payment details.`;

    const phone = businessConfig.whatsapps[0] || '8301851820';
    window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <section id="ready-made-section" className="py-20 bg-[#FAF7F2] text-[#231812] relative border-b border-[#E8E1D5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-[#E2D9C8] text-[#A8763E] text-xs uppercase tracking-widest font-bold mb-4 shadow-sm">
            <Package className="w-4 h-4 text-[#A8763E]" />
            <span>Ready-for-Pickup Inventory</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-normal text-[#231812] tracking-tight">
            Ready-Made Products
          </h2>
          <div className="w-16 h-0.5 bg-[#A8763E] mx-auto mt-4 mb-4" />
          <p className="text-base sm:text-lg text-[#57473B] font-light leading-relaxed">
            Crafted, kiln-seasoned, and hand-finished in our Kerala workshop. Available for direct customer inspection and pickup at our Adoor workshop.
          </p>

          {/* Customer Self-Pickup Notice */}
          <div className="mt-6 bg-[#FFF9F2] border border-[#F3DFC1] rounded-xl p-3.5 text-xs text-[#8D5F2D] flex items-center justify-center gap-2 max-w-2xl mx-auto shadow-xs">
            <MapPin className="w-4 h-4 text-[#A8763E] flex-shrink-0" />
            <span><strong>Customer Pickup Only:</strong> We do not provide delivery service. Customers collect orders directly from our Adoor workshop (loading assistance provided).</span>
          </div>

          {/* Quick Perks Pill Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6 text-xs text-[#57473B]">
            <div className="bg-white border border-[#E8E1D5] rounded-xl p-3 flex items-center justify-center gap-2 shadow-sm">
              <MapPin className="w-4 h-4 text-[#A8763E]" />
              <span className="font-semibold text-[#231812]">Direct Workshop Pickup (Adoor)</span>
            </div>
            <div className="bg-white border border-[#E8E1D5] rounded-xl p-3 flex items-center justify-center gap-2 shadow-sm">
              <ShieldCheck className="w-4 h-4 text-[#A8763E]" />
              <span className="font-semibold text-[#231812]">100% Solid Seasoned Teak</span>
            </div>
            <div className="bg-white border border-[#E8E1D5] rounded-xl p-3 flex items-center justify-center gap-2 shadow-sm">
              <Sparkles className="w-4 h-4 text-[#A8763E]" />
              <span className="font-semibold text-[#231812]">Direct Workshop Pricing</span>
            </div>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold tracking-wider transition-all duration-200 ${
                selectedCategory === cat
                  ? 'bg-[#A8763E] text-white font-bold shadow-md'
                  : 'bg-white text-[#57473B] border border-[#E2D9C8] hover:border-[#A8763E] hover:text-[#231812]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white border border-[#E8E1D5] rounded-2xl p-12 text-center max-w-lg mx-auto shadow-sm">
            <Package className="w-12 h-12 text-[#A8763E] mx-auto mb-3 opacity-60" />
            <h3 className="font-serif-luxury text-xl font-medium text-[#231812] mb-2">No Ready-Made Items in this category</h3>
            <p className="text-sm text-[#57473B] font-light mb-6">
              Our inventory sells fast! We can craft this exact design tailored to your dimensions.
            </p>
            <button
              onClick={() => onRequestCustomization('Ready-Made In-Stock Item')}
              className="px-6 py-2.5 rounded-lg bg-[#A8763E] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#91632F] transition-colors shadow-sm"
            >
              Request Custom Order
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-2xl border border-[#E8E1D5] hover:border-[#A8763E] transition-all duration-300 shadow-sm hover:shadow-xl flex flex-col group overflow-hidden"
              >
                {/* Image & Badges */}
                <div className="relative aspect-[4/3] overflow-hidden bg-[#FAF7F2] cursor-pointer" onClick={() => {
                  setSelectedProductForModal(product);
                  setActiveImageIndex(0);
                }}>
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="px-4 py-2 rounded-lg bg-white/95 text-[#231812] text-xs font-bold tracking-wider uppercase border border-[#A8763E] shadow-md flex items-center gap-1.5">
                      <Maximize2 className="w-3.5 h-3.5 text-[#A8763E]" />
                      <span>Quick View</span>
                    </span>
                  </div>

                  {/* Stock Badge */}
                  <div className="absolute top-3 left-3 bg-emerald-50 border border-emerald-300 text-emerald-800 px-3 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider shadow-sm flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>In Stock ({product.inStockCount || 1} available)</span>
                  </div>

                  {/* Heart Save Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleSaveItem({
                        id: product.id,
                        title: product.name,
                        category: product.category,
                        imageUrl: product.imageUrl,
                        type: 'product',
                        savedAt: new Date().toISOString()
                      }, true);
                    }}
                    className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/95 backdrop-blur-sm border border-[#E2D9C8] hover:border-[#A8763E] flex items-center justify-center text-[#57473B] hover:text-[#A8763E] transition-all shadow-sm z-10"
                    title={isItemSaved(product.id) ? 'Saved' : 'Save Item'}
                  >
                    <Heart className={`w-4 h-4 ${isItemSaved(product.id) ? 'fill-[#A8763E] text-[#A8763E]' : ''}`} />
                  </button>
                </div>

                {/* Content */}
                <div className="p-6 flex-1 flex flex-col">
                  <div className="text-[11px] text-[#A8763E] uppercase tracking-widest font-bold mb-1.5">
                    {product.category}
                  </div>
                  
                  <h3 className="font-serif-luxury text-xl font-medium text-[#231812] mb-2 line-clamp-1 group-hover:text-[#A8763E] transition-colors">
                    {product.name}
                  </h3>

                  <p className="text-sm text-[#57473B] font-light line-clamp-2 mb-4 leading-relaxed">
                    {product.description}
                  </p>

                  {/* Specs Pill List */}
                  <div className="space-y-1.5 py-3 border-y border-[#E8E1D5] my-auto text-xs text-[#57473B]">
                    <div className="flex items-center gap-2">
                      <Layers className="w-3.5 h-3.5 text-[#A8763E] flex-shrink-0" />
                      <span className="font-medium text-[#231812]">Wood:</span>
                      <span className="truncate text-[#42352B]">{product.woodType}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Ruler className="w-3.5 h-3.5 text-[#A8763E] flex-shrink-0" />
                      <span className="font-medium text-[#231812]">Size:</span>
                      <span className="truncate text-[#42352B]">{product.dimensionsNote}</span>
                    </div>
                    {product.leadTime && (
                      <div className="flex items-center gap-2 text-emerald-700">
                        <Clock className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                        <span className="font-medium">{product.leadTime}</span>
                      </div>
                    )}
                  </div>

                  {/* Price & Action Row */}
                  <div className="pt-4 flex items-center justify-between gap-3 mt-4">
                    <div>
                      <div className="flex items-baseline gap-2">
                        <span className="font-serif-luxury text-2xl font-bold text-[#A8763E]">
                          {product.price}
                        </span>
                        {product.originalPrice && (
                          <span className="text-xs text-[#8A7A6E] line-through">
                            {product.originalPrice}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] uppercase tracking-wider text-[#7A6E63] font-medium block">
                        {product.priceLabel || 'Direct Workshop Price'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleWhatsAppOrder(product)}
                        className="px-4 py-2.5 rounded-lg bg-[#25D366] hover:bg-[#20b858] text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-transform active:scale-95"
                        title="Order via WhatsApp"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Order</span>
                      </button>

                      <button
                        onClick={() => onOrderProduct(product)}
                        className="px-4 py-2.5 rounded-lg bg-[#FAF7F2] hover:bg-[#A8763E] hover:text-white text-[#231812] border border-[#E2D9C8] text-xs font-bold uppercase tracking-wider transition-colors shadow-sm"
                      >
                        Inquire
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Custom Order Callout Banner */}
        <div className="mt-16 bg-white rounded-2xl p-8 sm:p-12 text-[#231812] shadow-sm border border-[#E8E1D5] relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="relative z-10 max-w-2xl">
            <span className="text-xs uppercase tracking-widest text-[#A8763E] font-mono font-bold block mb-2">
              Need Different Dimensions or Specific Wood?
            </span>
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-normal text-[#231812] mb-3">
              We Custom-Carve Any Ready-Made Pattern to Your Frame Dimensions
            </h3>
            <p className="text-sm text-[#57473B] font-light leading-relaxed">
              If your doorway requires a custom height, double-shutter split, or specific timber species (Teak, Anjili, Rosewood), we fabricate it to your exact specifications.
            </p>
          </div>

          <div className="relative z-10 flex-shrink-0 flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={() => onRequestCustomization('Custom Sizing for Ready Pattern')}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-[#A8763E] hover:bg-[#91632F] text-white font-bold text-xs uppercase tracking-widest shadow-md flex items-center justify-center gap-2 transition-transform active:scale-95"
            >
              <span>Request Custom Size Quote</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* Modal / Quick View Popup */}
      {selectedProductForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div 
            className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-[#E8E1D5] shadow-2xl relative text-[#231812]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={() => setSelectedProductForModal(null)}
              className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-white/90 border border-[#E2D9C8] text-[#231812] hover:text-[#A8763E] flex items-center justify-center shadow-sm transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="grid grid-cols-1 md:grid-cols-2">
              {/* Product Images Preview */}
              <div className="bg-[#FAF7F2] p-6 flex flex-col justify-between border-b md:border-b-0 md:border-r border-[#E8E1D5]">
                <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-white border border-[#E2D9C8]">
                  <img
                    src={
                      selectedProductForModal.additionalImages && selectedProductForModal.additionalImages[activeImageIndex]
                        ? selectedProductForModal.additionalImages[activeImageIndex]
                        : selectedProductForModal.imageUrl
                    }
                    alt={selectedProductForModal.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3 bg-emerald-50 border border-emerald-300 text-emerald-800 px-2.5 py-1 rounded text-[11px] font-bold uppercase tracking-wider">
                    {selectedProductForModal.leadTime || 'In Stock'}
                  </div>
                </div>

                {/* Thumbnails if available */}
                {selectedProductForModal.additionalImages && selectedProductForModal.additionalImages.length > 0 && (
                  <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
                    <button
                      onClick={() => setActiveImageIndex(0)}
                      className={`w-16 h-16 rounded-lg overflow-hidden border-2 flex-shrink-0 ${
                        activeImageIndex === 0 ? 'border-[#A8763E]' : 'border-transparent opacity-60'
                      }`}
                    >
                      <img src={selectedProductForModal.imageUrl} alt="thumb" className="w-full h-full object-cover" />
                    </button>
                    {selectedProductForModal.additionalImages.map((img, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveImageIndex(idx)}
                        className={`w-16 h-16 rounded-lg overflow-hidden border-2 flex-shrink-0 ${
                          activeImageIndex === idx ? 'border-[#A8763E]' : 'border-transparent opacity-60'
                        }`}
                      >
                        <img src={img} alt="thumb" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Product Details */}
              <div className="p-6 sm:p-8 flex flex-col justify-between">
                <div>
                  <div className="text-xs uppercase tracking-widest font-bold text-[#A8763E] mb-1">
                    {selectedProductForModal.category}
                  </div>
                  <h3 className="font-serif-luxury text-2xl sm:text-3xl font-medium text-[#231812] mb-3">
                    {selectedProductForModal.name}
                  </h3>

                  {/* Price */}
                  <div className="flex items-baseline gap-3 mb-4">
                    <span className="font-serif-luxury text-3xl font-bold text-[#A8763E]">
                      {selectedProductForModal.price}
                    </span>
                    {selectedProductForModal.originalPrice && (
                      <span className="text-sm text-[#8A7A6E] line-through">
                        {selectedProductForModal.originalPrice}
                      </span>
                    )}
                  </div>

                  <p className="text-sm text-[#57473B] font-light leading-relaxed mb-6">
                    {selectedProductForModal.description}
                  </p>

                  {/* Highlights */}
                  {selectedProductForModal.highlights && selectedProductForModal.highlights.length > 0 && (
                    <div className="mb-6 space-y-2">
                      <span className="text-xs uppercase tracking-wider font-bold text-[#231812] block">
                        Key Features & Craftsmanship:
                      </span>
                      {selectedProductForModal.highlights.map((h, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs text-[#42352B]">
                          <CheckCircle2 className="w-4 h-4 text-[#A8763E] flex-shrink-0 mt-0.5" />
                          <span className="font-light">{h}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Specs Table */}
                  <div className="bg-[#FAF7F2] rounded-xl p-4 border border-[#E8E1D5] space-y-2 text-xs mb-6">
                    <div className="flex justify-between py-1 border-b border-[#E8E1D5]">
                      <span className="text-[#7A6E63]">Timber Species:</span>
                      <span className="font-semibold text-[#231812]">{selectedProductForModal.woodType}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-[#E8E1D5]">
                      <span className="text-[#7A6E63]">Ready Dimensions:</span>
                      <span className="font-semibold text-[#231812]">{selectedProductForModal.dimensionsNote}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-[#7A6E63]">Carving Technique:</span>
                      <span className="font-semibold text-[#231812]">{selectedProductForModal.carvingStyle || 'High-Relief CNC'}</span>
                    </div>
                    <div className="flex justify-between py-1 border-t border-[#E8E1D5] text-[#A8763E] pt-2">
                      <span className="font-medium">Collection:</span>
                      <span className="font-bold">Customer Pickup at Adoor Workshop (No Delivery)</span>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Buttons */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-4 border-t border-[#E8E1D5]">
                  <button
                    onClick={() => {
                      handleWhatsAppOrder(selectedProductForModal);
                      setSelectedProductForModal(null);
                    }}
                    className="w-full sm:flex-1 py-3.5 rounded-xl bg-[#25D366] hover:bg-[#20b858] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-colors"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Instant WhatsApp Order</span>
                  </button>

                  <button
                    onClick={() => {
                      const prod = selectedProductForModal;
                      setSelectedProductForModal(null);
                      onOrderProduct(prod);
                    }}
                    className="w-full sm:flex-1 py-3.5 rounded-xl bg-[#A8763E] hover:bg-[#91632F] text-white text-xs font-bold uppercase tracking-widest transition-colors shadow-md text-center"
                  >
                    Request Callback / Quote
                  </button>
                </div>

              </div>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
