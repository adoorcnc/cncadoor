import React from 'react';
import { Header } from './Header';
import { Hero } from './Hero';
import { Specialties } from './Specialties';
import { ReadyMadeProducts } from './ReadyMadeProducts';
import { OurDoors } from './OurDoors';
import { WoodCarving } from './WoodCarving';
import { CustomDesignsSection } from './CustomDesignsSection';
import { CarvingProcess } from './CarvingProcess';
import { FeaturedWork } from './FeaturedWork';
import { Gallery } from './Gallery';
import { WhyCncadoor } from './WhyCncadoor';
import { CustomDesignCta } from './CustomDesignCta';
import { QuoteSection } from './QuoteSection';
import { ContactSection } from './ContactSection';
import { AboutUs } from './AboutUs';
import { Footer } from './Footer';
import { FloatingActions } from './FloatingActions';
import { SearchResultItem } from './HeaderSearch';
import { useStore } from '../context/StoreContext';

export interface StorefrontLayoutProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedDoorCategory: string;
  setSelectedDoorCategory: (cat: string) => void;
  gallerySearchQuery: string;
  setGallerySearchQuery: (query: string) => void;
  highlightedGalleryItem: string | null;
  onOpenQuote: (doorType?: string, designTitle?: string) => void;
  onSelectSearchResult: (result: SearchResultItem) => void;
  onSearchInGallery: (query: string) => void;
  onOpenAdmin: () => void;
  onOpenCatalog: () => void;
  isEmbeddedPreview?: boolean;
}

export const StorefrontLayout: React.FC<StorefrontLayoutProps> = ({
  activeTab,
  setActiveTab,
  selectedDoorCategory,
  setSelectedDoorCategory,
  gallerySearchQuery,
  setGallerySearchQuery,
  highlightedGalleryItem,
  onOpenQuote,
  onSelectSearchResult,
  onSearchInGallery,
  onOpenAdmin,
  onOpenCatalog,
  isEmbeddedPreview = false,
}) => {
  const { setAdminDualViewMode } = useStore();

  const handleSpecialtyExplore = (category: string) => {
    setSelectedDoorCategory(category);
    setActiveTab('doors');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`min-h-screen bg-[#FAF7F2] text-[#443529] flex flex-col selection:bg-[#A8763E] selection:text-white ${isEmbeddedPreview ? 'text-xs' : ''}`}>
      
      {/* Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenQuote={() => onOpenQuote()}
        onSelectSearchResult={onSelectSearchResult}
        onSearchInGallery={onSearchInGallery}
        onOpenAdmin={onOpenAdmin}
        onOpenCatalog={onOpenCatalog}
      />

      {/* Main Content Areas based on active view */}
      <main className="flex-grow">
        {activeTab === 'home' && (
          <div>
            {/* 3. Hero Section */}
            <Hero
              onExploreDoors={() => {
                setActiveTab('doors');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onRequestQuote={() => onOpenQuote()}
            />

            {/* 5. Our Specialties ("Our Craft") */}
            <Specialties
              onSelectCategory={handleSpecialtyExplore}
              onSelectSpecialty={handleSpecialtyExplore}
            />

            {/* Ready-made in-stock spotlight on Home */}
            <ReadyMadeProducts
              onRequestQuote={(productName, wood) => onOpenQuote(wood, productName)}
            />

            {/* Doors Preview Section */}
            <OurDoors
              selectedCategory={selectedDoorCategory}
              setSelectedCategory={setSelectedDoorCategory}
              onRequestQuote={(doorName, doorType) => onOpenQuote(doorType, doorName)}
              onOpenCatalog={onOpenCatalog}
            />

            {/* 7. Wood Carving Masterclass Highlight */}
            <WoodCarving
              onRequestCustomCarving={() => onOpenQuote('Custom Door', 'Custom Wood Carving Inquiry')}
            />

            {/* Custom Designs Showcase */}
            <CustomDesignsSection
              onOpenQuote={(title) => onOpenQuote('Custom Door', title)}
            />

            {/* 8. Carving Process Timeline */}
            <CarvingProcess />

            {/* 10. Featured Work ("Crafted With Character") */}
            <FeaturedWork
              onViewAllProjects={() => {
                setActiveTab('gallery');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onRequestQuote={(projectTitle) => onOpenQuote('Main Entrance Door', projectTitle)}
            />

            {/* 9. Gallery Preview */}
            <Gallery
              onRequestQuoteWithItem={(itemTitle) => onOpenQuote('Custom Door', itemTitle)}
              searchQuery={gallerySearchQuery}
              onClearSearch={() => setGallerySearchQuery('')}
              highlightedItemId={highlightedGalleryItem}
            />

            {/* 11. Why CNCADOOR ("Craftsmanship You Can See") */}
            <WhyCncadoor />

            {/* 12. Custom Design Section (Dramatic Dark CTA) */}
            <CustomDesignCta
              onSendDesign={() => onOpenQuote('Custom Door', 'Client Reference Image Design')}
              onRequestQuote={() => onOpenQuote()}
            />

            {/* 13. Request a Quote Section */}
            <QuoteSection />

            {/* Contact & Workshop Section */}
            <ContactSection
              onStartProject={() => onOpenQuote()}
            />
          </div>
        )}

        {activeTab === 'doors' && (
          <div className="pt-4">
            <OurDoors
              selectedCategory={selectedDoorCategory}
              setSelectedCategory={setSelectedDoorCategory}
              onRequestQuote={(doorName, doorType) => onOpenQuote(doorType, doorName)}
              onOpenCatalog={onOpenCatalog}
            />
            
            {/* Custom Design Callout */}
            <CustomDesignCta
              onSendDesign={() => onOpenQuote('Custom Door', 'Client Reference Image Design')}
              onRequestQuote={() => onOpenQuote()}
            />
          </div>
        )}

        {activeTab === 'carving' && (
          <div className="pt-4">
            <WoodCarving
              onRequestCustomCarving={() => onOpenQuote('Custom Door', 'Custom Wood Carving Inquiry')}
            />
            <CarvingProcess />
            <CustomDesignCta
              onSendDesign={() => onOpenQuote('Custom Door', 'Custom Carving Project')}
              onRequestQuote={() => onOpenQuote()}
            />
          </div>
        )}

        {activeTab === 'ready-made' && (
          <div className="pt-4">
            <ReadyMadeProducts
              onRequestQuote={(productName, wood) => onOpenQuote(wood, productName)}
            />
            <CustomDesignCta
              onSendDesign={() => onOpenQuote('Custom Door', 'Ready Made Alternate Dimension')}
              onRequestQuote={() => onOpenQuote()}
            />
          </div>
        )}

        {activeTab === 'custom-designs' && (
          <div className="pt-4">
            <CustomDesignsSection
              onOpenQuote={(title) => onOpenQuote('Custom Door', title)}
            />
            <CarvingProcess />
            <QuoteSection />
          </div>
        )}

        {activeTab === 'gallery' && (
          <div className="pt-4">
            <Gallery
              onRequestQuoteWithItem={(itemTitle) => onOpenQuote('Custom Door', itemTitle)}
              searchQuery={gallerySearchQuery}
              onClearSearch={() => setGallerySearchQuery('')}
              highlightedItemId={highlightedGalleryItem}
            />
            <CustomDesignCta
              onSendDesign={() => onOpenQuote('Custom Door', 'Gallery Selected Reference')}
              onRequestQuote={() => onOpenQuote()}
            />
          </div>
        )}

        {activeTab === 'about' && (
          <div className="pt-4">
            <AboutUs />
            <WhyCncadoor />
            <CarvingProcess />
            <ContactSection
              onStartProject={() => onOpenQuote()}
            />
          </div>
        )}

        {activeTab === 'contact' && (
          <div className="pt-4">
            <ContactSection
              onStartProject={() => onOpenQuote()}
            />
            <QuoteSection />
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer
        setActiveTab={setActiveTab}
        onSelectCategory={(cat) => {
          setSelectedDoorCategory(cat);
          setActiveTab('doors');
        }}
        onOpenQuote={() => onOpenQuote()}
        onOpenAdmin={onOpenAdmin}
        onOpenCatalog={onOpenCatalog}
      />

      {/* Floating Actions only on non-embedded preview to avoid clutter */}
      {!isEmbeddedPreview && <FloatingActions />}

    </div>
  );
};
