import React, { useState, useEffect } from 'react';
import { BUSINESS_CONFIG } from '../data/config';
import { QuoteFormData } from '../types';
import { UploadCloud, CheckCircle2, MessageSquare, Phone, Send, X, LogIn, UserCheck, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface QuoteSectionProps {
  initialDoorType?: string;
  initialDesignTitle?: string;
  onSuccessClose?: () => void;
  isModal?: boolean;
}

export const QuoteSection: React.FC<QuoteSectionProps> = ({ 
  initialDoorType, 
  initialDesignTitle,
  onSuccessClose,
  isModal = false
}) => {
  const { user, openAuthModal, addQuoteRecord } = useAuth();

  const [formData, setFormData] = useState<QuoteFormData>({
    name: user?.name || '',
    phoneNumber: user?.phone || '',
    email: user?.email || '',
    requirement: initialDesignTitle ? `Inquiry regarding: ${initialDesignTitle}` : '',
    doorType: initialDoorType || 'Main Entrance Door',
    approximateSize: '',
    woodPreference: 'Teak Wood (Recommended)',
    designDescription: '',
    referenceImageName: '',
    referenceImageData: '',
    preferredContactMethod: 'WhatsApp'
  });

  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        name: prev.name || user.name,
        phoneNumber: prev.phoneNumber || user.phone || '',
        email: prev.email || user.email || '',
      }));
    }
  }, [user]);

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const productTypeOptions = [
    'Main Entrance Door',
    'Carved Wooden Door',
    'Traditional Kerala Door',
    'Pooja Mandir Door / Sanctum Shutter',
    'Double Shutter Grand Villa Door',
    'Contemporary Wooden Door',
    'Architectural CNC Wood Carving Panel',
    'Custom Temple Carving Motif',
    'Decorative Wall Carving Relief',
    'Other Custom Door / Carving Requirement'
  ];

  const woodOptions = [
    'Burma Teak / Nilambur Teak (Recommended)',
    'Rosewood / Eeti',
    'Anjili Wood (Traditional)',
    'Seasoned Mahogany',
    'Solid Teak + Brass Inlays',
    'Open to Consultation / Expert Advice'
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
        setFormData(prev => ({
          ...prev,
          referenceImageName: file.name,
          referenceImageData: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setImagePreview(null);
    setFormData(prev => ({
      ...prev,
      referenceImageName: '',
      referenceImageData: ''
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phoneNumber.trim()) {
      return;
    }
    addQuoteRecord(formData);
    setIsSubmitted(true);
  };

  const handleSendViaWhatsApp = () => {
    addQuoteRecord(formData);

    const text = `*New Custom Quote Request - CNCADOOR*\n\n` +
      `*Name:* ${formData.name}\n` +
      `*Phone:* ${formData.phoneNumber}\n` +
      (formData.email ? `*Email:* ${formData.email}\n` : '') +
      `*Product/Door Type:* ${formData.doorType}\n` +
      (formData.requirement ? `*Requirement:* ${formData.requirement}\n` : '') +
      (formData.approximateSize ? `*Approx Size:* ${formData.approximateSize}\n` : '') +
      (formData.woodPreference ? `*Wood Preference:* ${formData.woodPreference}\n` : '') +
      (formData.designDescription ? `*Description:* ${formData.designDescription}\n` : '') +
      `*Preferred Contact:* ${formData.preferredContactMethod}\n` +
      `*Collection:* I understand customer pickup is required directly from the Adoor workshop (no delivery service).\n` +
      (formData.referenceImageName ? `*Reference Attached:* ${formData.referenceImageName}\n` : '');

    const encoded = encodeURIComponent(text);
    const targetPhone = BUSINESS_CONFIG.whatsapps[0];
    window.open(`https://wa.me/91${targetPhone}?text=${encoded}`, '_blank');
  };

  return (
    <div className={`w-full text-[#231812] ${isModal ? 'p-0' : 'py-16 bg-[#FAF7F2]'}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {!isModal && (
          <div className="text-center max-w-2xl mx-auto mb-12">
            <div className="text-xs uppercase tracking-[0.22em] text-[#A8763E] font-bold mb-3">
              Direct Enquiry & Sizing
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-normal text-[#231812] mb-4">
              Request a Quote
            </h2>
            <div className="w-16 h-[2px] bg-[#A8763E] mx-auto mb-4" />
            <p className="text-[#57473B] text-sm sm:text-base font-light leading-relaxed">
              Share your doorway dimensions, custom wood carving specifications, or reference drawings. Our craftsmen will provide a tailored quote.
            </p>
          </div>
        )}

        {/* Customer Self-Pickup Notice Card */}
        <div className="mb-8 bg-[#FFF9F2] border border-[#F3DFC1] rounded-2xl p-4 sm:p-5 flex items-start gap-3.5 shadow-xs">
          <div className="w-9 h-9 rounded-xl bg-[#A8763E] text-white flex items-center justify-center flex-shrink-0 mt-0.5 shadow-xs">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div className="text-xs">
            <span className="font-bold text-[#A8763E] uppercase tracking-wider block mb-0.5">
              Workshop Collection Only (No Delivery Service)
            </span>
            <p className="text-[#57473B] leading-relaxed">
              Please note that <strong>we do not deliver products</strong>. Customers are required to collect their completed doors, pooja mandapams, and architectural wood carvings directly from our workshop in <strong>Adoor, Pathanamthitta, Kerala</strong>. Our workshop team assists with safe vehicle loading and protective wrap packaging.
            </p>
          </div>
        </div>

        {isSubmitted ? (
          <div className="bg-white border border-[#E8E1D5] rounded-2xl p-8 sm:p-12 text-center shadow-lg animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-[#FAF7F2] border border-[#A8763E] flex items-center justify-center text-[#A8763E] mx-auto mb-6">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-normal text-[#231812] mb-3">
              Quote Request Received
            </h3>
            
            <p className="text-[#57473B] text-base max-w-lg mx-auto mb-6 font-light leading-relaxed">
              Thank you for choosing CNCADOOR. Our consultation team will contact you shortly with estimates and drawings.
            </p>

            <div className="bg-[#FAF7F2] p-6 rounded-xl border border-[#E8E1D5] max-w-md mx-auto mb-8 text-left text-xs text-[#231812] space-y-2">
              <div className="flex justify-between border-b border-[#E8E1D5] pb-2">
                <span className="text-[#A8763E] font-medium">Client Name:</span>
                <span className="font-semibold">{formData.name}</span>
              </div>
              <div className="flex justify-between border-b border-[#E8E1D5] pb-2">
                <span className="text-[#A8763E] font-medium">Phone:</span>
                <span className="font-mono font-semibold">{formData.phoneNumber}</span>
              </div>
              <div className="flex justify-between border-b border-[#E8E1D5] pb-2">
                <span className="text-[#A8763E] font-medium">Product / Door:</span>
                <span>{formData.doorType}</span>
              </div>
              <div className="flex justify-between border-b border-[#E8E1D5] pb-2">
                <span className="text-[#A8763E] font-medium">Contact Method:</span>
                <span>{formData.preferredContactMethod}</span>
              </div>
              <div className="flex justify-between pt-1 text-[#A8763E]">
                <span className="font-semibold">Collection:</span>
                <span className="font-bold">Customer Pickup at Adoor Workshop</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={handleSendViaWhatsApp}
                className="w-full sm:w-auto px-6 py-3 rounded-lg text-xs uppercase tracking-widest font-bold bg-[#25D366] hover:bg-[#1ebd5a] text-white transition-all flex items-center justify-center gap-2 shadow-sm"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Open Instant WhatsApp Chat</span>
              </button>

              <button
                onClick={() => {
                  setIsSubmitted(false);
                  if (onSuccessClose) onSuccessClose();
                }}
                className="w-full sm:w-auto px-6 py-3 rounded-lg text-xs uppercase tracking-widest font-bold bg-[#A8763E] text-white hover:bg-[#91632F] transition-colors shadow-sm"
              >
                Submit Another Request
              </button>
            </div>
          </div>
        ) : (
          <form 
            onSubmit={handleSubmit}
            className="bg-white border border-[#E8E1D5] rounded-2xl p-6 sm:p-10 shadow-lg space-y-6"
          >
            {/* User Account Sign In Callout */}
            {user ? (
              <div className="bg-[#FAF7F2] border border-[#A8763E]/40 rounded-xl p-3.5 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-[#A8763E] text-white flex items-center justify-center font-bold text-xs">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <span className="font-semibold text-[#231812]">{user.name}</span>
                    <span className="text-[#7A6E63] ml-2 font-mono">({user.phone || user.email})</span>
                    <p className="text-[11px] text-[#A8763E]">Signed in • Contact details pre-filled & quotes saved to your profile</p>
                  </div>
                </div>
                <div className="inline-flex items-center gap-1 text-[11px] text-[#16A34A] bg-[#E8F8EE] px-2 py-0.5 rounded font-medium border border-[#25D366]/40">
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Profile Synced</span>
                </div>
              </div>
            ) : (
              <div className="bg-[#FAF7F2] border border-[#E8E1D5] rounded-xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5 text-[#57473B]">
                  <Sparkles className="w-4 h-4 text-[#A8763E] flex-shrink-0" />
                  <span>Have a client account or want to auto-fill your contact info?</span>
                </div>
                <button
                  type="button"
                  onClick={() => openAuthModal('quote_form')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-[#A8763E] text-[#A8763E] hover:bg-[#A8763E] hover:text-white transition-colors font-semibold text-[11px] whitespace-nowrap shadow-xs"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Quick Sign In</span>
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              {/* Name (Required) */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Thomas K. / Architect Menon"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 bg-[#FAF7F2] border border-[#E2D9C8] rounded-lg text-sm text-[#231812] placeholder-[#8A7A6E] focus:outline-none focus:border-[#A8763E] focus:bg-white"
                />
              </div>

              {/* Phone Number (Required) */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                  Phone Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 9876543210"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({...formData, phoneNumber: e.target.value})}
                  className="w-full px-4 py-3 bg-[#FAF7F2] border border-[#E2D9C8] rounded-lg text-sm text-[#231812] placeholder-[#8A7A6E] focus:outline-none focus:border-[#A8763E] focus:bg-white"
                />
              </div>

              {/* Email (Optional) */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                  Email Address <span className="text-[#8A7A6E] font-normal">(Optional)</span>
                </label>
                <input
                  type="email"
                  placeholder="e.g. you@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full px-4 py-3 bg-[#FAF7F2] border border-[#E2D9C8] rounded-lg text-sm text-[#231812] placeholder-[#8A7A6E] focus:outline-none focus:border-[#A8763E] focus:bg-white"
                />
              </div>

              {/* Product / Door Type */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                  Category / Item Type
                </label>
                <select
                  value={formData.doorType}
                  onChange={(e) => setFormData({...formData, doorType: e.target.value})}
                  className="w-full px-4 py-3 bg-[#FAF7F2] border border-[#E2D9C8] rounded-lg text-sm text-[#231812] focus:outline-none focus:border-[#A8763E] focus:bg-white"
                >
                  {productTypeOptions.map((type) => (
                    <option key={type} value={type} className="bg-white text-[#231812]">
                      {type}
                    </option>
                  ))}
                </select>
              </div>

              {/* Approximate Size (Optional) */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                  Approximate Size <span className="text-[#8A7A6E] font-normal">(e.g. 7ft x 3.5ft / Standard 81" x 36")</span>
                </label>
                <input
                  type="text"
                  placeholder="Height x Width in feet or inches"
                  value={formData.approximateSize}
                  onChange={(e) => setFormData({...formData, approximateSize: e.target.value})}
                  className="w-full px-4 py-3 bg-[#FAF7F2] border border-[#E2D9C8] rounded-lg text-sm text-[#231812] placeholder-[#8A7A6E] focus:outline-none focus:border-[#A8763E] focus:bg-white"
                />
              </div>

              {/* Wood Preference (Optional) */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                  Timber Preference <span className="text-[#8A7A6E] font-normal">(Optional)</span>
                </label>
                <select
                  value={formData.woodPreference}
                  onChange={(e) => setFormData({...formData, woodPreference: e.target.value})}
                  className="w-full px-4 py-3 bg-[#FAF7F2] border border-[#E2D9C8] rounded-lg text-sm text-[#231812] focus:outline-none focus:border-[#A8763E] focus:bg-white"
                >
                  {woodOptions.map((wood) => (
                    <option key={wood} value={wood} className="bg-white text-[#231812]">
                      {wood}
                    </option>
                  ))}
                </select>
              </div>

            </div>

            {/* Requirement / Subject Title */}
            <div>
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                Requirement / Project Title
              </label>
              <input
                type="text"
                placeholder="e.g. Teak villa entrance door and carved pooja mandir panel in Kerala"
                value={formData.requirement}
                onChange={(e) => setFormData({...formData, requirement: e.target.value})}
                className="w-full px-4 py-3 bg-[#FAF7F2] border border-[#E2D9C8] rounded-lg text-sm text-[#231812] placeholder-[#8A7A6E] focus:outline-none focus:border-[#A8763E] focus:bg-white"
              />
            </div>

            {/* Design Description */}
            <div>
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                Design Description & Specific Carving Notes
              </label>
              <textarea
                rows={3}
                placeholder="Describe your design preference, motif ideas (traditional temple patterns, fluted modern slats, geometric lines, or custom reference)..."
                value={formData.designDescription}
                onChange={(e) => setFormData({...formData, designDescription: e.target.value})}
                className="w-full px-4 py-3 bg-[#FAF7F2] border border-[#E2D9C8] rounded-lg text-sm text-[#231812] placeholder-[#8A7A6E] focus:outline-none focus:border-[#A8763E] focus:bg-white"
              />
            </div>

            {/* Upload Reference Image with Drag/Drop Support */}
            <div>
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                Upload Reference Image / Sketch
              </label>
              
              {imagePreview ? (
                <div className="relative p-4 bg-[#FAF7F2] border border-[#A8763E]/60 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img src={imagePreview} alt="Reference" className="w-16 h-16 object-cover rounded-lg border border-[#E2D9C8]" />
                    <div>
                      <p className="text-xs font-semibold text-[#231812]">{formData.referenceImageName || 'Uploaded Reference Image'}</p>
                      <p className="text-[11px] text-[#A8763E] font-medium">Ready to submit with enquiry</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={removeImage}
                    className="p-2 rounded-full bg-white border border-[#E2D9C8] text-[#57473B] hover:bg-red-50 hover:text-red-600 transition-colors shadow-xs"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="border-2 border-dashed border-[#E2D9C8] hover:border-[#A8763E] rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer transition-colors bg-[#FAF7F2] hover:bg-[#FFF9F2]">
                  <UploadCloud className="w-8 h-8 text-[#A8763E] mb-2" />
                  <span className="text-xs text-[#231812] font-semibold mb-1">Click to browse or drag reference image here</span>
                  <span className="text-[10px] text-[#7A6E63]">Supports JPG, PNG, WEBP, CAD sketches</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>

            {/* Preferred Contact Method */}
            <div>
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-2">
                Preferred Contact Method
              </label>
              <div className="grid grid-cols-2 gap-4">
                <label 
                  className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                    formData.preferredContactMethod === 'WhatsApp'
                      ? 'bg-[#E8F8EE] border-[#25D366] text-[#15803D]'
                      : 'bg-[#FAF7F2] border-[#E2D9C8] text-[#57473B]'
                  }`}
                >
                  <input
                    type="radio"
                    name="preferredContact"
                    value="WhatsApp"
                    checked={formData.preferredContactMethod === 'WhatsApp'}
                    onChange={() => setFormData({...formData, preferredContactMethod: 'WhatsApp'})}
                    className="hidden"
                  />
                  <MessageSquare className="w-4 h-4" />
                  <span className="text-xs font-semibold">WhatsApp</span>
                </label>

                <label 
                  className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                    formData.preferredContactMethod === 'Phone'
                      ? 'bg-[#FFF9F2] border-[#A8763E] text-[#A8763E]'
                      : 'bg-[#FAF7F2] border-[#E2D9C8] text-[#57473B]'
                  }`}
                >
                  <input
                    type="radio"
                    name="preferredContact"
                    value="Phone"
                    checked={formData.preferredContactMethod === 'Phone'}
                    onChange={() => setFormData({...formData, preferredContactMethod: 'Phone'})}
                    className="hidden"
                  />
                  <Phone className="w-4 h-4" />
                  <span className="text-xs font-semibold">Phone Call</span>
                </label>
              </div>
            </div>

            {/* Submit Action Buttons */}
            <div className="pt-4 border-t border-[#E8E1D5] flex flex-col sm:flex-row items-center gap-4">
              <button
                type="submit"
                id="submit-quote-form-btn"
                className="w-full sm:flex-1 py-3.5 rounded-lg text-xs uppercase tracking-[0.2em] font-bold bg-[#A8763E] text-white hover:bg-[#91632F] shadow-sm transition-all active:scale-98 flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>SUBMIT QUOTE REQUEST</span>
              </button>

              <button
                type="button"
                onClick={handleSendViaWhatsApp}
                className="w-full sm:w-auto px-6 py-3.5 rounded-lg text-xs uppercase tracking-widest font-bold bg-[#25D366] hover:bg-[#1ebd5a] text-white transition-all flex items-center justify-center gap-2 shadow-sm"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Send via WhatsApp</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
