import React, { useState, useRef, useEffect } from 'react';
import { Search, X, ArrowRight, Sparkles, DoorClosed, Layers, Eye } from 'lucide-react';
import { DOORS_DATA, GALLERY_ITEMS, CARVING_PATTERNS } from '../data/config';

export interface SearchResultItem {
  id: string;
  title: string;
  category: string;
  type: 'gallery' | 'door' | 'carving';
  woodType?: string;
  carvingStyle?: string;
  imageUrl: string;
  description?: string;
}

interface HeaderSearchProps {
  onSelectResult: (result: SearchResultItem) => void;
  onOpenGalleryWithQuery: (query: string) => void;
}

export const HeaderSearch: React.FC<HeaderSearchProps> = ({
  onSelectResult,
  onOpenGalleryWithQuery,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Quick suggestions for easy exploration
  const quickTags = [
    'Teak',
    'Lotus',
    'Main Entrance',
    'Floral',
    'Temple',
    'Geometric',
    'Traditional',
    'Carved Doors',
    'Contemporary',
    'Mahogany',
  ];

  // Aggregate searchable items from gallery, doors, and carving patterns
  const allSearchableItems: SearchResultItem[] = [
    ...GALLERY_ITEMS.map((item) => ({
      id: `gallery-${item.id}`,
      title: item.title,
      category: `Gallery • ${item.category}`,
      type: 'gallery' as const,
      woodType: item.woodType,
      imageUrl: item.imageUrl,
      description: item.description,
    })),
    ...DOORS_DATA.map((door) => ({
      id: `door-${door.id}`,
      title: door.name,
      category: `Door • ${door.category}`,
      type: 'door' as const,
      woodType: door.woodType,
      carvingStyle: door.carvingStyle,
      imageUrl: door.imageUrl,
      description: door.description,
    })),
    ...CARVING_PATTERNS.map((pattern) => ({
      id: `carving-${pattern.id}`,
      title: pattern.title,
      category: `Carving Style • ${pattern.category}`,
      type: 'carving' as const,
      imageUrl: pattern.imageUrl,
      description: pattern.description,
    })),
  ];

  // Filter based on user query
  const trimmed = query.trim().toLowerCase();
  const searchResults = trimmed
    ? allSearchableItems.filter((item) => {
        const titleMatch = item.title.toLowerCase().includes(trimmed);
        const categoryMatch = item.category.toLowerCase().includes(trimmed);
        const woodMatch = item.woodType?.toLowerCase().includes(trimmed);
        const styleMatch = item.carvingStyle?.toLowerCase().includes(trimmed);
        const descMatch = item.description?.toLowerCase().includes(trimmed);
        return titleMatch || categoryMatch || woodMatch || styleMatch || descMatch;
      }).slice(0, 7) // Keep it lightweight and fast
    : [];

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  // Handle escape key or click outside
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };
    const handleClickOutside = (e: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleResultClick = (result: SearchResultItem) => {
    onSelectResult(result);
    setIsOpen(false);
    setQuery('');
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onOpenGalleryWithQuery(query.trim());
      setIsOpen(false);
      setQuery('');
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Trigger button when collapsed */}
      {!isOpen ? (
        <button
          id="header-search-open-btn"
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-3 py-2 rounded-md text-xs text-[#57473B] hover:text-[#A8763E] bg-[#F2ECE1] hover:bg-[#EFE7DA] border border-[#E2D9C8] hover:border-[#A8763E]/60 transition-all duration-200"
          title="Search door types or carving styles"
          aria-label="Search door types or carving styles"
        >
          <Search className="w-3.5 h-3.5 text-[#A8763E]" />
          <span className="hidden sm:inline text-[11px] uppercase tracking-wider text-[#57473B] font-semibold">
            Search Styles...
          </span>
        </button>
      ) : (
        /* Active Search Box Overlay in Header */
        <div className="flex items-center">
          <form
            onSubmit={handleSearchSubmit}
            className="flex items-center bg-white border border-[#A8763E] rounded-md px-2.5 py-1.5 shadow-xl w-56 sm:w-72 md:w-80 transition-all"
          >
            <Search className="w-4 h-4 text-[#A8763E] flex-shrink-0 mr-2" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search doors, carving, teak, lotus..."
              className="bg-transparent border-none outline-none text-xs text-[#231812] placeholder-[#8A7A6E] w-full"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="text-[#8A7A6E] hover:text-[#231812] p-0.5 mr-1"
              >
                <X className="w-3 h-3" />
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                setIsOpen(false);
                setQuery('');
              }}
              className="text-[#8A7A6E] hover:text-[#A8763E] text-xs px-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}

      {/* Floating Dropdown Results Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white border border-[#E2D9C8] rounded-xl shadow-2xl z-50 overflow-hidden text-left">
          
          {/* Quick Tag Pills */}
          <div className="p-3 bg-[#FAF7F2] border-b border-[#E2D9C8]">
            <div className="text-[10px] uppercase tracking-widest text-[#A8763E] font-bold mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3 h-3" />
              <span>Quick Categories & Carving Styles:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {quickTags.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setQuery(tag)}
                  className="px-2 py-0.5 rounded text-[10px] bg-white hover:bg-[#F2ECE1] text-[#57473B] hover:text-[#A8763E] border border-[#E2D9C8] hover:border-[#A8763E]/60 transition-colors font-medium"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Results List */}
          <div className="max-h-80 overflow-y-auto divide-y divide-[#E2D9C8]">
            {trimmed && searchResults.length === 0 && (
              <div className="p-6 text-center text-[#57473B] text-xs">
                <p>No exact door or carving matches found for "{query}".</p>
                <button
                  onClick={() => {
                    onOpenGalleryWithQuery(query);
                    setIsOpen(false);
                  }}
                  className="mt-3 inline-flex items-center gap-1 text-[#A8763E] hover:underline font-semibold"
                >
                  <span>Explore full gallery for "{query}"</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            )}

            {searchResults.map((item) => (
              <button
                key={item.id}
                onClick={() => handleResultClick(item)}
                className="w-full p-3 flex items-start gap-3 hover:bg-[#FAF7F2] transition-colors text-left group"
              >
                {/* Thumbnail Image */}
                <div className="w-12 h-12 rounded bg-[#FAF7F2] border border-[#E2D9C8] group-hover:border-[#A8763E] overflow-hidden flex-shrink-0">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Details */}
                <div className="flex-grow min-w-0">
                  <div className="flex items-center justify-between gap-1 mb-0.5">
                    <span className="text-[10px] uppercase font-mono tracking-wider text-[#A8763E] font-semibold truncate">
                      {item.category}
                    </span>
                    <span className="text-[9px] text-[#8A7A6E] uppercase tracking-widest flex items-center gap-0.5">
                      <Eye className="w-2.5 h-2.5" /> View
                    </span>
                  </div>
                  <h4 className="font-serif-luxury text-xs font-bold text-[#231812] group-hover:text-[#A8763E] transition-colors truncate">
                    {item.title}
                  </h4>
                  {item.woodType && (
                    <p className="text-[10px] text-[#57473B] truncate mt-0.5">
                      Timber: {item.woodType}
                    </p>
                  )}
                  {item.carvingStyle && (
                    <p className="text-[10px] text-[#8A7A6E] truncate">
                      Style: {item.carvingStyle}
                    </p>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Bottom helper info */}
          {query.trim() && (
            <div className="p-2.5 bg-[#FAF7F2] border-t border-[#E2D9C8] text-center">
              <button
                onClick={() => {
                  onOpenGalleryWithQuery(query);
                  setIsOpen(false);
                }}
                className="text-[11px] text-[#A8763E] hover:text-[#231812] font-semibold uppercase tracking-wider inline-flex items-center gap-1.5 transition-colors"
              >
                <span>View all results in Gallery</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
