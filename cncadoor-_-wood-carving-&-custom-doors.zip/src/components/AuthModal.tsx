import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useStore } from '../context/StoreContext';
import { 
  X, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  User, 
  Mail, 
  Phone, 
  Lock,
  Eye,
  EyeOff,
  Shield
} from 'lucide-react';

interface AuthModalProps {
  onDirectQuote?: (itemTitle?: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onDirectQuote }) => {
  const { 
    isAuthModalOpen, 
    closeAuthModal, 
    authPromptReason, 
    pendingActionItem, 
    login 
  } = useAuth();
  const { setAdminDualViewMode } = useStore();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [phone, setPhone] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Dynamically check if the user is typing the admin email
  const isAdminEmail = email.trim().toLowerCase() === 'adoorcnc@gmail.com';

  useEffect(() => {
    if (isAuthModalOpen) {
      setError(null);
      setPassword('');
    }
  }, [isAuthModalOpen]);

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();

    if (!cleanEmail || !cleanEmail.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }

    // When adoorcnc@gmail.com is entered, password is required to log in as admin
    if (cleanEmail === 'adoorcnc@gmail.com') {
      if (!password.trim()) {
        setError('Password is required to log in as admin.');
        return;
      }

      const res = login({
        name: cleanName || 'Workshop Owner',
        email: 'adoorcnc@gmail.com',
        password: password.trim(),
        role: 'Owner / Admin',
      });

      if (!res.success) {
        setError(res.error || 'Incorrect password for admin account. Please try again.');
        return;
      }

      setAdminDualViewMode('split');
      closeAuthModal();
      return;
    }

    // Standard client flow (no password required)
    if (!cleanName) {
      setError('Please provide your name.');
      return;
    }

    const res = login({
      name: cleanName,
      email: email.trim(),
      phone: phone.trim() || undefined,
      role: 'Client / Homeowner',
    });

    if (!res.success) {
      setError(res.error || 'Unable to sign in. Please try again.');
      return;
    }

    closeAuthModal();
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn text-[#231812]"
      onClick={closeAuthModal}
    >
      <div 
        className="relative max-w-lg w-full my-8 bg-white border border-[#E8E1D5] rounded-2xl overflow-hidden shadow-2xl animate-scaleUp text-[#231812]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header bar */}
        <div className="bg-[#FAF7F2] border-b border-[#E8E1D5] px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white border border-[#A8763E]/40 flex items-center justify-center text-[#A8763E] font-serif-luxury font-bold text-sm shadow-xs">
              C
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-[#A8763E] font-semibold">
                CNCADOOR Woodcraft
              </div>
              <h3 className="font-serif-luxury text-lg font-normal text-[#231812] leading-tight">
                {isAdminEmail ? 'Admin Sign In' : 'Sign In'}
              </h3>
            </div>
          </div>

          <button
            onClick={closeAuthModal}
            className="w-8 h-8 rounded-full bg-white hover:bg-[#FAF7F2] text-[#57473B] hover:text-[#231812] flex items-center justify-center transition-colors border border-[#E2D9C8] shadow-xs cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Dynamic prompt reason banner */}
        <div className="px-6 py-3.5 bg-[#FAF5EE] border-b border-[#E8E1D5] text-xs text-[#57473B] flex items-start gap-2.5">
          <Sparkles className="w-4 h-4 text-[#A8763E] flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="leading-relaxed font-light">
              {authPromptReason || 'Sign in to save your preferred door designs, track quotation requests, and receive priority craftsmanship assistance.'}
            </p>
            {pendingActionItem && (
              <div className="mt-2 flex items-center gap-2 p-1.5 rounded-lg bg-white border border-[#E2D9C8] text-[11px] text-[#231812] font-medium shadow-xs">
                <img 
                  src={pendingActionItem.imageUrl} 
                  alt={pendingActionItem.title} 
                  className="w-8 h-8 rounded object-cover" 
                  referrerPolicy="no-referrer"
                />
                <span className="truncate">Selected: <strong>{pendingActionItem.title}</strong></span>
              </div>
            )}
          </div>
        </div>

        {/* Error Notification */}
        {error && (
          <div className="mx-6 mt-4 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 leading-relaxed">
            {error}
          </div>
        )}

        {/* Unified Form Section */}
        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Email Field - checked in real time */}
            <div>
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-1.5">
                Email Address <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#8A7A6E] absolute left-3.5 top-3" />
                <input
                  type="email"
                  required
                  placeholder="e.g. yourname@gmail.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError(null);
                  }}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#E2D9C8] focus:border-[#A8763E] rounded-xl text-xs text-[#231812] placeholder-[#9E958A] focus:outline-none focus:ring-1 focus:ring-[#A8763E]/30"
                />
              </div>
            </div>

            {/* If admin email is entered, securely prompt for password */}
            {isAdminEmail ? (
              <div className="space-y-4 animate-fadeIn">
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200/80 flex items-center gap-2.5 text-xs text-amber-900">
                  <Shield className="w-4 h-4 text-amber-700 flex-shrink-0" />
                  <span>Admin account detected. Enter password to log in as administrator.</span>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-1.5">
                    Password <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#A8763E] absolute left-3.5 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      autoFocus
                      placeholder="Enter password"
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        setError(null);
                      }}
                      className="w-full pl-10 pr-10 py-2.5 bg-white border border-[#E2D9C8] focus:border-[#A8763E] rounded-xl text-xs text-[#231812] placeholder-[#9E958A] focus:outline-none focus:ring-1 focus:ring-[#A8763E]/30"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-[#7A6E63] hover:text-[#231812] cursor-pointer"
                      tabIndex={-1}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* Regular client fields (no password needed) */
              <div className="space-y-4 animate-fadeIn">
                <div>
                  <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-1.5">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-[#8A7A6E] absolute left-3.5 top-3" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Radhakrishnan Nair"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#E2D9C8] focus:border-[#A8763E] rounded-xl text-xs text-[#231812] placeholder-[#9E958A] focus:outline-none focus:ring-1 focus:ring-[#A8763E]/30"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider font-semibold text-[#A8763E] mb-1.5">
                    Phone / WhatsApp (Optional)
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-[#8A7A6E] absolute left-3.5 top-3" />
                    <input
                      type="tel"
                      placeholder="e.g. 9847012345"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#E2D9C8] focus:border-[#A8763E] rounded-xl text-xs text-[#231812] placeholder-[#9E958A] focus:outline-none focus:ring-1 focus:ring-[#A8763E]/30"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              id="submit-auth-btn"
              type="submit"
              className="w-full py-3 rounded-xl text-xs uppercase tracking-widest font-bold bg-[#A8763E] text-white hover:bg-[#91632F] shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              {isAdminEmail ? (
                <>
                  <Lock className="w-3.5 h-3.5" />
                  <span>Sign In as Admin</span>
                </>
              ) : (
                <>
                  <span>Sign In</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>

            {!isAdminEmail && (
              <p className="text-[11px] text-center text-[#7A6E63] font-light">
                No password required for client accounts.
              </p>
            )}
          </form>

          {/* Benefits summary & Guest dismissal */}
          <div className="mt-6 pt-4 border-t border-[#E8E1D5] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-1.5 text-[#57473B]">
              <ShieldCheck className="w-4 h-4 text-[#A8763E]" />
              <span>Direct workshop privacy guarantee</span>
            </div>

            <button
              onClick={() => {
                closeAuthModal();
                if (pendingActionItem && onDirectQuote) {
                  onDirectQuote(pendingActionItem.title);
                }
              }}
              className="text-[#7A6E63] hover:text-[#231812] underline text-[11px] font-medium cursor-pointer"
            >
              Continue as Guest →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
