import React, { useState, useEffect } from 'react';
import { GALLERY_ITEMS } from '../data/config';
import { GalleryFilter, GalleryItem } from '../types';
import { Maximize2, X, ArrowRight, Search, Heart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface GalleryProps {
  onRequestQuoteWithItem?: (title: string) => void;
  searchQuery?: string;
  onClearSearch?: () => void;
  highlightedItemId?: string | null;
}

export const Gallery: React.FC<GalleryProps> = ({
  onRequestQuoteWithItem,
  searchQuery = '',
  onClearSearch,
  highlightedItemId = null,
}) => {
  const { toggleSaveItem, isItemSaved } = useAuth();
  const [activeFilter, setActiveFilter] = useState<GalleryFilter>('ALL');
  const [activeLightboxItem, setActiveLightboxItem] = useState<GalleryItem | null>(null);

  const filters: GalleryFilter[] = ['ALL', 'DOORS', 'CARVING', 'DETAILS', 'COMPLETED WORK'];

  useEffect(() => {
    if (highlightedItemId) {
      const cleanId = highlightedItemId.replace('gallery-', '');
      const found = GALLERY_ITEMS.find((item) => item.id === cleanId || item.id === highlightedItemId);
      if (found) {
        setActiveLightboxItem(found);
      }
    }
  }, [highlightedItemId]);

  const filteredItems = GALLERY_ITEMS.filter((item) => {
    const matchesFilter = activeFilter === 'ALL' || item.category === activeFilter;
    if (!matchesFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const titleMatch = item.title.toLowerCase().includes(q);
      const descMatch = item.description?.toLowerCase().includes(q) ?? false;
      const woodMatch = item.woodType?.toLowerCase().includes(q) ?? false;
      const categoryMatch = item.category.toLowerCase().includes(q);
      return titleMatch || descMatch || woodMatch || categoryMatch;
    }

    return true;
  });

  return (
    <section id="gallery-section" className="py-20 bg-white text-[#231812] relative border-b border-[#E8E1D5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs uppercase tracking-[0.22em] text-[#A8763E] font-bold mb-3">
            Visual Portfolio
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-normal text-[#231812] mb-4">
            Craftsmanship Gallery
          </h2>
          <div className="w-16 h-[2px] bg-[#A8763E] mx-auto mb-4" />
          <p className="text-[#57473B] text-sm sm:text-base font-light leading-relaxed">
            Examine our high-definition wood textures, deep-relief carving angles, ornamental door stiles, and completed site installations.
          </p>

          {/* Active Search Query Feedback Banner */}
          {searchQuery.trim() && (
            <div className="mt-6 inline-flex items-center gap-3 px-4 py-2 rounded-full bg-[#FAF7F2] border border-[#E2D9C8] text-xs shadow-sm">
              <Search className="w-3.5 h-3.5 text-[#A8763E]" />
              <span className="text-[#57473B]">
                Showing results for: <strong className="text-[#A8763E]">"{searchQuery}"</strong> ({filteredItems.length} found)
              </span>
              {onClearSearch && (
                <button
                  onClick={onClearSearch}
                  className="ml-2 text-[#7A6E63] hover:text-[#231812] bg-white hover:bg-[#F2EAE0] rounded-full p-1 transition-colors border border-[#E2D9C8]"
                  title="Clear search filter"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {filters.map((filter) => {
            const isActive = activeFilter === filter;
            return (
              <button
                key={filter}
                id={`gallery-filter-${filter.replace(/\s+/g, '-').toLowerCase()}`}
                onClick={() => setActiveFilter(filter)}
                className={`px-5 py-2 rounded-full text-xs uppercase tracking-widest font-semibold transition-all ${
                  isActive
                    ? 'bg-[#A8763E] text-white font-bold shadow-md scale-105'
                    : 'bg-[#FAF7F2] text-[#57473B] hover:text-[#231812] hover:bg-[#F2EAE0] border border-[#E2D9C8]'
                }`}
              >
                {filter}
              </button>
            );
          })}
        </div>

        {/* Masonry / Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => {
            return (
              <div
                key={item.id}
                id={`gallery-item-${item.id}`}
                onClick={() => setActiveLightboxItem(item)}
                className="group relative rounded-xl overflow-hidden bg-white border border-[#E8E1D5] hover:border-[#A8763E] cursor-pointer shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-end"
              >
                {/* Image */}
                <div className="aspect-[4/3] overflow-hidden bg-[#FAF7F2]">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Dark Hover Gradient & Meta */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent opacity-75 group-hover:opacity-90 transition-opacity" />

                {/* Save Heart Button */}
                <button
                  id={`save-gallery-${item.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleSaveItem({
                      id: item.id,
                      title: item.title,
                      category: item.category,
                      imageUrl: item.imageUrl,
                      type: 'gallery',
                      savedAt: new Date().toISOString(),
                    }, true);
                  }}
                  className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm border border-[#E2D9C8] hover:border-[#A8763E] flex items-center justify-center text-[#57473B] hover:text-[#A8763E] transition-all z-10 shadow-sm"
                  title={isItemSaved(item.id) ? 'Saved in Shortlist' : 'Save to Shortlist'}
                  aria-label="Save gallery item"
                >
                  <Heart className={`w-3.5 h-3.5 ${isItemSaved(item.id) ? 'fill-[#A8763E] text-[#A8763E]' : ''}`} />
                </button>

                {/* Content Overlay */}
                <div className="absolute bottom-0 inset-x-0 p-5 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-[10px] uppercase tracking-widest font-mono text-[#A8763E] bg-white/90 px-2 py-0.5 rounded border border-[#E2D9C8] font-medium shadow-sm">
                      {item.category}
                    </span>
                    <div className="w-8 h-8 rounded-full bg-white/90 border border-[#E2D9C8] flex items-center justify-center text-[#231812] group-hover:bg-[#A8763E] group-hover:text-white transition-colors shadow-sm">
                      <Maximize2 className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  <h3 className="font-serif-luxury text-base font-medium text-white leading-tight">
                    {item.title}
                  </h3>
                  
                  {item.woodType && (
                    <p className="text-[11px] text-[#E8E1D5] mt-1 font-light">
                      {item.woodType}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Lightbox Modal */}
        {activeLightboxItem && (
          <div
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setActiveLightboxItem(null)}
          >
            <div
              className="relative max-w-4xl w-full bg-white border border-[#E8E1D5] rounded-2xl overflow-hidden shadow-2xl animate-fadeIn text-[#231812]"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close button */}
              <button
                onClick={() => setActiveLightboxItem(null)}
                className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-white/90 text-[#231812] border border-[#E2D9C8] flex items-center justify-center hover:bg-[#A8763E] hover:text-white transition-colors shadow-sm"
                aria-label="Close Lightbox"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Large Image Frame */}
              <div className="relative max-h-[65vh] overflow-hidden bg-[#FAF7F2] flex items-center justify-center">
                <img
                  src={activeLightboxItem.imageUrl}
                  alt={activeLightboxItem.title}
                  className="max-h-[65vh] w-auto object-contain mx-auto"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Lightbox Details Bar */}
              <div className="p-6 bg-white border-t border-[#E8E1D5] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs uppercase tracking-widest text-[#A8763E] font-semibold block mb-1">
                    {activeLightboxItem.category} {activeLightboxItem.woodType && `• ${activeLightboxItem.woodType}`}
                  </span>
                  <h3 className="font-serif-luxury text-xl sm:text-2xl font-normal text-[#231812]">
                    {activeLightboxItem.title}
                  </h3>
                  {activeLightboxItem.description && (
                    <p className="text-xs sm:text-sm text-[#57473B] mt-1 max-w-xl font-light">
                      {activeLightboxItem.description}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      const item = activeLightboxItem;
                      toggleSaveItem({
                        id: item.id,
                        title: item.title,
                        category: item.category,
                        imageUrl: item.imageUrl,
                        type: 'gallery',
                        savedAt: new Date().toISOString(),
                      }, true);
                    }}
                    className={`px-4 py-2.5 rounded-lg text-xs font-semibold border transition-all flex items-center gap-1.5 ${
                      isItemSaved(activeLightboxItem.id)
                        ? 'bg-[#FAF5EE] text-[#A8763E] border-[#A8763E]'
                        : 'bg-white text-[#57473B] border-[#D5CBC0] hover:border-[#A8763E]'
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${isItemSaved(activeLightboxItem.id) ? 'fill-[#A8763E] text-[#A8763E]' : ''}`} />
                    <span>{isItemSaved(activeLightboxItem.id) ? 'Saved' : 'Save to Shortlist'}</span>
                  </button>

                  <button
                    onClick={() => {
                      const itemTitle = activeLightboxItem.title;
                      setActiveLightboxItem(null);
                      if (onRequestQuoteWithItem) {
                        onRequestQuoteWithItem(itemTitle);
                      }
                    }}
                    className="px-6 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold bg-[#A8763E] hover:bg-[#91632F] text-white shadow-md flex items-center gap-2 whitespace-nowrap transition-colors"
                  >
                    <span>Inquire This Design</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
