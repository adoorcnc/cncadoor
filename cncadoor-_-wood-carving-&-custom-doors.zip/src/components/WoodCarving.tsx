import React from 'react';
import { CARVING_PATTERNS } from '../data/config';
import { Sparkles, CheckCircle2, ArrowRight, Heart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface WoodCarvingProps {
  onRequestCustomCarving: () => void;
}

export const WoodCarving: React.FC<WoodCarvingProps> = ({ onRequestCustomCarving }) => {
  const { toggleSaveItem, isItemSaved } = useAuth();
  return (
    <section id="wood-carving-section" className="py-20 bg-white text-[#231812] relative border-b border-[#E8E1D5]">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Main Hero Header for Wood Carving */}
        <div className="text-center max-w-4xl mx-auto mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF7F2] border border-[#E2D9C8] text-xs uppercase tracking-[0.22em] text-[#A8763E] font-bold mb-4 shadow-sm">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Master Artistry & Relief Sculpting</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-5xl md:text-6xl font-normal text-[#231812] tracking-tight mb-6">
            The Art of Wood Carving
          </h2>
          <div className="w-20 h-[2px] bg-[#A8763E] mx-auto mb-6" />
          <p className="text-[#57473B] text-base sm:text-lg max-w-3xl mx-auto font-light leading-relaxed">
            Every carving begins with an architectural idea and becomes a timeless heirloom through patience, precision CNC tooling, and master hand-detailing.
          </p>
        </div>

        {/* 4 Carving Pattern Categories Detail Grid */}
        <div className="space-y-16 lg:space-y-24">
          {CARVING_PATTERNS.map((pattern, index) => {
            const isReversed = index % 2 === 1;
            return (
              <div 
                key={pattern.id}
                id={`carving-category-${pattern.id}`}
                className={`flex flex-col ${isReversed ? 'lg:flex-row-reverse' : 'lg:flex-row'} items-center gap-8 lg:gap-14 bg-[#FAF7F2] border border-[#E8E1D5] rounded-2xl p-6 sm:p-8 lg:p-10 shadow-sm hover:border-[#A8763E] transition-all`}
              >
                {/* Visual Image Showcase */}
                <div className="w-full lg:w-1/2">
                  <div className="relative rounded-xl overflow-hidden border border-[#E2D9C8] shadow-sm aspect-[4/3] group bg-white">
                    <img
                      src={pattern.imageUrl}
                      alt={pattern.title}
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                      loading="lazy"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm border border-[#E2D9C8] px-3 py-1 rounded text-xs font-mono uppercase tracking-widest text-[#A8763E] font-semibold shadow-sm">
                      Pattern Focus 0{index + 1}
                    </div>

                    <button
                      id={`save-pattern-${pattern.id}`}
                      onClick={() => toggleSaveItem({
                        id: pattern.id,
                        title: pattern.title,
                        category: pattern.category,
                        imageUrl: pattern.imageUrl,
                        type: 'carving',
                        savedAt: new Date().toISOString(),
                      }, true)}
                      className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/95 backdrop-blur-sm border border-[#E2D9C8] hover:border-[#A8763E] flex items-center justify-center text-[#57473B] hover:text-[#A8763E] transition-all shadow-sm z-10"
                      title={isItemSaved(pattern.id) ? 'Saved in Shortlist' : 'Save Motif to Shortlist'}
                      aria-label="Save motif to shortlist"
                    >
                      <Heart className={`w-4 h-4 ${isItemSaved(pattern.id) ? 'fill-[#A8763E] text-[#A8763E]' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Content Breakdown */}
                <div className="w-full lg:w-1/2 flex flex-col justify-center">
                  <span className="text-xs uppercase tracking-[0.2em] text-[#A8763E] font-bold mb-2">
                    {pattern.category}
                  </span>
                  <h3 className="font-serif-luxury text-2xl sm:text-3xl font-normal text-[#231812] mb-4">
                    {pattern.title}
                  </h3>
                  <p className="text-sm sm:text-base text-[#57473B] font-light leading-relaxed mb-6">
                    {pattern.description}
                  </p>

                  {/* Highlights Bullet List */}
                  <div className="space-y-2.5 mb-8">
                    {pattern.details.map((detail, dIdx) => (
                      <div key={dIdx} className="flex items-start gap-3 text-xs sm:text-sm text-[#42352B]">
                        <CheckCircle2 className="w-4 h-4 text-[#A8763E] flex-shrink-0 mt-0.5" />
                        <span className="font-light">{detail}</span>
                      </div>
                    ))}
                  </div>

                  {/* Request Button */}
                  <div>
                    <button
                      onClick={onRequestCustomCarving}
                      className="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-xs uppercase tracking-widest font-bold bg-[#A8763E] hover:bg-[#91632F] text-white transition-all shadow-sm"
                    >
                      <span>Inquire About {pattern.category}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Custom Carving Reference Notice Box */}
        <div className="mt-20 bg-gradient-to-r from-[#FAF7F2] via-[#F4EFE6] to-[#FAF7F2] border border-[#E2D9C8] rounded-2xl p-8 sm:p-12 text-center relative overflow-hidden shadow-sm">
          <div className="max-w-3xl mx-auto relative z-10">
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-normal text-[#231812] mb-3">
              Provide Your Own Reference or Custom Motif
            </h3>
            <p className="text-sm sm:text-base text-[#57473B] font-light leading-relaxed mb-8">
              Whether you have an architectural sketch, a heritage temple motif, or a modern digital vector, our woodcraft workshop will configure the precise carving depth, wood selection, and finishing.
            </p>
            <button
              onClick={onRequestCustomCarving}
              className="px-8 py-4 rounded-lg text-xs uppercase tracking-[0.22em] font-bold bg-[#A8763E] text-white hover:bg-[#91632F] shadow-md transition-all active:scale-95"
            >
              SEND YOUR DESIGN REFERENCE
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
