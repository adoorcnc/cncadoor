import React from 'react';
import { PROCESS_STEPS } from '../data/config';
import { Compass, TreePine, Sparkles, Gem, PackageCheck } from 'lucide-react';

export const CarvingProcess: React.FC = () => {
  const stepIcons = [Compass, TreePine, Sparkles, Gem, PackageCheck];

  return (
    <section className="py-20 bg-[#FAF7F2] relative overflow-hidden border-t border-[#E2D9C8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="text-xs uppercase tracking-[0.25em] text-[#A8763E] font-semibold mb-3">
            Step-by-Step Craftsmanship
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-bold text-[#231812] mb-4">
            Our Carving Process
          </h2>
          <div className="w-16 h-[2px] bg-[#A8763E] mx-auto mb-4" />
          <p className="text-[#57473B] text-sm sm:text-base leading-relaxed">
            From preliminary concepts to the finished architectural masterpiece, our systematic process ensures structural integrity and decorative excellence.
          </p>
        </div>

        {/* 5 Step Visual Timeline Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {PROCESS_STEPS.map((item, idx) => {
            const Icon = stepIcons[idx % stepIcons.length];
            return (
              <div
                key={item.step}
                id={`process-step-${item.step}`}
                className="bg-white border border-[#E2D9C8] rounded-xl p-6 flex flex-col justify-between hover:border-[#A8763E] transition-all duration-300 relative group shadow-sm hover:shadow-lg"
              >
                {/* Step Number Top Banner */}
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-[#E2D9C8]">
                  <span className="font-serif-luxury text-3xl font-bold text-[#A8763E] group-hover:scale-110 transition-transform inline-block">
                    {item.step}
                  </span>
                  <div className="w-10 h-10 rounded-full bg-[#FAF7F2] border border-[#E2D9C8] flex items-center justify-center text-[#A8763E] shadow-sm">
                    <Icon className="w-5 h-5" />
                  </div>
                </div>

                {/* Step Details */}
                <div>
                  <h3 className="font-serif-luxury text-lg font-bold text-[#231812] group-hover:text-[#A8763E] transition-colors mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs font-semibold text-[#A8763E] mb-3">
                    {item.description}
                  </p>
                  <p className="text-xs text-[#57473B] leading-relaxed">
                    {item.details}
                  </p>
                </div>

                {/* Bottom subtle indicator line */}
                <div className="mt-6 h-1 w-full bg-[#FAF7F2] rounded-full overflow-hidden">
                  <div className="h-full bg-[#E2D9C8] group-hover:bg-[#A8763E] transition-colors w-full" />
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

