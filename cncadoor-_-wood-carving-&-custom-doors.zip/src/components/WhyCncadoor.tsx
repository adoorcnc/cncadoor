import React from 'react';

export const WhyCncadoor: React.FC = () => {
  const pillars = [
    {
      title: 'QUALITY MATERIALS',
      description: 'We use only the best materials for long lasting durability.',
      icon: (
        <svg className="w-9 h-9 text-[#C59B4B] mx-auto mb-4" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M16 4l10 4v8c0 7-6 11-10 13-4-2-10-6-10-13V8l10-4z" stroke="currentColor" />
          <path d="M12 16l3 3 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
    },
    {
      title: 'EXPERT CRAFTSMANSHIP',
      description: 'Skilled craftsmen with years of experience and attention to detail.',
      icon: (
        <svg className="w-9 h-9 text-[#C59B4B] mx-auto mb-4" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M7 7l6 6M19 19l6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M10 4l3 3-7 7-3-3 7-7z" stroke="currentColor" />
          <path d="M22 16l6 6-4 4-6-6 4-4z" stroke="currentColor" />
          <line x1="14" y1="18" x2="18" y2="14" stroke="currentColor" strokeWidth="2" />
        </svg>
      )
    },
    {
      title: 'CUSTOM SOLUTIONS',
      description: 'Every piece is customized to match your space and requirements.',
      icon: (
        <svg className="w-9 h-9 text-[#C59B4B] mx-auto mb-4" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="5" y="5" width="22" height="22" rx="2" stroke="currentColor" />
          <line x1="5" y1="13" x2="27" y2="13" stroke="currentColor" strokeDasharray="2 2" />
          <line x1="15" y1="5" x2="15" y2="27" stroke="currentColor" strokeDasharray="2 2" />
          <circle cx="10" cy="9" r="1.5" fill="currentColor" />
          <circle cx="21" cy="20" r="1.5" fill="currentColor" />
        </svg>
      )
    },
    {
      title: 'DIRECT WORKSHOP PICKUP',
      description: 'Finished products are collected directly from our Adoor workshop. No delivery service is provided.',
      icon: (
        <svg className="w-9 h-9 text-[#C59B4B] mx-auto mb-4" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M4 10l12-6 12 6v14l-12 6-12-6V10z" stroke="currentColor" />
          <path d="M12 16l3 3 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
    }
  ];

  return (
    <section className="py-20 bg-[#FAF7F2] relative border-b border-[#E8E1D5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="text-xs uppercase tracking-[0.2em] text-[#C59B4B] font-bold mb-2">
            WHY CHOOSE US
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-normal text-[#1A1816]">
            Quality You Can Trust
          </h2>
        </div>

        {/* 4 Columns with Clean Vertical Dividers */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-0 lg:divide-x lg:divide-[#E8E1D5]">
          {pillars.map((item, index) => (
            <div
              key={item.title}
              id={`why-pillar-${index}`}
              className="text-center px-6 py-4 flex flex-col items-center group"
            >
              <div className="transform group-hover:scale-110 transition-transform duration-300">
                {item.icon}
              </div>
              <h3 className="font-serif-luxury text-sm font-bold tracking-[0.14em] text-[#1E1915] group-hover:text-[#C59B4B] transition-colors mb-2 uppercase">
                {item.title}
              </h3>
              <p className="text-xs text-[#7A6E63] font-normal leading-relaxed max-w-[240px]">
                {item.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

