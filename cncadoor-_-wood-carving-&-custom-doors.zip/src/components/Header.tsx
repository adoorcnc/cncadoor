import React, { useState, useEffect } from 'react';
import { BUSINESS_CONFIG } from '../data/config';
import { Menu, X, Phone, MessageSquare, Compass, Sparkles, Search, Heart, User, LogIn, ChevronDown, LogOut, FileText, Shield, Package, Download, Columns } from 'lucide-react';
import { HeaderSearch, SearchResultItem } from './HeaderSearch';
import { useAuth } from '../context/AuthContext';
import { useStore } from '../context/StoreContext';
import { generateCatalogPdf } from '../utils/generateCatalogPdf';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenQuote: (initialDoorType?: string) => void;
  onSelectSearchResult?: (result: SearchResultItem) => void;
  onSearchInGallery?: (query: string) => void;
  onOpenAdmin?: () => void;
  onOpenCatalog?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenQuote,
  onSelectSearchResult,
  onSearchInGallery,
  onOpenAdmin,
  onOpenCatalog,
}) => {
  const { user, isAdmin, openAuthModal, openShortlistDrawer, logout } = useAuth();
  const { businessConfig, setIsAdminMode, setAdminDualViewMode } = useStore();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showCallDropdown, setShowCallDropdown] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);

  const totalSavedCount = user?.savedItems?.length || 0;

  useEffect(() => {
    const handleOutsideClick = () => {
      setShowProfileDropdown(false);
    };
    if (showProfileDropdown) {
      window.addEventListener('click', handleOutsideClick);
      return () => window.removeEventListener('click', handleOutsideClick);
    }
  }, [showProfileDropdown]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'HOME' },
    { id: 'doors', label: 'DOORS' },
    { id: 'carving', label: 'WOOD CARVING' },
    { id: 'custom-designs', label: 'CUSTOM DESIGNS' },
    { id: 'gallery', label: 'GALLERY' },
    { id: 'about', label: 'ABOUT US' },
    { id: 'contact', label: 'CONTACT' },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleWhatsAppDirect = () => {
    const encoded = encodeURIComponent(businessConfig.whatsappMessage);
    const phone = businessConfig.whatsapps[0] || '9876543210';
    window.open(`https://wa.me/91${phone}?text=${encoded}`, '_blank');
  };

  const handleSearchResultClick = (result: SearchResultItem) => {
    if (onSelectSearchResult) {
      onSelectSearchResult(result);
    }
  };

  const handleSearchInGallery = (query: string) => {
    if (onSearchInGallery) {
      onSearchInGallery(query);
    }
  };

  return (
    <div className="sticky top-0 z-50">
      {/* Top Announcement Bar (if active) */}
      {businessConfig.announcementActive && businessConfig.announcement && (
        <div className="bg-[#FAF5EE] text-[#57473B] text-[11px] sm:text-xs py-1.5 px-4 text-center border-b border-[#E2D9C8] flex items-center justify-center gap-2 font-medium tracking-wide">
          <Sparkles className="w-3.5 h-3.5 text-[#A8763E] flex-shrink-0 animate-pulse" />
          <span className="truncate">{businessConfig.announcement}</span>
          <button 
            onClick={() => handleNavClick('doors')}
            className="hidden sm:inline-block ml-2 text-[#A8763E] underline font-bold uppercase text-[10px] hover:text-[#231812]"
          >
            Explore Catalog
          </button>
        </div>
      )}

      <header 
        className={`transition-all duration-300 ${
          isScrolled 
            ? 'bg-white/95 backdrop-blur-md border-b border-[#E8E1D5] shadow-sm py-3' 
            : 'bg-white border-b border-[#E8E1D5] py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            
            {/* Exact Logo from Model Screenshot */}
            <div 
              id="brand-logo"
              onClick={() => handleNavClick('home')}
              className="cursor-pointer group flex items-center space-x-3"
            >
              {/* Geometric Gold Door Emblem */}
              <div className="w-10 h-10 border-2 border-[#A8763E] rounded-sm flex items-center justify-center p-1 relative shadow-sm group-hover:border-[#7A5328] transition-colors bg-[#FAF7F2]">
                <div className="w-5 h-7 border border-[#A8763E] rounded-t-xs flex items-center justify-end pr-0.5">
                  <div className="w-1 h-1 rounded-full bg-[#A8763E]" />
                </div>
              </div>

              <div>
                <div className="font-serif-luxury text-xl sm:text-2xl font-bold tracking-[0.12em] text-[#231812] group-hover:text-[#A8763E] transition-colors leading-none">
                  {businessConfig.name}
                </div>
                <div className="text-[9px] sm:text-[10px] tracking-[0.22em] uppercase text-[#7A6E63] font-medium mt-1">
                  {businessConfig.subtitle}
                </div>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-7">
              {navItems.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-link-${item.id}`}
                    onClick={() => handleNavClick(item.id)}
                    className={`text-xs font-semibold tracking-[0.14em] transition-all relative py-1 ${
                      isActive 
                        ? 'text-[#A8763E] font-bold' 
                        : 'text-[#57473B] hover:text-[#A8763E]'
                    }`}
                  >
                    {item.label}
                    {isActive && (
                      <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#A8763E] rounded-full" />
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Desktop Action Buttons */}
            <div className="hidden lg:flex items-center space-x-3">
              {/* Search */}
              <HeaderSearch
                onSelectResult={handleSearchResultClick}
                onOpenGalleryWithQuery={handleSearchInGallery}
              />

              {/* Shortlist */}
              <button
                id="header-shortlist-btn"
                onClick={openShortlistDrawer}
                title="Saved Shortlist"
                className="relative p-2 rounded-md text-[#57473B] hover:text-[#A8763E] hover:bg-[#FAF7F2] border border-transparent hover:border-[#E2D9C8] transition-all"
              >
                <Heart className={`w-4 h-4 ${totalSavedCount > 0 ? 'fill-[#A8763E] text-[#A8763E]' : ''}`} />
                {totalSavedCount > 0 && (
                  <span className="absolute -top-1 -right-1 text-[10px] font-bold bg-[#A8763E] text-white w-4 h-4 rounded-full flex items-center justify-center">
                    {totalSavedCount}
                  </span>
                )}
              </button>

              {/* Owner Admin Switch - ONLY visible to Admin */}
              {isAdmin && (
                <button
                  id="header-admin-btn"
                  onClick={() => {
                    if (onOpenAdmin) onOpenAdmin();
                    else setIsAdminMode(true);
                  }}
                  className="px-2.5 py-1.5 rounded-md text-[#A8763E] hover:text-[#231812] bg-[#FAF5EE] hover:bg-[#F4EFE6] border border-[#A8763E]/40 hover:border-[#A8763E] transition-all flex items-center gap-1.5 text-xs font-semibold shadow-sm"
                  title="Business Owner Admin Dashboard"
                >
                  <Shield className="w-3.5 h-3.5 text-[#A8763E]" />
                  <span className="hidden xl:inline">Admin</span>
                </button>
              )}

              {/* User Account / Profile */}
              <div className="relative">
                {user ? (
                  <button
                    id="header-profile-btn"
                    onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                    className="p-1 rounded-md text-[#57473B] hover:text-[#231812] hover:bg-[#FAF7F2] border border-[#E2D9C8] transition-all flex items-center gap-1.5 text-xs"
                    title={user.name}
                  >
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[11px] ${
                      isAdmin 
                        ? 'bg-[#FAF5EE] border border-[#A8763E] text-[#A8763E]' 
                        : 'bg-[#FAF7F2] border border-[#E2D9C8] text-[#57473B]'
                    }`}>
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <ChevronDown className="w-3 h-3 text-[#8A7A6E]" />
                  </button>
                ) : (
                  <button
                    id="header-signin-btn"
                    onClick={() => openAuthModal('Sign in to sync your shortlisted doors and access account features.')}
                    className="px-2.5 py-1.5 rounded-md text-[#57473B] hover:text-[#231812] hover:bg-[#FAF7F2] border border-[#E2D9C8] transition-all flex items-center gap-1 text-xs font-medium"
                    title="Sign In / Account"
                  >
                    <User className="w-3.5 h-3.5 text-[#A8763E]" />
                    <span className="hidden xl:inline">Sign In</span>
                  </button>
                )}

                {/* Profile Dropdown */}
                {showProfileDropdown && user && (
                  <div 
                    className="absolute right-0 mt-2 w-52 bg-white border border-[#E2D9C8] rounded-xl shadow-xl py-2 z-50 text-xs animate-fadeIn text-[#231812]"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="px-3 py-2 border-b border-[#E8E1D5]">
                      <div className="font-semibold text-[#231812] truncate">{user.name}</div>
                      <div className="text-[10px] text-[#7A6E63] truncate">{user.email || 'No email provided'}</div>
                      <div className="mt-1 inline-block text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider bg-[#FAF5EE] text-[#A8763E] border border-[#A8763E]/30">
                        {user.role || (isAdmin ? 'Owner / Admin' : 'Client')}
                      </div>
                    </div>

                    {isAdmin && (
                      <div className="py-1 border-b border-[#E8E1D5] mb-1 space-y-0.5">
                        <button
                          onClick={() => {
                            setShowProfileDropdown(false);
                            setAdminDualViewMode('split');
                          }}
                          className="w-full px-3 py-2 text-left text-[#231812] bg-[#FAF5EE] hover:bg-[#F2ECE1] flex items-center gap-2 font-bold text-xs rounded-md"
                          title="View Admin Panel and Storefront side-by-side"
                        >
                          <Columns className="w-3.5 h-3.5 text-[#A8763E]" />
                          <span>Both Sides (Split View)</span>
                        </button>

                        <button
                          onClick={() => {
                            setShowProfileDropdown(false);
                            setAdminDualViewMode('admin');
                          }}
                          className="w-full px-3 py-1.5 text-left text-[#A8763E] hover:bg-[#FAF7F2] flex items-center gap-2 font-medium text-xs rounded-md"
                        >
                          <Shield className="w-3.5 h-3.5 text-[#A8763E]" />
                          <span>Admin Dashboard</span>
                        </button>
                      </div>
                    )}

                    <button
                      onClick={() => {
                        setShowProfileDropdown(false);
                        openShortlistDrawer();
                      }}
                      className="w-full px-3 py-2 text-left text-[#57473B] hover:bg-[#FAF7F2] flex items-center gap-2"
                    >
                      <Heart className="w-3.5 h-3.5 text-[#A8763E]" />
                      <span>My Shortlist ({totalSavedCount})</span>
                    </button>

                    <div className="border-t border-[#E8E1D5] my-1" />

                    <button
                      onClick={() => {
                        setShowProfileDropdown(false);
                        logout();
                      }}
                      className="w-full px-3 py-2 text-left text-red-600 hover:bg-red-50 flex items-center gap-2"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Download PDF Catalog Button */}
              <button
                id="header-catalog-pdf-btn"
                onClick={() => {
                  if (onOpenCatalog) onOpenCatalog();
                  else generateCatalogPdf();
                }}
                className="hidden xl:inline-flex items-center gap-1.5 px-3 py-2 rounded-md text-[#57473B] hover:text-[#231812] hover:bg-[#FAF7F2] border border-[#E2D9C8] hover:border-[#A8763E] transition-all text-xs font-semibold shadow-xs group cursor-pointer"
                title="Download Door Collections PDF Catalog & Brochure"
              >
                <FileText className="w-3.5 h-3.5 text-[#A8763E] group-hover:scale-110 transition-transform" />
                <span>PDF Catalog</span>
                <Download className="w-3 h-3 text-[#A8763E]" />
              </button>

              {/* Primary GET A QUOTE CTA Button matching light luxury palette */}
              <button
                id="header-quote-cta"
                onClick={() => onOpenQuote()}
                className="px-5 py-2.5 rounded-md text-xs font-bold uppercase tracking-[0.14em] bg-[#A8763E] hover:bg-[#91632F] text-white transition-all shadow-sm active:scale-95 cursor-pointer"
              >
                GET A QUOTE
              </button>
            </div>

            {/* Mobile Actions */}
            <div className="flex items-center space-x-2 lg:hidden">
              <button
                id="mobile-shortlist-btn"
                onClick={openShortlistDrawer}
                className="p-2 rounded-md text-[#57473B] hover:text-[#A8763E] relative"
                aria-label="View shortlist"
              >
                <Heart className={`w-4 h-4 ${totalSavedCount > 0 ? 'fill-[#A8763E] text-[#A8763E]' : ''}`} />
                {totalSavedCount > 0 && (
                  <span className="absolute -top-1 -right-1 text-[9px] font-bold bg-[#A8763E] text-white w-4 h-4 rounded-full flex items-center justify-center">
                    {totalSavedCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => onOpenQuote()}
                className="px-3 py-1.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-[#A8763E] text-white shadow-sm"
              >
                QUOTE
              </button>

              <button
                id="mobile-menu-toggle"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-md text-[#231812] hover:text-[#A8763E] transition-colors"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

          </div>
        </div>

        {/* Mobile Drawer Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden fixed inset-x-0 top-[70px] bg-white border-b border-[#E8E1D5] p-6 shadow-2xl backdrop-blur-xl animate-fadeIn max-h-[85vh] overflow-y-auto text-[#231812]">
            <div className="flex flex-col space-y-3">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  id={`mobile-nav-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center justify-between text-left py-2.5 px-4 rounded-xl text-sm transition-colors ${
                    activeTab === item.id 
                      ? 'bg-[#FAF5EE] text-[#A8763E] font-bold border-l-4 border-[#A8763E]' 
                      : 'text-[#57473B] hover:bg-[#FAF7F2]'
                  }`}
                >
                  <span>{item.label}</span>
                  {activeTab === item.id && <Sparkles className="w-4 h-4 text-[#A8763E]" />}
                </button>
              ))}

              <div className="pt-4 border-t border-[#E8E1D5] flex flex-col gap-3">
                <button
                  id="mobile-drawer-quote-btn"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenQuote();
                  }}
                  className="w-full py-3 rounded-md text-center text-xs uppercase tracking-widest font-bold bg-[#A8763E] text-white shadow-md cursor-pointer"
                >
                  GET A QUOTE
                </button>

                {/* Mobile Download PDF Catalog Button */}
                <button
                  id="mobile-drawer-catalog-btn"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    if (onOpenCatalog) onOpenCatalog();
                    else generateCatalogPdf();
                  }}
                  className="w-full py-2.5 rounded-md text-center text-xs font-bold text-[#231812] bg-[#FAF5EE] hover:bg-[#F4EFE6] border border-[#A8763E]/40 flex items-center justify-center gap-2 transition-colors shadow-xs cursor-pointer"
                >
                  <FileText className="w-4 h-4 text-[#A8763E]" />
                  <span>Download PDF Catalog</span>
                  <Download className="w-3.5 h-3.5 text-[#A8763E]" />
                </button>

                {/* Mobile Admin Switch - ONLY visible to Admin */}
                {isAdmin && (
                  <div className="space-y-1.5">
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        setAdminDualViewMode('split');
                      }}
                      className="w-full py-2.5 rounded-md text-center text-xs font-extrabold text-[#231812] bg-[#D4AF37] hover:bg-[#C49F27] border border-[#B38F17] flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                    >
                      <Columns className="w-4 h-4 text-[#231812]" />
                      <span>View Both Sides (Split Screen)</span>
                    </button>

                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        setAdminDualViewMode('admin');
                      }}
                      className="w-full py-2 rounded-md text-center text-xs font-bold text-[#A8763E] bg-[#FAF5EE] hover:bg-[#F4EFE6] border border-[#A8763E]/30 flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Shield className="w-3.5 h-3.5 text-[#A8763E]" />
                      <span>Admin Panel Dashboard</span>
                    </button>
                  </div>
                )}

                {/* Mobile User Profile / Auth */}
                <div className="pt-2 border-t border-[#E8E1D5]">
                  {user ? (
                    <div className="p-3 bg-[#FAF7F2] rounded-xl border border-[#E2D9C8] flex items-center justify-between">
                      <div>
                        <div className="text-xs font-semibold text-[#231812]">{user.name}</div>
                        <div className="text-[10px] text-[#A8763E] uppercase font-bold tracking-wider">
                          {user.role || (isAdmin ? 'Owner / Admin' : 'Client')}
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setMobileMenuOpen(false);
                          logout();
                        }}
                        className="px-2.5 py-1 text-[11px] rounded bg-white text-red-600 border border-red-200 hover:bg-red-50 transition-colors"
                      >
                        Sign Out
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        openAuthModal('Sign in to access your saved shortlist across devices.');
                      }}
                      className="w-full py-2.5 rounded-md text-center text-xs font-semibold text-[#57473B] bg-[#FAF7F2] hover:bg-[#F4EFE6] border border-[#E2D9C8] flex items-center justify-center gap-1.5"
                    >
                      <User className="w-4 h-4 text-[#A8763E]" />
                      <span>Sign In / Register</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <a
                    href={`tel:${businessConfig.phones[0]}`}
                    className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-md bg-[#FAF7F2] border border-[#E2D9C8] text-xs text-[#231812] hover:bg-[#F4EFE6]"
                  >
                    <Phone className="w-3.5 h-3.5 text-[#A8763E]" />
                    <span>Call Us</span>
                  </a>
                  <button
                    onClick={handleWhatsAppDirect}
                    className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-md bg-[#25D366] text-white text-xs font-semibold hover:bg-[#1ebd5a]"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-white" />
                    <span>WhatsApp</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </header>
    </div>
  );
};

