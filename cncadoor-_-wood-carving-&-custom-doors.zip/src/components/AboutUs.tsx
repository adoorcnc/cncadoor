import React from 'react';
import { BUSINESS_CONFIG } from '../data/config';
import { Sparkles, MapPin, Shield, Compass, HeartHandshake } from 'lucide-react';

export const AboutUs: React.FC = () => {
  return (
    <section id="about-us-section" className="py-20 bg-[#121212] text-white relative border-b border-[#222222]">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase tracking-[0.22em] text-[#C59B4B] font-bold mb-3">
            Our Studio & Workshop
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-normal text-white mb-4">
            Crafting Wood With Purpose
          </h2>
          <div className="w-16 h-[2px] bg-[#C59B4B] mx-auto mb-4" />
          <p className="text-[#A89F95] text-sm sm:text-base font-light leading-relaxed">
            Located in Kerala, CNCADOOR is dedicated exclusively to the art of custom carved wooden doors, temple pooja doors, and decorative architectural wood carving.
          </p>
        </div>

        {/* 4 Architectural Fact-Grounded Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          
          {/* Who We Are */}
          <div className="bg-[#181818] border border-[#282828] rounded-2xl p-8 shadow-md flex flex-col justify-between hover:border-[#C59B4B]/60 transition-colors">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C59B4B] mb-5">
                <Compass className="w-5 h-5" />
              </div>
              <h3 className="font-serif-luxury text-2xl font-normal text-white mb-4">
                Who We Are
              </h3>
              <p className="text-sm text-[#A89F95] leading-relaxed font-light mb-4">
                CNCADOOR is an artisanal wood-carving, custom wooden doors, and architectural woodcraft studio. We specialize in transforming solid seasoned timber into grand entrance doors, temple pooja shutters, and intricate sculptural wall reliefs.
              </p>
              <p className="text-sm text-[#A89F95] leading-relaxed font-light">
                Our workshop operates with a dedicated focus on architectural integrity, craftsmanship, and bespoke commissions.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-[#2A2A2A] flex items-center gap-2 text-xs text-[#C59B4B] font-medium">
              <MapPin className="w-4 h-4 flex-shrink-0" />
              <span>Adoor, Pathanamthitta, Kerala</span>
            </div>
          </div>

          {/* What We Create */}
          <div className="bg-[#181818] border border-[#282828] rounded-2xl p-8 shadow-md flex flex-col justify-between hover:border-[#C59B4B]/60 transition-colors">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C59B4B] mb-5">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="font-serif-luxury text-2xl font-normal text-white mb-4">
                What We Create
              </h3>
              <p className="text-sm text-[#A89F95] leading-relaxed font-light mb-4">
                Our creations encompass hand-detailed and precision-carved solid wooden doors, main villa entrance shutters, temple mandir doors, and bespoke architectural wood carving panels.
              </p>
              <p className="text-sm text-[#A89F95] leading-relaxed font-light">
                Every piece is tailored to client-specified dimensions, carving depth requirements, and natural timber grains.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-[#2A2A2A] text-xs text-[#C59B4B] font-medium">
              <span>Focus: Doors • Carvings • Temple Motifs • Architectural Panels</span>
            </div>
          </div>

          {/* Our Approach */}
          <div className="bg-[#181818] border border-[#282828] rounded-2xl p-8 shadow-md flex flex-col justify-between hover:border-[#C59B4B]/60 transition-colors">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C59B4B] mb-5">
                <Shield className="w-5 h-5" />
              </div>
              <h3 className="font-serif-luxury text-2xl font-normal text-white mb-4">
                Our Approach
              </h3>
              <p className="text-sm text-[#A89F95] leading-relaxed font-light mb-4">
                We combine the mathematical accuracy of advanced 2D/3D CNC wood sculpting with traditional hand-finishing, meticulous sanding, and durable protective staining.
              </p>
              <p className="text-sm text-[#A89F95] leading-relaxed font-light">
                This balanced methodology ensures crisp geometric edges, deep sculptural relief depths, and long-lasting structural reliability.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-[#2A2A2A] text-xs text-[#C59B4B] font-medium">
              <span>Methodology: Precision Sculpting + Hand Detailing</span>
            </div>
          </div>

          {/* Our Commitment */}
          <div className="bg-[#181818] border border-[#282828] rounded-2xl p-8 shadow-md flex flex-col justify-between hover:border-[#C59B4B]/60 transition-colors">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C59B4B] mb-5">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <h3 className="font-serif-luxury text-2xl font-normal text-white mb-4">
                Our Commitment
              </h3>
              <p className="text-sm text-[#A89F95] leading-relaxed font-light mb-4">
                We are committed to building authentic wooden doors and precision wood carvings tailored to your architectural vision. We listen to your specifications, respect the natural behavior of timber, and maintain transparent communication throughout production.
              </p>
              <p className="text-sm text-[#A89F95] leading-relaxed font-light">
                We welcome custom client designs, sketches, and architectural drawings.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-[#2A2A2A] text-xs text-[#C59B4B] font-medium">
              <span>Customer-Centric Bespoke Woodcraft</span>
            </div>
          </div>

        </div>

        {/* Workshop Location Banner */}
        <div className="bg-[#181818] border border-[#282828] rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-md">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C59B4B] flex-shrink-0">
              <MapPin className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif-luxury text-lg font-medium text-white">
                CNCADOOR Workshop & Showroom
              </h4>
              <p className="text-xs text-[#A89F95] font-light mt-0.5">
                {BUSINESS_CONFIG.address}
              </p>
            </div>
          </div>

          <a
            href={BUSINESS_CONFIG.googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 rounded-lg text-xs uppercase tracking-widest font-bold bg-[#C59B4B] hover:bg-[#B38737] text-[#121212] transition-all whitespace-nowrap shadow-md"
          >
            Open in Google Maps
          </a>
        </div>

      </div>
    </section>
  );
};
