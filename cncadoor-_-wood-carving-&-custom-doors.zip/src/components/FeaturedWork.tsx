import React from 'react';
import { FEATURED_PROJECTS } from '../data/config';
import { MapPin } from 'lucide-react';

interface FeaturedWorkProps {
  onViewAllProjects: () => void;
  onRequestQuote: (projectTitle?: string) => void;
}

export const FeaturedWork: React.FC<FeaturedWorkProps> = ({ onViewAllProjects, onRequestQuote }) => {
  return (
    <section className="py-24 bg-white text-[#231812] relative border-b border-[#E8E1D5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Heading, Subtext, & CTA */}
          <div className="lg:col-span-4 flex flex-col items-start pr-0 lg:pr-6">
            <div className="text-xs uppercase tracking-[0.2em] text-[#A8763E] font-bold mb-3">
              FEATURED PROJECTS
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-normal text-[#231812] mb-5 leading-tight">
              Bringing Ideas <br className="hidden sm:inline" />To Life
            </h2>
            <p className="text-sm text-[#57473B] font-light leading-relaxed mb-8">
              A glimpse of our completed projects that showcase our passion for detail and quality.
            </p>
            <button
              id="view-all-projects-btn"
              onClick={onViewAllProjects}
              className="px-6 py-3 rounded-md text-xs uppercase tracking-[0.16em] font-bold bg-[#A8763E] hover:bg-[#91632F] text-white transition-all duration-300 shadow-md active:scale-95"
            >
              VIEW ALL PROJECTS
            </button>
          </div>

          {/* Right Column: 3 Cards Grid */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-5">
            {FEATURED_PROJECTS.map((project) => (
              <div
                key={project.id}
                id={`featured-card-${project.id}`}
                onClick={() => onRequestQuote(project.title)}
                className="group cursor-pointer flex flex-col bg-white rounded-lg overflow-hidden border border-[#E8E1D5] hover:border-[#A8763E] transition-all duration-300 shadow-sm hover:shadow-md"
              >
                {/* Image */}
                <div className="relative aspect-[4/5] overflow-hidden bg-[#FAF7F2]">
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Card Caption / Title & Location */}
                <div className="p-4 bg-white flex flex-col justify-between flex-grow border-t border-[#F0EBE1]">
                  <h3 className="font-serif-luxury text-sm font-semibold text-[#231812] group-hover:text-[#A8763E] transition-colors leading-snug">
                    {project.title}
                  </h3>
                  {project.location && (
                    <div className="flex items-center gap-1 text-[11px] text-[#7A6E63] mt-1.5 font-light">
                      <MapPin className="w-3 h-3 text-[#A8763E]" />
                      <span>{project.location}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
};

