import React from 'react';

interface SpecialtiesProps {
  onSelectCategory?: (type: string, category: string) => void;
  onSelectSpecialty?: (categoryOrType: string, category?: string) => void;
}

export const Specialties: React.FC<SpecialtiesProps> = ({ onSelectCategory, onSelectSpecialty }) => {
  const handleItemClick = (type: string, category: string) => {
    if (typeof onSelectCategory === 'function') {
      onSelectCategory(type, category);
    } else if (typeof onSelectSpecialty === 'function') {
      onSelectSpecialty(type, category);
    }
  };

  const items = [
    {
      id: 'main-doors',
      title: 'MAIN DOORS',
      subtitle: 'Strong. Secure. Beautiful.',
      type: 'doors',
      category: 'Main Entrance Doors',
      icon: (
        <svg className="w-8 h-8 text-[#C59B4B] mx-auto mb-3.5" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="7" y="4" width="18" height="24" rx="1" stroke="currentColor" />
          <circle cx="21" cy="16" r="1" fill="currentColor" />
          <line x1="5" y1="28" x2="27" y2="28" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      )
    },
    {
      id: 'wooden-doors',
      title: 'WOODEN DOORS',
      subtitle: 'Elegant designs in premium wood.',
      type: 'doors',
      category: 'Traditional Doors',
      icon: (
        <svg className="w-8 h-8 text-[#C59B4B] mx-auto mb-3.5" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="7" y="4" width="18" height="24" rx="1" stroke="currentColor" />
          <rect x="10" y="7" width="5" height="8" stroke="currentColor" />
          <rect x="17" y="7" width="5" height="8" stroke="currentColor" />
          <rect x="10" y="17" width="5" height="8" stroke="currentColor" />
          <rect x="17" y="17" width="5" height="8" stroke="currentColor" />
        </svg>
      )
    },
    {
      id: 'carved-doors',
      title: 'CARVED DOORS',
      subtitle: 'Artistic relief & CNC craftsmanship.',
      type: 'doors',
      category: 'Carved Doors',
      icon: (
        <svg className="w-8 h-8 text-[#C59B4B] mx-auto mb-3.5" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="7" y="4" width="18" height="24" rx="1" stroke="currentColor" />
          <path d="M12 10c2-1 6-1 8 0M12 16c2-1 6-1 8 0M12 22c2-1 6-1 8 0" stroke="currentColor" strokeLinecap="round" />
          <circle cx="21" cy="16" r="1" fill="currentColor" />
        </svg>
      )
    },
    {
      id: 'temple-pooja-doors',
      title: 'TEMPLE & POOJA DOORS',
      subtitle: 'Sacred motifs & divine woodcraft.',
      type: 'doors',
      category: 'Temple-Inspired Designs',
      icon: (
        <svg className="w-8 h-8 text-[#C59B4B] mx-auto mb-3.5" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M16 4l8 6v16a1 1 0 01-1 1H9a1 1 0 01-1-1V10l8-6z" stroke="currentColor" />
          <circle cx="16" cy="15" r="3" stroke="currentColor" />
          <path d="M12 21h8" stroke="currentColor" strokeLinecap="round" />
        </svg>
      )
    },
    {
      id: 'custom-designs',
      title: 'CUSTOM DESIGNS',
      subtitle: 'Your idea, our craftsmanship.',
      type: 'custom',
      category: 'Custom Designs',
      icon: (
        <svg className="w-8 h-8 text-[#C59B4B] mx-auto mb-3.5" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M16 4l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1 3-6z" stroke="currentColor" />
          <circle cx="16" cy="16" r="3" stroke="currentColor" />
        </svg>
      )
    }
  ];

  return (
    <section className="bg-[#FAF7F2] border-b border-[#E8E1D5] py-10 lg:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-0 lg:divide-x lg:divide-[#E8E1D5]">
          {items.map((item, index) => (
            <div
              key={item.id}
              id={`feature-col-${index}`}
              onClick={() => handleItemClick(item.type, item.category)}
              className="text-center px-4 py-3 cursor-pointer group hover:bg-[#F2ECE0] transition-colors rounded-lg lg:rounded-none"
            >
              <div className="transform group-hover:scale-110 transition-transform duration-300">
                {item.icon}
              </div>
              <h3 className="font-serif-luxury text-sm font-bold tracking-[0.14em] text-[#1E1915] group-hover:text-[#C59B4B] transition-colors mb-1 uppercase">
                {item.title}
              </h3>
              <p className="text-xs text-[#7A6E63] font-normal leading-snug max-w-[200px] mx-auto">
                {item.subtitle}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

