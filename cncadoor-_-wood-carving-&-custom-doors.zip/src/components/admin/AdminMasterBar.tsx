import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useStore } from '../../context/StoreContext';
import { AdminDualViewMode, AdminTab } from '../../types';
import { 
  Store, 
  LayoutDashboard, 
  Columns, 
  Package, 
  ShoppingBag, 
  PlusCircle, 
  Settings, 
  LogOut, 
  ChevronUp, 
  ChevronDown, 
  ShieldCheck,
  Sparkles,
  RefreshCw
} from 'lucide-react';

interface AdminMasterBarProps {
  onQuickAdminTab?: (tab: AdminTab) => void;
  splitLayout?: '50-50' | '60-40' | '40-60' | 'mobile';
  onSetSplitLayout?: (layout: '50-50' | '60-40' | '40-60' | 'mobile') => void;
}

export const AdminMasterBar: React.FC<AdminMasterBarProps> = ({
  onQuickAdminTab,
  splitLayout = '50-50',
  onSetSplitLayout
}) => {
  const { user, isAdmin, logout } = useAuth();
  const { 
    adminDualViewMode, 
    setAdminDualViewMode, 
    setActiveAdminTab,
    products, 
    enquiries,
    setEditingProduct,
    setDraftProductInCreation
  } = useStore();

  const [isCollapsed, setIsCollapsed] = useState(false);

  if (!isAdmin) return null;

  const newEnquiriesCount = enquiries.filter(e => e.status === 'New').length;
  const publishedCount = products.filter(p => p.status === 'published').length;

  const handleSwitchTab = (tab: AdminTab) => {
    setActiveAdminTab(tab);
    if (tab === 'add-product') {
      setEditingProduct(null);
      setDraftProductInCreation(null);
    }
    if (adminDualViewMode === 'storefront') {
      setAdminDualViewMode('admin');
    }
    if (onQuickAdminTab) {
      onQuickAdminTab(tab);
    }
  };

  // Compact floating pill when collapsed
  if (isCollapsed) {
    return (
      <aside 
        aria-label="Admin Bar Collapsed"
        className="fixed top-2 right-4 z-50 animate-fadeIn"
      >
        <div className="bg-[#24130A] text-[#FAF7F2] border border-[#A8763E]/60 rounded-full px-3.5 py-1.5 shadow-2xl flex items-center gap-2.5 text-xs">
          <div className="flex items-center gap-1.5 font-semibold text-[#D4AF37]">
            <ShieldCheck className="w-4 h-4" />
            <span className="text-[11px] uppercase tracking-wider">adoorcnc@gmail.com</span>
          </div>
          <span className="w-1 h-3 bg-white/20 rounded-full" />
          <span className="text-[11px] text-[#E0D5C7] capitalize">
            {adminDualViewMode === 'split' ? 'Both Sides (Split)' : adminDualViewMode === 'admin' ? 'Admin Panel' : 'Store Front'}
          </span>
          <button
            onClick={() => setIsCollapsed(false)}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="Expand CNCADOOR Master Bar"
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </aside>
    );
  }

  return (
    <header 
      id="admin-master-dual-bar"
      className="bg-[#201108] text-[#FAF7F2] border-b-2 border-[#A8763E] sticky top-0 z-50 shadow-xl transition-all select-none"
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-12 sm:h-13 flex items-center justify-between gap-2 text-xs">
        
        {/* Left: Admin Identifier & Status */}
        <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
          <div className="flex items-center gap-1.5">
            <div className="w-6 h-6 rounded-md bg-[#A8763E] text-white flex items-center justify-center font-serif-luxury font-bold text-xs shadow-xs">
              C
            </div>
            <div className="hidden lg:block">
              <span className="font-serif-luxury font-bold text-[#FAF7F2] tracking-wider text-xs">CNCADOOR</span>
              <span className="text-[10px] text-[#A8763E] font-semibold ml-1.5">WORKSHOP OWNER</span>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5 border border-[#A8763E]/40 text-[10px] text-[#E0D5C7]">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono truncate max-w-[130px] md:max-w-none">{user?.email || 'adoorcnc@gmail.com'}</span>
          </div>
        </div>

        {/* Center: The Core Dual-Mode View Switcher (Store Front / Both Sides / Admin Panel) */}
        <div className="flex items-center justify-center flex-1 max-w-lg">
          <div 
            className="bg-[#140A05] p-1 rounded-xl border border-[#A8763E]/40 flex items-center gap-1 shadow-inner"
            role="group"
            aria-label="View mode switcher"
          >
            {/* Option 1: Store Front */}
            <button
              id="admin-switch-storefront"
              onClick={() => setAdminDualViewMode('storefront')}
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg font-bold text-[11px] sm:text-xs transition-all cursor-pointer ${
                adminDualViewMode === 'storefront'
                  ? 'bg-[#A8763E] text-white shadow-md'
                  : 'text-[#C5B5A3] hover:text-white hover:bg-white/5'
              }`}
              title="View full customer-facing store front website"
            >
              <Store className="w-3.5 h-3.5" />
              <span>Store Front</span>
            </button>

            {/* Option 2: Both Sides (Split Screen View) */}
            <button
              id="admin-switch-split-both"
              onClick={() => setAdminDualViewMode('split')}
              className={`flex items-center gap-1.5 px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-lg font-bold text-[11px] sm:text-xs transition-all cursor-pointer ${
                adminDualViewMode === 'split'
                  ? 'bg-[#D4AF37] text-[#231812] shadow-md ring-1 ring-white/50'
                  : 'text-[#E0D5C7] hover:text-white hover:bg-white/5'
              }`}
              title="See both sides side-by-side simultaneously: Admin Panel + Live Store Front"
            >
              <Columns className="w-3.5 h-3.5 text-amber-700 font-bold" />
              <span className="font-extrabold">Both Sides</span>
              <span className="hidden md:inline text-[9px] px-1 py-0.2 rounded bg-black/20 font-mono">
                Split
              </span>
            </button>

            {/* Option 3: Admin Panel */}
            <button
              id="admin-switch-admin"
              onClick={() => setAdminDualViewMode('admin')}
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg font-bold text-[11px] sm:text-xs transition-all cursor-pointer ${
                adminDualViewMode === 'admin'
                  ? 'bg-[#A8763E] text-white shadow-md'
                  : 'text-[#C5B5A3] hover:text-white hover:bg-white/5'
              }`}
              title="Open full workshop admin management panel"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>Admin Panel</span>
            </button>
          </div>
        </div>

        {/* Right: Quick Admin Shortcuts & Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
          
          {/* Split layout selector (only when in split mode) */}
          {adminDualViewMode === 'split' && onSetSplitLayout && (
            <div className="hidden xl:flex items-center gap-1 bg-white/5 px-2 py-1 rounded-lg border border-white/10 text-[10px]">
              <span className="text-[#A8763E] font-semibold">Pane:</span>
              <button
                onClick={() => onSetSplitLayout('50-50')}
                className={`px-1.5 py-0.5 rounded cursor-pointer ${splitLayout === '50-50' ? 'bg-[#A8763E] text-white font-bold' : 'text-[#C5B5A3] hover:text-white'}`}
                title="50% Admin / 50% Storefront"
              >
                50:50
              </button>
              <button
                onClick={() => onSetSplitLayout('60-40')}
                className={`px-1.5 py-0.5 rounded cursor-pointer ${splitLayout === '60-40' ? 'bg-[#A8763E] text-white font-bold' : 'text-[#C5B5A3] hover:text-white'}`}
                title="Wide Admin / Compact Storefront"
              >
                Wide Admin
              </button>
              <button
                onClick={() => onSetSplitLayout('mobile')}
                className={`px-1.5 py-0.5 rounded cursor-pointer ${splitLayout === 'mobile' ? 'bg-[#A8763E] text-white font-bold' : 'text-[#C5B5A3] hover:text-white'}`}
                title="Admin + Mobile Phone Preview"
              >
                Mobile View
              </button>
            </div>
          )}

          {/* Quick Shortcuts (visible on larger screens) */}
          <div className="hidden lg:flex items-center gap-1">
            <button
              onClick={() => handleSwitchTab('products')}
              className="px-2 py-1 rounded-md bg-white/5 hover:bg-white/10 text-[#E0D5C7] hover:text-white transition-colors flex items-center gap-1 text-[11px] cursor-pointer"
              title="Manage Products"
            >
              <Package className="w-3 h-3 text-[#D4AF37]" />
              <span>Products ({publishedCount})</span>
            </button>

            <button
              onClick={() => handleSwitchTab('orders')}
              className="px-2 py-1 rounded-md bg-white/5 hover:bg-white/10 text-[#E0D5C7] hover:text-white transition-colors flex items-center gap-1 text-[11px] cursor-pointer"
              title="Customer Enquiries & Orders"
            >
              <ShoppingBag className="w-3 h-3 text-[#D4AF37]" />
              <span>Orders</span>
              {newEnquiriesCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-bold text-[9px] ml-0.5">
                  {newEnquiriesCount}
                </span>
              )}
            </button>

            <button
              onClick={() => handleSwitchTab('add-product')}
              className="px-2 py-1 rounded-md bg-[#A8763E]/30 hover:bg-[#A8763E]/50 text-[#FAF7F2] border border-[#A8763E]/50 transition-colors flex items-center gap-1 text-[11px] font-semibold cursor-pointer"
              title="Add New Door or Carving"
            >
              <PlusCircle className="w-3 h-3 text-[#D4AF37]" />
              <span>+ Add Door</span>
            </button>
          </div>

          {/* Logout / Exit */}
          <button
            onClick={() => {
              logout();
              setAdminDualViewMode('storefront');
            }}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-950/60 hover:text-rose-300 border border-white/10 transition-colors cursor-pointer text-[#C5B5A3]"
            title="Sign Out of Admin"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>

          {/* Minimize / Collapse */}
          <button
            onClick={() => setIsCollapsed(true)}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#C5B5A3] hover:text-white border border-white/10 transition-colors cursor-pointer"
            title="Minimize Bar"
          >
            <ChevronUp className="w-3.5 h-3.5" />
          </button>

        </div>

      </div>
    </header>
  );
};
