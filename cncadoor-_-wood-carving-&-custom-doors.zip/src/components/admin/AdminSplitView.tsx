import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { AdminMasterBar } from './AdminMasterBar';
import { AdminDashboard } from './AdminDashboard';
import { StorefrontLayout, StorefrontLayoutProps } from '../StorefrontLayout';
import { 
  Columns, 
  Store, 
  LayoutDashboard, 
  Maximize2, 
  RefreshCw, 
  Smartphone, 
  Monitor, 
  ExternalLink,
  ChevronRight,
  Sparkles,
  Layers
} from 'lucide-react';

interface AdminSplitViewProps {
  storefrontProps: Omit<StorefrontLayoutProps, 'isEmbeddedPreview'>;
}

export const AdminSplitView: React.FC<AdminSplitViewProps> = ({ storefrontProps }) => {
  const { 
    setAdminDualViewMode, 
    businessConfig, 
    products, 
    enquiries 
  } = useStore();

  const [splitLayout, setSplitLayout] = useState<'50-50' | '60-40' | '40-60' | 'mobile'>('50-50');
  const [storefrontKey, setStorefrontKey] = useState(0);
  const [mobileTabPreview, setMobileTabPreview] = useState<'admin' | 'storefront'>('admin');

  const handleRefreshStorefront = () => {
    setStorefrontKey(prev => prev + 1);
  };

  const getLeftWidthClass = () => {
    switch (splitLayout) {
      case '60-40':
        return 'md:w-3/5';
      case '40-60':
        return 'md:w-2/5';
      case 'mobile':
        return 'md:flex-1';
      case '50-50':
      default:
        return 'md:w-1/2';
    }
  };

  const getRightWidthClass = () => {
    switch (splitLayout) {
      case '60-40':
        return 'md:w-2/5';
      case '40-60':
        return 'md:w-3/5';
      case 'mobile':
        return 'md:w-[410px] xl:w-[440px]';
      case '50-50':
      default:
        return 'md:w-1/2';
    }
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-[#1A0E08] text-[#231812] overflow-hidden font-sans">
      
      {/* 1. Global Admin Master Dual Bar */}
      <AdminMasterBar 
        splitLayout={splitLayout} 
        onSetSplitLayout={setSplitLayout} 
      />

      {/* Mobile-only view toggle tab when viewport is too small for split */}
      <div className="md:hidden bg-[#24130A] border-b border-[#A8763E]/40 px-3 py-2 flex items-center justify-between">
        <span className="text-[11px] font-bold text-[#E0D5C7] flex items-center gap-1">
          <Columns className="w-3.5 h-3.5 text-[#D4AF37]" />
          Split Mode on Mobile
        </span>
        <div className="flex rounded-lg bg-black/40 p-0.5 border border-white/10 text-xs">
          <button
            onClick={() => setMobileTabPreview('admin')}
            className={`px-3 py-1 rounded-md font-bold text-[11px] cursor-pointer ${
              mobileTabPreview === 'admin' ? 'bg-[#A8763E] text-white' : 'text-[#C5B5A3]'
            }`}
          >
            Admin Panel
          </button>
          <button
            onClick={() => setMobileTabPreview('storefront')}
            className={`px-3 py-1 rounded-md font-bold text-[11px] cursor-pointer ${
              mobileTabPreview === 'storefront' ? 'bg-[#A8763E] text-white' : 'text-[#C5B5A3]'
            }`}
          >
            Store Front
          </button>
        </div>
      </div>

      {/* 2. Side-by-Side Dual Pane Container */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        
        {/* Left Pane: ADMIN PANEL */}
        <div 
          className={`h-full flex flex-col border-r border-[#A8763E]/40 bg-[#F7F4EE] transition-all overflow-hidden ${getLeftWidthClass()} ${
            mobileTabPreview === 'storefront' ? 'hidden md:flex' : 'flex'
          }`}
        >
          {/* Admin Pane Sub-header */}
          <div className="bg-[#2B1810] text-[#FAF7F2] px-4 py-2 border-b border-[#A8763E]/30 flex items-center justify-between text-xs flex-shrink-0">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span className="font-serif-luxury font-bold tracking-wider text-white text-xs">
                WORKSHOP ADMIN CONTROLS
              </span>
              <span className="text-[10px] text-[#C5B5A3] hidden sm:inline">
                (Changes reflect live on right pane)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setAdminDualViewMode('admin')}
                className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-[#FAF7F2] text-[10px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                title="Open Admin in Fullscreen"
              >
                <span>Fullscreen Admin</span>
                <Maximize2 className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Admin Dashboard Body */}
          <div className="flex-1 overflow-y-auto">
            <AdminDashboard 
              onReturnToPublicSite={() => setAdminDualViewMode('storefront')}
              isSplitPane={true}
            />
          </div>
        </div>

        {/* Right Pane: LIVE STORE FRONT PREVIEW */}
        <div 
          className={`h-full flex flex-col bg-[#FAF7F2] border-l border-[#E2D9C8] transition-all overflow-hidden shadow-2xl ${getRightWidthClass()} ${
            mobileTabPreview === 'admin' ? 'hidden md:flex' : 'flex'
          }`}
        >
          {/* Storefront Pane Sub-header */}
          <div className="bg-[#1F140E] text-[#FAF7F2] px-4 py-2 border-b border-[#A8763E]/40 flex items-center justify-between text-xs flex-shrink-0">
            <div className="flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-bold text-white tracking-wide text-xs flex items-center gap-1">
                <Store className="w-3.5 h-3.5 text-[#D4AF37]" />
                LIVE STORE FRONT
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-mono hidden sm:inline">
                ● Interactive Preview
              </span>
            </div>

            {/* Storefront Navigation Quick Bar in Split Mode */}
            <div className="flex items-center gap-2">
              {/* Quick page switcher */}
              <div className="hidden lg:flex items-center gap-1 bg-white/5 px-2 py-0.5 rounded-md border border-white/10 text-[10px]">
                <span className="text-[#C5B5A3]">Page:</span>
                <button
                  onClick={() => storefrontProps.setActiveTab('home')}
                  className={`px-1.5 py-0.5 rounded cursor-pointer ${storefrontProps.activeTab === 'home' ? 'bg-[#A8763E] text-white font-bold' : 'text-[#C5B5A3] hover:text-white'}`}
                >
                  Home
                </button>
                <button
                  onClick={() => storefrontProps.setActiveTab('doors')}
                  className={`px-1.5 py-0.5 rounded cursor-pointer ${storefrontProps.activeTab === 'doors' ? 'bg-[#A8763E] text-white font-bold' : 'text-[#C5B5A3] hover:text-white'}`}
                >
                  Doors
                </button>
                <button
                  onClick={() => storefrontProps.setActiveTab('ready-made')}
                  className={`px-1.5 py-0.5 rounded cursor-pointer ${storefrontProps.activeTab === 'ready-made' ? 'bg-[#A8763E] text-white font-bold' : 'text-[#C5B5A3] hover:text-white'}`}
                >
                  Ready-Made
                </button>
                <button
                  onClick={() => storefrontProps.setActiveTab('gallery')}
                  className={`px-1.5 py-0.5 rounded cursor-pointer ${storefrontProps.activeTab === 'gallery' ? 'bg-[#A8763E] text-white font-bold' : 'text-[#C5B5A3] hover:text-white'}`}
                >
                  Gallery
                </button>
              </div>

              {/* Refresh Preview */}
              <button
                onClick={handleRefreshStorefront}
                className="p-1 rounded bg-white/10 hover:bg-white/20 text-[#FAF7F2] transition-colors cursor-pointer"
                title="Refresh Storefront View"
              >
                <RefreshCw className="w-3 h-3" />
              </button>

              {/* Maximize to full Storefront */}
              <button
                onClick={() => setAdminDualViewMode('storefront')}
                className="px-2 py-1 rounded bg-[#A8763E] hover:bg-[#91632F] text-white text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                title="Open Storefront in Fullscreen"
              >
                <span>Fullscreen</span>
                <Maximize2 className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Storefront Live Body */}
          <div 
            key={storefrontKey}
            className={`flex-1 overflow-y-auto ${
              splitLayout === 'mobile' 
                ? 'p-4 bg-[#140A05] flex justify-center items-start' 
                : 'bg-[#FAF7F2]'
            }`}
          >
            {splitLayout === 'mobile' ? (
              // Mobile Mockup Frame
              <div className="w-full max-w-[390px] bg-[#FAF7F2] rounded-3xl border-4 border-[#3D2314] shadow-2xl overflow-hidden min-h-[780px]">
                <div className="bg-[#201108] text-white py-1 px-4 text-center text-[10px] font-mono border-b border-[#A8763E]/40 flex items-center justify-between">
                  <span>CNCADOOR Mobile</span>
                  <span className="w-12 h-3 bg-black/40 rounded-full mx-auto" />
                  <span>5G ●</span>
                </div>
                <div className="overflow-y-auto max-h-[740px]">
                  <StorefrontLayout 
                    {...storefrontProps} 
                    isEmbeddedPreview={true} 
                  />
                </div>
              </div>
            ) : (
              <StorefrontLayout 
                {...storefrontProps} 
                isEmbeddedPreview={true} 
              />
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
