import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { EnquiryRecord, EnquiryStatus } from '../../types';
import { 
  Sparkles, 
  Image as ImageIcon, 
  MessageSquare, 
  PhoneCall, 
  Calendar, 
  CheckCircle2, 
  Layers, 
  Ruler, 
  ExternalLink,
  Search,
  X
} from 'lucide-react';

export const AdminCustomRequests: React.FC = () => {
  const { enquiries, updateEnquiryStatus } = useStore();
  const [selectedRequest, setSelectedRequest] = useState<EnquiryRecord | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Filter custom requests (either marked as custom_request or containing custom keyword)
  const customRequests = enquiries.filter(e => 
    e.type === 'custom_request' || 
    e.productTitle.toLowerCase().includes('custom') ||
    e.requirement.toLowerCase().includes('custom')
  ).filter(e => 
    e.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.phone.includes(searchQuery) ||
    e.requirement.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const statuses: EnquiryStatus[] = [
    'New',
    'In Review',
    'Contacted',
    'Quotation Sent',
    'Order Confirmed',
    'In Production',
    'Completed'
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2D9C8] pb-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-xs font-bold text-[#A8763E] mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Bespoke Commission Portal</span>
          </div>
          <h1 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#231812]">
            Custom Door & Carving Requests ({customRequests.length})
          </h1>
          <p className="text-xs sm:text-sm text-[#8A7A6E]">
            Customer submissions for tailored door dimensions, CAD carving files, and reference image requests.
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8A7A6E]" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Filter custom requests by customer, phone, or requirements..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-xs text-[#231812] bg-white shadow-sm"
        />
      </div>

      {/* Requests Grid */}
      {customRequests.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#E2D9C8] p-12 text-center">
          <Sparkles className="w-12 h-12 text-[#A8763E] mx-auto mb-3 opacity-40" />
          <h3 className="font-serif-luxury text-xl font-bold text-[#231812] mb-1">No custom requests found</h3>
          <p className="text-xs text-[#8A7A6E]">
            When customers submit custom drawings or dimensions via "Request a Quote", they will appear here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {customRequests.map((req) => (
            <div
              key={req.id}
              className="bg-white rounded-2xl border border-[#E2D9C8] hover:border-[#A8763E] p-6 transition-all duration-200 shadow-sm hover:shadow-md flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-serif-luxury font-bold text-lg text-[#231812]">
                        {req.customerName}
                      </h3>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        req.status === 'New' ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {req.status}
                      </span>
                    </div>
                    <span className="text-xs font-mono text-[#8A7A6E]">{req.phone}</span>
                  </div>

                  <span className="text-[11px] text-[#8A7A6E] flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span>{new Date(req.createdAt).toLocaleDateString()}</span>
                  </span>
                </div>

                <div className="bg-[#FAF7F2] p-3.5 rounded-xl border border-[#E2D9C8] text-xs space-y-1">
                  <div><strong className="text-[#231812]">Design:</strong> {req.productTitle}</div>
                  <div><strong className="text-[#231812]">Wood Choice:</strong> <span className="text-[#A8763E] font-semibold">{req.woodPreference || 'Solid Teak Wood'}</span></div>
                  <div><strong className="text-[#231812]">Dimensions:</strong> {req.approximateSize || 'Custom Site Measure'}</div>
                </div>

                <div className="text-xs text-[#57473B] leading-relaxed">
                  <span className="font-bold text-[#231812] block mb-1">Requirement Notes:</span>
                  <p className="line-clamp-3 bg-gray-50 p-2.5 rounded-lg border border-gray-100">
                    {req.requirement}
                  </p>
                </div>

                {/* Reference Image Preview Indicator */}
                {req.referenceImageData ? (
                  <div className="flex items-center gap-2 p-2 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900">
                    <ImageIcon className="w-4 h-4 text-[#A8763E]" />
                    <span className="font-semibold">Reference Image Attached</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg border border-gray-100 text-xs text-[#8A7A6E]">
                    <ImageIcon className="w-4 h-4 text-gray-400" />
                    <span>Customer requested quote consultation</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-4 mt-4 border-t border-[#E2D9C8] flex items-center justify-between gap-2">
                {/* Status Dropdown */}
                <select
                  value={req.status}
                  onChange={(e) => updateEnquiryStatus(req.id, e.target.value as EnquiryStatus)}
                  className="px-2.5 py-1.5 rounded-lg border border-[#E2D9C8] text-xs font-semibold text-[#231812] bg-white focus:outline-none focus:border-[#A8763E]"
                >
                  {statuses.map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>

                <div className="flex items-center gap-2">
                  <a
                    href={`https://wa.me/91${req.phone}?text=Hello%20${encodeURIComponent(req.customerName)},%20CNCADOOR%20workshop%20received%20your%20custom%20wood%20carving%20request%20for%20${encodeURIComponent(req.productTitle)}...`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3.5 py-1.5 rounded-lg bg-[#25D366] text-white text-xs font-bold flex items-center gap-1 shadow-sm hover:bg-[#20b858]"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>

                  <a
                    href={`tel:${req.phone}`}
                    className="p-2 rounded-lg bg-white border border-[#E2D9C8] text-[#231812] hover:border-[#A8763E]"
                    title="Call"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-[#A8763E]" />
                  </a>
                </div>
              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
};
