import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { EnquiryRecord, EnquiryStatus } from '../../types';
import { 
  MessageSquare, 
  PhoneCall, 
  Search, 
  CheckCircle2, 
  Clock, 
  Trash2, 
  FileText, 
  User, 
  Calendar,
  X,
  ExternalLink,
  ChevronDown
} from 'lucide-react';

export const AdminOrdersEnquiries: React.FC = () => {
  const { enquiries, updateEnquiryStatus, deleteEnquiry } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | EnquiryStatus>('ALL');
  const [selectedEnquiry, setSelectedEnquiry] = useState<EnquiryRecord | null>(null);
  const [editingNotes, setEditingNotes] = useState('');

  const statuses: EnquiryStatus[] = [
    'New',
    'In Review',
    'Contacted',
    'Quotation Sent',
    'Order Confirmed',
    'In Production',
    'Completed',
    'Cancelled'
  ];

  const filteredEnquiries = enquiries.filter(e => {
    const matchesSearch = e.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.phone.includes(searchQuery) ||
      e.productTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.requirement.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || e.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenDetail = (enq: EnquiryRecord) => {
    setSelectedEnquiry(enq);
    setEditingNotes(enq.adminNotes || '');
  };

  const handleSaveNotes = () => {
    if (selectedEnquiry) {
      updateEnquiryStatus(selectedEnquiry.id, selectedEnquiry.status, editingNotes);
      setSelectedEnquiry({ ...selectedEnquiry, adminNotes: editingNotes });
    }
  };

  const handleStatusChange = (id: string, newStatus: EnquiryStatus) => {
    updateEnquiryStatus(id, newStatus);
    if (selectedEnquiry && selectedEnquiry.id === id) {
      setSelectedEnquiry({ ...selectedEnquiry, status: newStatus });
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2D9C8] pb-4">
        <div>
          <h1 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#231812]">
            Orders & Quote Inquiries ({enquiries.length})
          </h1>
          <p className="text-xs sm:text-sm text-[#8A7A6E]">
            Track quotes, customer requirements, ready-made orders, and send WhatsApp follow-ups.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl border border-[#E2D9C8] p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 shadow-sm">
        
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8A7A6E]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by customer name, phone number, door type..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-xs text-[#231812]"
          />
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              statusFilter === 'ALL' ? 'bg-[#2B1810] text-white' : 'bg-[#FAF7F2] text-[#57473B] border border-[#E2D9C8]'
            }`}
          >
            All ({enquiries.length})
          </button>
          {statuses.slice(0, 5).map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                statusFilter === s ? 'bg-[#2B1810] text-white' : 'bg-[#FAF7F2] text-[#57473B] border border-[#E2D9C8]'
              }`}
            >
              {s}
            </button>
          ))}
        </div>

      </div>

      {/* Enquiries List */}
      {filteredEnquiries.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#E2D9C8] p-12 text-center">
          <MessageSquare className="w-12 h-12 text-[#8A7A6E] mx-auto mb-3 opacity-40" />
          <h3 className="font-serif-luxury text-xl font-bold text-[#231812] mb-1">No inquiries match your criteria</h3>
          <p className="text-xs text-[#8A7A6E]">Try changing the status filter or search term.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredEnquiries.map((enq) => (
            <div
              key={enq.id}
              onClick={() => handleOpenDetail(enq)}
              className="bg-white rounded-2xl border border-[#E2D9C8] hover:border-[#A8763E] p-5 transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-1.5 max-w-2xl">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-bold text-base text-[#231812]">{enq.customerName}</span>
                  <span className="text-xs font-mono text-[#8A7A6E]">({enq.phone})</span>
                  
                  {/* Status badge */}
                  <span className={`text-[10px] font-bold uppercase px-2.5 py-0.5 rounded ${
                    enq.status === 'New'
                      ? 'bg-rose-100 text-rose-800 animate-pulse'
                      : enq.status === 'Quotation Sent'
                      ? 'bg-blue-100 text-blue-800'
                      : enq.status === 'Order Confirmed'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {enq.status}
                  </span>

                  <span className="text-[11px] text-[#8A7A6E] flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span>{new Date(enq.createdAt).toLocaleDateString()}</span>
                  </span>
                </div>

                <p className="text-xs font-semibold text-[#231812]">
                  {enq.productTitle} • <span className="text-[#A8763E]">{enq.woodPreference || 'Teak Wood'}</span> • {enq.approximateSize || 'Standard Dimensions'}
                </p>

                <p className="text-xs text-[#57473B] line-clamp-2 leading-relaxed">
                  {enq.requirement}
                </p>

                {enq.adminNotes && (
                  <div className="text-[11px] text-indigo-900 bg-indigo-50/80 px-2.5 py-1 rounded-lg border border-indigo-100">
                    <strong>Owner Note:</strong> {enq.adminNotes}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 self-end md:self-center" onClick={(e) => e.stopPropagation()}>
                <a
                  href={`https://wa.me/91${enq.phone}?text=Hello%20${encodeURIComponent(enq.customerName)},%20thank%20you%20for%20contacting%20CNCADOOR%20Wood%20Carving.%20Regarding%20your%20inquiry%20for%20${encodeURIComponent(enq.productTitle)}...`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 rounded-xl bg-[#25D366] hover:bg-[#20b858] text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-transform active:scale-95"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Reply on WhatsApp</span>
                </a>

                <a
                  href={`tel:${enq.phone}`}
                  className="p-2 rounded-xl bg-white border border-[#E2D9C8] hover:border-[#A8763E] text-[#231812] transition-colors"
                  title="Call Customer"
                >
                  <PhoneCall className="w-4 h-4 text-[#A8763E]" />
                </a>

                <button
                  onClick={() => handleOpenDetail(enq)}
                  className="px-3 py-2 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] hover:border-[#A8763E] text-xs font-bold text-[#231812]"
                >
                  Details
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Detail Slideout Modal */}
      {selectedEnquiry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div 
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-[#E2D9C8] p-6 sm:p-8 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedEnquiry(null)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-[#FAF7F2] border border-[#E2D9C8] text-[#231812] flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-6">
              <div>
                <div className="flex items-center gap-2 text-xs text-[#8A7A6E] mb-1">
                  <span>Enquiry ID: {selectedEnquiry.id}</span>
                  <span>•</span>
                  <span>{new Date(selectedEnquiry.createdAt).toLocaleString()}</span>
                </div>
                <h2 className="font-serif-luxury text-2xl font-bold text-[#231812]">
                  {selectedEnquiry.customerName}
                </h2>
                <div className="flex items-center gap-4 text-xs text-[#57473B] mt-1 font-mono">
                  <span>Phone: {selectedEnquiry.phone}</span>
                  {selectedEnquiry.email && <span>Email: {selectedEnquiry.email}</span>}
                </div>
              </div>

              {/* Status Update Control */}
              <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#E2D9C8] space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-[#231812]">
                  Update Status:
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {statuses.map(s => (
                    <button
                      key={s}
                      onClick={() => handleStatusChange(selectedEnquiry.id, s)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                        selectedEnquiry.status === s
                          ? 'bg-[#2B1810] text-white shadow-sm'
                          : 'bg-white text-[#57473B] border border-[#E2D9C8] hover:border-[#A8763E]'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Specs */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-[#FAF7F2] p-4 rounded-xl border border-[#E2D9C8]">
                <div>
                  <span className="text-[#8A7A6E] block font-medium">Door / Product:</span>
                  <span className="font-bold text-[#231812]">{selectedEnquiry.productTitle}</span>
                </div>
                <div>
                  <span className="text-[#8A7A6E] block font-medium">Wood Choice:</span>
                  <span className="font-bold text-[#231812]">{selectedEnquiry.woodPreference || 'Teak Wood'}</span>
                </div>
                <div>
                  <span className="text-[#8A7A6E] block font-medium">Approximate Dimensions:</span>
                  <span className="font-bold text-[#231812]">{selectedEnquiry.approximateSize || 'Standard'}</span>
                </div>
                <div>
                  <span className="text-[#8A7A6E] block font-medium">Contact Method:</span>
                  <span className="font-bold text-[#231812]">{selectedEnquiry.preferredContactMethod}</span>
                </div>
              </div>

              {/* Full Requirement */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                  Customer Requirement Message:
                </label>
                <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#E2D9C8] text-xs text-[#231812] leading-relaxed whitespace-pre-wrap">
                  {selectedEnquiry.requirement}
                </div>
              </div>

              {/* Admin Notes Section */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                  Owner Workshop Notes (Private):
                </label>
                <textarea
                  rows={3}
                  value={editingNotes}
                  onChange={(e) => setEditingNotes(e.target.value)}
                  placeholder="Record quote amounts, CAD drawing approvals, wood measurements, or customer conversation notes..."
                  className="w-full p-3 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
                />
                <button
                  onClick={handleSaveNotes}
                  className="mt-2 px-4 py-2 rounded-lg bg-[#2B1810] text-white text-xs font-bold uppercase tracking-wider"
                >
                  Save Notes
                </button>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-[#E2D9C8] flex items-center justify-between">
                <button
                  onClick={() => {
                    if (window.confirm('Delete this inquiry?')) {
                      deleteEnquiry(selectedEnquiry.id);
                      setSelectedEnquiry(null);
                    }
                  }}
                  className="text-xs text-rose-700 font-bold hover:underline"
                >
                  Delete Inquiry
                </button>

                <div className="flex items-center gap-2">
                  <a
                    href={`https://wa.me/91${selectedEnquiry.phone}?text=Hello%20${encodeURIComponent(selectedEnquiry.customerName)},%20regarding%20your%20CNCADOOR%20door%20quote%20request...`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-5 py-2.5 rounded-xl bg-[#25D366] text-white text-xs font-bold flex items-center gap-1.5"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Open WhatsApp</span>
                  </a>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
};
