import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { ActivityLogCategory, ActivityLogItem } from '../../types';
import { 
  History, 
  Search, 
  Filter, 
  Download, 
  Trash2, 
  PlusCircle, 
  Calendar, 
  User, 
  CheckCircle2, 
  AlertCircle, 
  Info, 
  ArrowRight, 
  Package, 
  FileText, 
  Shield, 
  Settings, 
  Layers, 
  Clock, 
  ArrowUpRight, 
  RefreshCw,
  X,
  MessageSquare,
  Sparkles
} from 'lucide-react';

export const AdminActivityLog: React.FC = () => {
  const { 
    activityLogs, 
    addActivityLog, 
    clearActivityLogs, 
    setActiveAdminTab,
    setEditingProduct,
    products
  } = useStore();

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [timeRange, setTimeRange] = useState<'all' | 'today' | 'week'>('all');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  // Manual Note Modal State
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [noteTitle, setNoteTitle] = useState('');
  const [noteDetails, setNoteDetails] = useState('');
  const [noteCategory, setNoteCategory] = useState<ActivityLogCategory>('doors');
  const [isConfirmClearOpen, setIsConfirmClearOpen] = useState(false);

  // Stats calculation
  const totalCount = activityLogs.length;
  const doorChangesCount = activityLogs.filter(l => l.category === 'doors').length;
  const quoteChangesCount = activityLogs.filter(l => l.category === 'quotes').length;
  const userEventsCount = activityLogs.filter(l => l.category === 'users').length;
  const settingsCount = activityLogs.filter(l => l.category === 'settings').length;

  // Filtered & Sorted Logs
  const filteredLogs = useMemo(() => {
    const now = new Date().getTime();
    const oneDayMs = 24 * 60 * 60 * 1000;
    const sevenDaysMs = 7 * oneDayMs;

    return activityLogs
      .filter((log) => {
        // Category filter
        if (selectedCategory !== 'all' && log.category !== selectedCategory) {
          return false;
        }

        // Severity filter
        if (selectedSeverity !== 'all' && log.severity !== selectedSeverity) {
          return false;
        }

        // Time range filter
        if (timeRange !== 'all') {
          const logTime = new Date(log.timestamp).getTime();
          const ageMs = now - logTime;
          if (timeRange === 'today' && ageMs > oneDayMs) return false;
          if (timeRange === 'week' && ageMs > sevenDaysMs) return false;
        }

        // Search query filter
        if (searchQuery.trim()) {
          const query = searchQuery.toLowerCase();
          const matchesTitle = log.title.toLowerCase().includes(query);
          const matchesDetails = log.details.toLowerCase().includes(query);
          const matchesActor = log.performedBy.toLowerCase().includes(query);
          const matchesTarget = (log.targetName || '').toLowerCase().includes(query);
          const matchesId = log.id.toLowerCase().includes(query) || (log.targetId || '').toLowerCase().includes(query);
          return matchesTitle || matchesDetails || matchesActor || matchesTarget || matchesId;
        }

        return true;
      })
      .sort((a, b) => {
        const timeA = new Date(a.timestamp).getTime();
        const timeB = new Date(b.timestamp).getTime();
        return sortOrder === 'desc' ? timeB - timeA : timeA - timeB;
      });
  }, [activityLogs, selectedCategory, selectedSeverity, timeRange, searchQuery, sortOrder]);

  // Format Date Helper
  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const now = new Date();
      const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

      if (diffMinutes < 1) return 'Just now';
      if (diffMinutes < 60) return `${diffMinutes}m ago`;
      const diffHours = Math.floor(diffMinutes / 60);
      if (diffHours < 24) return `${diffHours}h ago`;
      const diffDays = Math.floor(diffHours / 24);
      if (diffDays === 1) return 'Yesterday';
      if (diffDays < 7) return `${diffDays}d ago`;

      return date.toLocaleDateString('en-IN', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return isoString;
    }
  };

  const getCategoryIcon = (category: ActivityLogCategory) => {
    switch (category) {
      case 'doors':
        return <Package className="w-4 h-4 text-amber-700" />;
      case 'quotes':
        return <FileText className="w-4 h-4 text-blue-700" />;
      case 'users':
        return <Shield className="w-4 h-4 text-emerald-700" />;
      case 'settings':
        return <Settings className="w-4 h-4 text-purple-700" />;
      default:
        return <History className="w-4 h-4 text-stone-600" />;
    }
  };

  const getCategoryBadgeClass = (category: ActivityLogCategory) => {
    switch (category) {
      case 'doors':
        return 'bg-amber-100/70 text-amber-900 border-amber-300';
      case 'quotes':
        return 'bg-blue-100/70 text-blue-900 border-blue-300';
      case 'users':
        return 'bg-emerald-100/70 text-emerald-900 border-emerald-300';
      case 'settings':
        return 'bg-purple-100/70 text-purple-900 border-purple-300';
      default:
        return 'bg-stone-100 text-stone-800 border-stone-300';
    }
  };

  const getSeverityBadge = (severity?: string) => {
    switch (severity) {
      case 'success':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3" />
            <span>Success</span>
          </span>
        );
      case 'warning':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200">
            <AlertCircle className="w-3 h-3" />
            <span>Attention</span>
          </span>
        );
      case 'info':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200">
            <Info className="w-3 h-3" />
            <span>Updated</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-md bg-stone-100 text-stone-700 border border-stone-200">
            <Clock className="w-3 h-3" />
            <span>Logged</span>
          </span>
        );
    }
  };

  // Export CSV Handler
  const handleExportCsv = () => {
    const headers = ['ID', 'Timestamp', 'Category', 'Action', 'Title', 'Details', 'PerformedBy', 'TargetName', 'TargetID', 'Severity'];
    const rows = filteredLogs.map(log => [
      `"${log.id}"`,
      `"${log.timestamp}"`,
      `"${log.category}"`,
      `"${log.action}"`,
      `"${(log.title || '').replace(/"/g, '""')}"`,
      `"${(log.details || '').replace(/"/g, '""')}"`,
      `"${(log.performedBy || '').replace(/"/g, '""')}"`,
      `"${(log.targetName || '').replace(/"/g, '""')}"`,
      `"${(log.targetId || '').replace(/"/g, '""')}"`,
      `"${log.severity || 'info'}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `cncadoor_admin_activity_log_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle Manual Note Submission
  const handleAddManualNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim()) return;

    addActivityLog({
      category: noteCategory,
      action: 'admin_note',
      title: noteTitle.trim(),
      details: noteDetails.trim() || 'Administrative manual notation recorded by workshop owner.',
      performedBy: 'adoorcnc@gmail.com (Owner)',
      severity: 'info',
      meta: {
        badgeText: 'Owner Note'
      }
    });

    setNoteTitle('');
    setNoteDetails('');
    setIsNoteModalOpen(false);
  };

  // Handle Quick Target Navigation
  const handleNavigateToTarget = (log: ActivityLogItem) => {
    if (log.category === 'doors') {
      if (log.targetId) {
        const prod = products.find(p => p.id === log.targetId);
        if (prod) {
          setEditingProduct(prod);
          setActiveAdminTab('add-product');
          return;
        }
      }
      setActiveAdminTab('products');
    } else if (log.category === 'quotes') {
      setActiveAdminTab('orders');
    } else if (log.category === 'settings') {
      setActiveAdminTab('settings');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-[#231812] via-[#352319] to-[#2B1810] rounded-2xl p-6 sm:p-8 text-[#FAF7F2] shadow-sm border border-[#A8763E]/30 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FAF7F2]/10 border border-[#FAF7F2]/20 text-xs text-[#D4AF37] font-semibold mb-2">
            <History className="w-3.5 h-3.5" />
            <span>Administrative Transparency & Audit Ledger</span>
          </div>
          <h1 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-white tracking-wide">
            Admin Activity Log
          </h1>
          <p className="text-xs sm:text-sm text-[#D7CCC8] mt-1.5 max-w-2xl leading-relaxed">
            Chronological audit trail tracking all modifications made to doors, inventory stock, quote inquiries, user authentication sessions, and workshop settings.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setIsNoteModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-[#A8763E] hover:bg-[#8F6232] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-sm transition-transform active:scale-95 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Record Admin Note</span>
          </button>

          <button
            onClick={handleExportCsv}
            disabled={activityLogs.length === 0}
            className="px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
            title="Download CSV report of activity history"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          <button
            onClick={() => setIsConfirmClearOpen(true)}
            className="px-3 py-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/30 text-rose-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Clear activity records"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 2. Metrics Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            selectedCategory === 'all'
              ? 'bg-white border-[#A8763E] shadow-sm ring-1 ring-[#A8763E]/30'
              : 'bg-white/80 border-[#E2D9C8] hover:border-[#A8763E]/60'
          }`}
        >
          <div className="flex items-center justify-between text-[#8A7A6E] mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">All Activities</span>
            <Layers className="w-4 h-4 text-[#A8763E]" />
          </div>
          <div className="text-2xl font-bold font-serif-luxury text-[#231812]">{totalCount}</div>
          <div className="text-[10px] text-[#8A7A6E] mt-0.5">Total audit entries</div>
        </button>

        <button
          onClick={() => setSelectedCategory('doors')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            selectedCategory === 'doors'
              ? 'bg-white border-amber-600 shadow-sm ring-1 ring-amber-600/30'
              : 'bg-white/80 border-[#E2D9C8] hover:border-amber-500/60'
          }`}
        >
          <div className="flex items-center justify-between text-amber-800 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Doors & Stock</span>
            <Package className="w-4 h-4 text-amber-700" />
          </div>
          <div className="text-2xl font-bold font-serif-luxury text-amber-900">{doorChangesCount}</div>
          <div className="text-[10px] text-[#8A7A6E] mt-0.5">Catalog & price updates</div>
        </button>

        <button
          onClick={() => setSelectedCategory('quotes')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            selectedCategory === 'quotes'
              ? 'bg-white border-blue-600 shadow-sm ring-1 ring-blue-600/30'
              : 'bg-white/80 border-[#E2D9C8] hover:border-blue-500/60'
          }`}
        >
          <div className="flex items-center justify-between text-blue-800 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Quotes & Orders</span>
            <FileText className="w-4 h-4 text-blue-700" />
          </div>
          <div className="text-2xl font-bold font-serif-luxury text-blue-900">{quoteChangesCount}</div>
          <div className="text-[10px] text-[#8A7A6E] mt-0.5">Quote status & notes</div>
        </button>

        <button
          onClick={() => setSelectedCategory('users')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            selectedCategory === 'users'
              ? 'bg-white border-emerald-600 shadow-sm ring-1 ring-emerald-600/30'
              : 'bg-white/80 border-[#E2D9C8] hover:border-emerald-500/60'
          }`}
        >
          <div className="flex items-center justify-between text-emerald-800 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">User Status & Auth</span>
            <Shield className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="text-2xl font-bold font-serif-luxury text-emerald-900">{userEventsCount}</div>
          <div className="text-[10px] text-[#8A7A6E] mt-0.5">Logins & permissions</div>
        </button>

        <button
          onClick={() => setSelectedCategory('settings')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer col-span-2 lg:col-span-1 ${
            selectedCategory === 'settings'
              ? 'bg-white border-purple-600 shadow-sm ring-1 ring-purple-600/30'
              : 'bg-white/80 border-[#E2D9C8] hover:border-purple-500/60'
          }`}
        >
          <div className="flex items-center justify-between text-purple-800 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Settings</span>
            <Settings className="w-4 h-4 text-purple-700" />
          </div>
          <div className="text-2xl font-bold font-serif-luxury text-purple-900">{settingsCount}</div>
          <div className="text-[10px] text-[#8A7A6E] mt-0.5">Workshop phone & announcements</div>
        </button>
      </div>

      {/* 3. Search & Filtering Controls */}
      <div className="bg-white rounded-2xl border border-[#E2D9C8] p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#8A7A6E] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search activity by title, door name, customer, action or actor email..."
              className="w-full pl-9 pr-8 py-2 text-xs rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] focus:outline-none focus:border-[#A8763E] text-[#231812] placeholder-[#8A7A6E]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filters Group */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Category Dropdown */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] text-[#231812] font-medium focus:outline-none focus:border-[#A8763E]"
            >
              <option value="all">All Categories</option>
              <option value="doors">Doors & Catalog</option>
              <option value="quotes">Quotes & Orders</option>
              <option value="users">User Status & Auth</option>
              <option value="settings">Workshop Settings</option>
            </select>

            {/* Timeframe Dropdown */}
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value as any)}
              className="px-3 py-2 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] text-[#231812] font-medium focus:outline-none focus:border-[#A8763E]"
            >
              <option value="all">All Time</option>
              <option value="today">Today Only</option>
              <option value="week">Past 7 Days</option>
            </select>

            {/* Sort Toggle */}
            <button
              onClick={() => setSortOrder(prev => prev === 'desc' ? 'asc' : 'desc')}
              className="px-3 py-2 rounded-xl bg-[#FAF7F2] hover:bg-[#EADCC9]/50 border border-[#E2D9C8] text-[#231812] font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Toggle sort direction"
            >
              <Clock className="w-3.5 h-3.5 text-[#A8763E]" />
              <span>{sortOrder === 'desc' ? 'Newest First' : 'Oldest First'}</span>
            </button>
          </div>
        </div>

        {/* Active Filters Display */}
        {(selectedCategory !== 'all' || selectedSeverity !== 'all' || timeRange !== 'all' || searchQuery) && (
          <div className="flex items-center gap-2 pt-2 border-t border-[#E2D9C8]/60 text-xs text-[#8A7A6E]">
            <span className="font-semibold text-[#57473B]">Showing {filteredLogs.length} matching events</span>
            <span>•</span>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedSeverity('all');
                setTimeRange('all');
                setSearchQuery('');
              }}
              className="text-[#A8763E] hover:underline font-bold"
            >
              Reset all filters
            </button>
          </div>
        )}
      </div>

      {/* 4. Activity Logs List Timeline */}
      <div className="bg-white rounded-2xl border border-[#E2D9C8] shadow-sm overflow-hidden">
        
        <div className="p-4 sm:p-5 border-b border-[#E2D9C8] flex items-center justify-between bg-[#FAF7F2]/50">
          <div className="flex items-center gap-2">
            <h2 className="font-serif-luxury text-lg font-bold text-[#231812]">
              Audit Trail Entries
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-[#E2D9C8] text-[#57473B] font-bold">
              {filteredLogs.length}
            </span>
          </div>

          <div className="text-xs text-[#8A7A6E] flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Live Local Audit Sync</span>
          </div>
        </div>

        {filteredLogs.length === 0 ? (
          <div className="text-center py-16 px-4 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-700 mx-auto flex items-center justify-center">
              <History className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-base text-[#231812]">No activity entries found</h3>
            <p className="text-xs text-[#8A7A6E] max-w-sm mx-auto">
              No audit logs matched your search or category filter. Try clearing the search or selecting 'All Categories'.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setTimeRange('all');
              }}
              className="px-4 py-2 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] text-xs font-bold text-[#A8763E] hover:bg-[#EADCC9]/50 transition-colors"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="divide-y divide-[#E2D9C8]/60">
            {filteredLogs.map((log) => {
              const isExpanded = expandedLogId === log.id;

              return (
                <div 
                  key={log.id} 
                  className={`p-4 sm:p-5 transition-colors ${
                    isExpanded ? 'bg-[#FAF7F2]' : 'hover:bg-[#FAF7F2]/60'
                  }`}
                >
                  <div className="flex items-start gap-3.5">
                    
                    {/* Category Icon Badge */}
                    <div className="w-9 h-9 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                      {getCategoryIcon(log.category)}
                    </div>

                    {/* Content Column */}
                    <div className="flex-1 min-w-0 space-y-1.5">
                      
                      {/* Top Row: Category Tag, Title, Timestamp, Severity */}
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${getCategoryBadgeClass(log.category)}`}>
                            {log.category === 'doors' ? 'Door Catalog' : log.category === 'quotes' ? 'Quotes & Orders' : log.category === 'users' ? 'User Status' : 'Settings'}
                          </span>

                          <span className="font-bold text-sm text-[#231812] tracking-tight">
                            {log.title}
                          </span>

                          {log.meta?.badgeText && (
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#EADCC9] text-[#443529]">
                              {log.meta.badgeText}
                            </span>
                          )}
                        </div>

                        {/* Relative time & Severity */}
                        <div className="flex items-center gap-2 self-start sm:self-center">
                          {getSeverityBadge(log.severity)}
                          <span 
                            className="text-xs text-[#8A7A6E] font-medium shrink-0" 
                            title={new Date(log.timestamp).toLocaleString()}
                          >
                            {formatTime(log.timestamp)}
                          </span>
                        </div>
                      </div>

                      {/* Descriptive Details */}
                      <p className="text-xs text-[#57473B] leading-relaxed">
                        {log.details}
                      </p>

                      {/* Meta Pills & Actor */}
                      <div className="flex flex-wrap items-center gap-2 pt-1 text-[11px] text-[#8A7A6E]">
                        <span className="inline-flex items-center gap-1 font-medium text-[#443529]">
                          <User className="w-3 h-3 text-[#A8763E]" />
                          <span>Performed by: <strong className="font-semibold text-[#231812]">{log.performedBy}</strong></span>
                        </span>

                        {log.targetName && (
                          <>
                            <span>•</span>
                            <span className="text-[#57473B]">
                              Target: <span className="font-medium text-[#231812]">{log.targetName}</span>
                            </span>
                          </>
                        )}

                        {/* If status changed, show before & after badge */}
                        {log.meta?.previousValue && log.meta?.newValue && (
                          <>
                            <span>•</span>
                            <span className="inline-flex items-center gap-1 text-[10px] font-mono bg-stone-100 px-2 py-0.5 rounded border border-stone-200">
                              <span className="text-stone-600 line-through">{log.meta.previousValue}</span>
                              <ArrowRight className="w-2.5 h-2.5 text-stone-400" />
                              <span className="font-bold text-[#231812]">{log.meta.newValue}</span>
                            </span>
                          </>
                        )}
                      </div>

                      {/* Expand Details Drawer */}
                      {isExpanded && (
                        <div className="mt-3 p-3.5 rounded-xl bg-white border border-[#E2D9C8] space-y-2.5 text-xs text-[#57473B] animate-fadeIn">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <span className="text-[10px] font-bold text-[#8A7A6E] uppercase tracking-wider block">Log ID</span>
                              <span className="font-mono text-xs text-[#231812]">{log.id}</span>
                            </div>
                            <div>
                              <span className="text-[10px] font-bold text-[#8A7A6E] uppercase tracking-wider block">Full Timestamp</span>
                              <span className="font-mono text-xs text-[#231812]">{new Date(log.timestamp).toLocaleString('en-IN', { timeZoneName: 'short' })}</span>
                            </div>
                            {log.targetId && (
                              <div>
                                <span className="text-[10px] font-bold text-[#8A7A6E] uppercase tracking-wider block">Target Reference ID</span>
                                <span className="font-mono text-xs text-[#231812]">{log.targetId}</span>
                              </div>
                            )}
                            <div>
                              <span className="text-[10px] font-bold text-[#8A7A6E] uppercase tracking-wider block">Action Type</span>
                              <span className="font-mono text-xs text-[#231812]">{log.action}</span>
                            </div>
                          </div>

                          {/* Quick Jump to Target Button */}
                          {(log.category === 'doors' || log.category === 'quotes' || log.category === 'settings') && (
                            <div className="pt-2 border-t border-[#E2D9C8]/60 flex justify-end">
                              <button
                                onClick={() => handleNavigateToTarget(log)}
                                className="px-3 py-1.5 rounded-lg bg-[#FAF7F2] hover:bg-[#EADCC9]/50 border border-[#E2D9C8] text-[#A8763E] font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <span>View in {log.category === 'doors' ? 'Product Catalog' : log.category === 'quotes' ? 'Orders & Quotes' : 'Settings'}</span>
                                <ArrowUpRight className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Expand / Collapse toggle button */}
                      <button
                        onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                        className="text-[11px] text-[#A8763E] hover:underline font-semibold pt-0.5 cursor-pointer block"
                      >
                        {isExpanded ? 'Hide audit metadata' : 'View full metadata & IDs'}
                      </button>

                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

      {/* 5. Record Manual Note Modal */}
      {isNoteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-[#E2D9C8] space-y-4">
            <div className="flex items-center justify-between border-b border-[#E2D9C8] pb-3">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-[#A8763E]" />
                <h3 className="font-serif-luxury text-lg font-bold text-[#231812]">
                  Record Administrative Note
                </h3>
              </div>
              <button
                onClick={() => setIsNoteModalOpen(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddManualNote} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#57473B] mb-1">
                  Category *
                </label>
                <select
                  value={noteCategory}
                  onChange={(e) => setNoteCategory(e.target.value as ActivityLogCategory)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs font-medium focus:outline-none focus:border-[#A8763E]"
                >
                  <option value="doors">Doors & Products</option>
                  <option value="quotes">Quotes & Orders</option>
                  <option value="users">User Status & Authentication</option>
                  <option value="settings">Workshop Settings</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#57473B] mb-1">
                  Note Title *
                </label>
                <input
                  type="text"
                  required
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  placeholder="e.g., Updated Teak Wood wholesale rate or dispatched order #102"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs focus:outline-none focus:border-[#A8763E]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#57473B] mb-1">
                  Details & Context
                </label>
                <textarea
                  rows={3}
                  value={noteDetails}
                  onChange={(e) => setNoteDetails(e.target.value)}
                  placeholder="Additional context, timber lot notes, customer reference or internal reasons..."
                  className="w-full px-3.5 py-2 rounded-xl border border-[#E2D9C8] text-xs focus:outline-none focus:border-[#A8763E]"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-[#E2D9C8]">
                <button
                  type="button"
                  onClick={() => setIsNoteModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-[#E2D9C8] text-xs font-bold text-[#57473B] hover:bg-[#FAF7F2]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#A8763E] hover:bg-[#8F6232] text-white text-xs font-bold uppercase tracking-wider"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. Confirm Clear Dialog */}
      {isConfirmClearOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-rose-200 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-serif-luxury text-lg font-bold text-[#231812]">
                Clear Activity Records?
              </h3>
              <p className="text-xs text-[#8A7A6E] leading-relaxed">
                This will wipe the current local audit history ({activityLogs.length} events). Any future changes will continue to be automatically logged.
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setIsConfirmClearOpen(false)}
                className="px-4 py-2 rounded-xl border border-[#E2D9C8] text-xs font-bold text-[#57473B] hover:bg-[#FAF7F2]"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  clearActivityLogs();
                  setIsConfirmClearOpen(false);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold"
              >
                Yes, Clear All Logs
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
