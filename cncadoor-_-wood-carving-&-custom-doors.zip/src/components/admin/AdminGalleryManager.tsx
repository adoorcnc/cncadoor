import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { GalleryItem, GalleryFilter } from '../../types';
import { 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  Layers, 
  CheckCircle2, 
  ExternalLink,
  X
} from 'lucide-react';

export const AdminGalleryManager: React.FC = () => {
  const { galleryItems, addGalleryItem, deleteGalleryItem } = useStore();
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | GalleryFilter>('ALL');

  const [newItem, setNewItem] = useState<{
    title: string;
    category: GalleryFilter;
    imageUrl: string;
    woodType: string;
    description: string;
    aspectRatio: 'tall' | 'wide' | 'square';
  }>({
    title: '',
    category: 'DOORS',
    imageUrl: '',
    woodType: 'Solid Teak',
    description: '',
    aspectRatio: 'square'
  });

  const categories: GalleryFilter[] = ['ALL', 'DOORS', 'CARVING', 'DETAILS', 'COMPLETED WORK', 'CUSTOM'];

  const filteredItems = selectedFilter === 'ALL'
    ? galleryItems
    : galleryItems.filter(item => item.category === selectedFilter);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItem.title.trim() || !newItem.imageUrl.trim()) {
      alert('Please provide at least a photo title and image URL');
      return;
    }

    addGalleryItem({
      title: newItem.title,
      category: newItem.category,
      imageUrl: newItem.imageUrl,
      woodType: newItem.woodType,
      description: newItem.description,
      aspectRatio: newItem.aspectRatio
    });

    setShowAddModal(false);
    setNewItem({
      title: '',
      category: 'DOORS',
      imageUrl: '',
      woodType: 'Solid Teak',
      description: '',
      aspectRatio: 'square'
    });
  };

  const samplePresets = [
    { title: 'Teak Floral Mandala Carving', url: 'https://images.unsplash.com/photo-1548625361-195fe5795df5?auto=format&fit=crop&w=1000&q=80', cat: 'CARVING' as GalleryFilter },
    { title: 'Grand Arched Entrance Shutter', url: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80', cat: 'DOORS' as GalleryFilter },
    { title: 'Botanical Acanthus Grain Detail', url: 'https://images.unsplash.com/photo-1509644851169-2acc08aa25b5?auto=format&fit=crop&w=1000&q=80', cat: 'DETAILS' as GalleryFilter },
    { title: 'Installed Villa Teak Double Door', url: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1000&q=80', cat: 'COMPLETED WORK' as GalleryFilter }
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2D9C8] pb-4">
        <div>
          <h1 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#231812]">
            Workshop Gallery Manager ({galleryItems.length})
          </h1>
          <p className="text-xs sm:text-sm text-[#8A7A6E]">
            Add and curate photos of completed client installations, wood grain close-ups, and CNC carvings.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-5 py-2.5 rounded-xl bg-[#2B1810] hover:bg-[#A8763E] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-sm self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Photo to Gallery</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedFilter(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold tracking-wider transition-all ${
              selectedFilter === cat
                ? 'bg-[#2B1810] text-[#FAF7F2] shadow-sm'
                : 'bg-white text-[#57473B] border border-[#E2D9C8] hover:border-[#A8763E]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl border border-[#E2D9C8] overflow-hidden shadow-sm hover:shadow-md transition-all group flex flex-col justify-between"
          >
            <div className="relative aspect-[4/3] bg-black/5 overflow-hidden">
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute top-2 left-2 bg-[#2B1810]/80 text-[#FAF7F2] text-[10px] font-bold uppercase px-2 py-0.5 rounded">
                {item.category}
              </div>

              <button
                onClick={() => {
                  if (window.confirm(`Remove "${item.title}" from gallery?`)) {
                    deleteGalleryItem(item.id);
                  }
                }}
                className="absolute top-2 right-2 w-7 h-7 rounded-full bg-white/90 text-rose-700 hover:bg-rose-100 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                title="Delete Photo"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-4 space-y-1">
              <h4 className="font-serif-luxury font-bold text-sm text-[#231812] line-clamp-1">
                {item.title}
              </h4>
              <p className="text-xs text-[#8A7A6E]">
                {item.woodType || 'Solid Teak Wood'}
              </p>
              {item.description && (
                <p className="text-[11px] text-[#57473B] line-clamp-2">
                  {item.description}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div 
            className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 border border-[#E2D9C8] shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-[#FAF7F2] text-[#231812] flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>

            <h2 className="font-serif-luxury text-2xl font-bold text-[#231812] mb-6">
              Add Photo to Gallery
            </h2>

            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                  Photo Title *
                </label>
                <input
                  type="text"
                  required
                  value={newItem.title}
                  onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                  placeholder="e.g. Traditional Teak Entrance Door in Adoor"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                    Category
                  </label>
                  <select
                    value={newItem.category}
                    onChange={(e) => setNewItem({ ...newItem, category: e.target.value as GalleryFilter })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs bg-white focus:outline-none"
                  >
                    <option value="DOORS">DOORS</option>
                    <option value="CARVING">CARVING</option>
                    <option value="DETAILS">DETAILS</option>
                    <option value="COMPLETED WORK">COMPLETED WORK</option>
                    <option value="CUSTOM">CUSTOM</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                    Wood Type
                  </label>
                  <input
                    type="text"
                    value={newItem.woodType}
                    onChange={(e) => setNewItem({ ...newItem, woodType: e.target.value })}
                    placeholder="e.g. Solid Teak"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                  Image URL *
                </label>
                <input
                  type="url"
                  required
                  value={newItem.imageUrl}
                  onChange={(e) => setNewItem({ ...newItem, imageUrl: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs font-mono focus:border-[#A8763E] focus:outline-none"
                />

                {/* Quick Presets */}
                <div className="mt-2 space-y-1">
                  <span className="text-[10px] text-[#8A7A6E] block">Or pick a workshop sample preset:</span>
                  <div className="grid grid-cols-4 gap-1.5">
                    {samplePresets.map((p, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setNewItem({ ...newItem, imageUrl: p.url, title: p.title, category: p.cat })}
                        className="relative aspect-[4/3] rounded border overflow-hidden"
                      >
                        <img src={p.url} alt={p.title} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                  Caption / Description (Optional)
                </label>
                <textarea
                  rows={2}
                  value={newItem.description}
                  onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                  placeholder="Brief description of the installation, wood finish or carving..."
                  className="w-full px-3.5 py-2 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
                />
              </div>

              <div className="pt-4 flex items-center justify-end gap-2 border-t border-[#E2D9C8]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-[#E2D9C8] text-xs font-bold text-[#57473B]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-xl bg-[#2B1810] text-white text-xs font-bold uppercase tracking-wider"
                >
                  Add Photo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
