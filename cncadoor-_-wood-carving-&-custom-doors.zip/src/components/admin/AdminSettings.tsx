import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { BusinessConfig } from '../../types';
import { 
  Settings, 
  Save, 
  Phone, 
  MessageSquare, 
  MapPin, 
  Clock, 
  Sparkles, 
  CheckCircle2, 
  Mail, 
  Globe 
} from 'lucide-react';

export const AdminSettings: React.FC = () => {
  const { businessConfig, updateBusinessConfig } = useStore();
  const [formData, setFormData] = useState<BusinessConfig>(businessConfig);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusinessConfig(formData);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
    }, 3000);
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-4xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2D9C8] pb-4">
        <div>
          <h1 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#231812]">
            Website & Workshop Settings
          </h1>
          <p className="text-xs sm:text-sm text-[#8A7A6E]">
            Configure your business contact numbers, WhatsApp routing, workshop address, and live announcement banner.
          </p>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-sm flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span className="font-semibold">Website Settings updated successfully!</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-[#E2D9C8] p-6 sm:p-10 shadow-sm space-y-8">
        
        {/* Section 1: Business Identity */}
        <div>
          <h3 className="font-serif-luxury text-lg font-bold text-[#231812] mb-4 pb-2 border-b border-[#E2D9C8] flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#A8763E]" />
            <span>Business Brand Identity</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                Business Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs font-semibold focus:border-[#A8763E] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                Subtitle
              </label>
              <input
                type="text"
                value={formData.subtitle}
                onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                Tagline / Brand Statement
              </label>
              <input
                type="text"
                value={formData.tagline}
                onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Contact & WhatsApp */}
        <div>
          <h3 className="font-serif-luxury text-lg font-bold text-[#231812] mb-4 pb-2 border-b border-[#E2D9C8] flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-[#A8763E]" />
            <span>Phone Numbers & WhatsApp Routing</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                Primary Phone / WhatsApp Number
              </label>
              <input
                type="text"
                value={formData.phones[0] || ''}
                onChange={(e) => {
                  const newPhones = [...formData.phones];
                  newPhones[0] = e.target.value;
                  const newWhatsapps = [...formData.whatsapps];
                  newWhatsapps[0] = e.target.value;
                  setFormData({ ...formData, phones: newPhones, whatsapps: newWhatsapps });
                }}
                placeholder="8301851820"
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs font-mono font-bold focus:border-[#A8763E] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                Secondary Phone / WhatsApp Number
              </label>
              <input
                type="text"
                value={formData.phones[1] || ''}
                onChange={(e) => {
                  const newPhones = [...formData.phones];
                  newPhones[1] = e.target.value;
                  const newWhatsapps = [...formData.whatsapps];
                  newWhatsapps[1] = e.target.value;
                  setFormData({ ...formData, phones: newPhones, whatsapps: newWhatsapps });
                }}
                placeholder="7558934820"
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs font-mono focus:border-[#A8763E] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                Business Email
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                Workshop Operating Hours
              </label>
              <input
                type="text"
                value={formData.openingHours}
                onChange={(e) => setFormData({ ...formData, openingHours: e.target.value })}
                placeholder="9:00am - 8:00pm (Mon - Sat)"
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Workshop Address & Maps */}
        <div>
          <h3 className="font-serif-luxury text-lg font-bold text-[#231812] mb-4 pb-2 border-b border-[#E2D9C8] flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#A8763E]" />
            <span>Workshop Location</span>
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                Physical Workshop Address
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-1">
                Google Maps Navigation Link
              </label>
              <input
                type="url"
                value={formData.googleMapsUrl}
                onChange={(e) => setFormData({ ...formData, googleMapsUrl: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs font-mono focus:border-[#A8763E] focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Announcement Bar */}
        <div>
          <h3 className="font-serif-luxury text-lg font-bold text-[#231812] mb-4 pb-2 border-b border-[#E2D9C8] flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#A8763E]" />
            <span>Top Website Announcement Banner</span>
          </h3>

          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="announcementActive"
                checked={formData.announcementActive !== false}
                onChange={(e) => setFormData({ ...formData, announcementActive: e.target.checked })}
                className="w-4 h-4 text-[#A8763E] rounded border-[#E2D9C8]"
              />
              <label htmlFor="announcementActive" className="text-xs font-bold text-[#231812]">
                Display announcement banner at the top of the website
              </label>
            </div>

            <input
              type="text"
              value={formData.announcement || ''}
              onChange={(e) => setFormData({ ...formData, announcement: e.target.value })}
              placeholder="🌟 Direct Workshop Pricing in Adoor: Custom CNC Wood Carving & Pre-Seasoned Teak Doors"
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2D9C8] text-xs focus:border-[#A8763E] focus:outline-none"
            />
          </div>
        </div>

        {/* Save Button */}
        <div className="pt-4 border-t border-[#E2D9C8] flex justify-end">
          <button
            type="submit"
            className="px-8 py-3 rounded-xl bg-[#2B1810] hover:bg-[#A8763E] text-white text-xs font-bold uppercase tracking-widest flex items-center gap-2 shadow-md transition-transform active:scale-95"
          >
            <Save className="w-4 h-4" />
            <span>Save All Settings</span>
          </button>
        </div>

      </form>

    </div>
  );
};
