import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductItem, ProductStatus, ProductType } from '../../types';
import { 
  Package, 
  Sparkles, 
  Search, 
  Filter, 
  Plus, 
  Edit3, 
  Trash2, 
  Copy, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  Clock, 
  ExternalLink,
  Layers,
  Ruler
} from 'lucide-react';

export const AdminProductsList: React.FC = () => {
  const { 
    products, 
    toggleProductStatus, 
    deleteProduct, 
    duplicateProduct, 
    setEditingProduct, 
    setActiveAdminTab,
    setDraftProductInCreation 
  } = useStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | ProductType>('ALL');
  const [filterStatus, setFilterStatus] = useState<'ALL' | ProductStatus>('ALL');
  const [selectedProductForModal, setSelectedProductForModal] = useState<ProductItem | null>(null);

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.woodType.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesType = filterType === 'ALL' || p.type === filterType;
    const matchesStatus = filterStatus === 'ALL' || p.status === filterStatus;

    return matchesSearch && matchesType && matchesStatus;
  });

  const handleEdit = (product: ProductItem) => {
    setEditingProduct(product);
    setActiveAdminTab('add-product');
  };

  const handleAddNew = () => {
    setEditingProduct(null);
    setDraftProductInCreation(null);
    setActiveAdminTab('add-product');
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}"?`)) {
      deleteProduct(id);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Header & New Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2D9C8] pb-4">
        <div>
          <h1 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#231812]">
            Products Inventory ({products.length})
          </h1>
          <p className="text-xs sm:text-sm text-[#8A7A6E]">
            Manage published items, in-stock ready-made products, custom offerings, and draft items.
          </p>
        </div>

        <button
          onClick={handleAddNew}
          className="px-5 py-2.5 rounded-xl bg-[#2B1810] hover:bg-[#A8763E] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-sm transition-transform active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl border border-[#E2D9C8] p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 shadow-sm">
        
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8A7A6E]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, wood species, category..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-xs text-[#231812]"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* Type Filter */}
          <div className="flex items-center bg-[#FAF7F2] p-1 rounded-xl border border-[#E2D9C8] text-xs">
            <button
              onClick={() => setFilterType('ALL')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterType === 'ALL' ? 'bg-[#2B1810] text-white' : 'text-[#57473B]'
              }`}
            >
              All Types
            </button>
            <button
              onClick={() => setFilterType('ready-made')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterType === 'ready-made' ? 'bg-[#2B1810] text-white' : 'text-[#57473B]'
              }`}
            >
              Ready-Made
            </button>
            <button
              onClick={() => setFilterType('customized')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterType === 'customized' ? 'bg-[#2B1810] text-white' : 'text-[#57473B]'
              }`}
            >
              Customized
            </button>
          </div>

          {/* Status Filter */}
          <div className="flex items-center bg-[#FAF7F2] p-1 rounded-xl border border-[#E2D9C8] text-xs">
            <button
              onClick={() => setFilterStatus('ALL')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterStatus === 'ALL' ? 'bg-[#2B1810] text-white' : 'text-[#57473B]'
              }`}
            >
              All Status
            </button>
            <button
              onClick={() => setFilterStatus('published')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterStatus === 'published' ? 'bg-emerald-700 text-white' : 'text-[#57473B]'
              }`}
            >
              Published
            </button>
            <button
              onClick={() => setFilterStatus('draft')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterStatus === 'draft' ? 'bg-amber-700 text-white' : 'text-[#57473B]'
              }`}
            >
              Drafts
            </button>
            <button
              onClick={() => setFilterStatus('hidden')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterStatus === 'hidden' ? 'bg-rose-700 text-white' : 'text-[#57473B]'
              }`}
            >
              Hidden
            </button>
          </div>

        </div>
      </div>

      {/* Products Table / Cards */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#E2D9C8] p-12 text-center">
          <Package className="w-12 h-12 text-[#8A7A6E] mx-auto mb-3 opacity-40" />
          <h3 className="font-serif-luxury text-xl font-bold text-[#231812] mb-1">No products found</h3>
          <p className="text-xs text-[#8A7A6E] mb-6">Try clearing search filters or add a new product.</p>
          <button
            onClick={handleAddNew}
            className="px-5 py-2 rounded-lg bg-[#2B1810] text-white text-xs font-bold"
          >
            Create Product
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-[#E2D9C8] overflow-hidden shadow-sm">
          <div className="divide-y divide-[#E2D9C8]/60">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-[#FAF7F2]/60 transition-colors"
              >
                {/* Left: Thumbnail & Info */}
                <div className="flex items-start gap-4">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden bg-black/5 flex-shrink-0 border border-[#E2D9C8] relative">
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    <div className={`absolute bottom-0 inset-x-0 text-[9px] font-bold text-center text-white py-0.5 uppercase ${
                      product.type === 'ready-made' ? 'bg-emerald-800' : 'bg-[#2B1810]'
                    }`}>
                      {product.type === 'ready-made' ? 'Ready Stock' : 'Custom'}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-serif-luxury font-bold text-base text-[#231812]">
                        {product.name}
                      </h3>

                      {/* Status Dropdown/Pill */}
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        product.status === 'published'
                          ? 'bg-emerald-100 text-emerald-800'
                          : product.status === 'draft'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {product.status}
                      </span>
                    </div>

                    <p className="text-xs text-[#57473B] font-medium">
                      {product.category} • <span className="text-[#A8763E]">{product.woodType}</span>
                    </p>

                    <p className="text-xs text-[#8A7A6E] line-clamp-1 max-w-xl">
                      {product.description}
                    </p>

                    <div className="flex items-center gap-4 text-xs text-[#8A7A6E] pt-1">
                      <span><strong>Size:</strong> {product.dimensionsNote}</span>
                      {product.type === 'ready-made' && (
                        <span><strong>Stock:</strong> {product.inStockCount || 1} units</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Middle: Price & Status Toggle */}
                <div className="flex flex-wrap items-center justify-between lg:justify-end gap-6 pt-3 lg:pt-0 border-t lg:border-t-0 border-[#E2D9C8]/60">
                  <div className="text-left lg:text-right">
                    <span className="font-serif-luxury text-lg font-bold text-[#231812] block">
                      {product.price || 'Price on Request'}
                    </span>
                    <span className="text-[10px] uppercase text-[#8A7A6E] font-medium">
                      {product.priceLabel || (product.type === 'ready-made' ? 'Workshop Price' : 'Estimated')}
                    </span>
                  </div>

                  {/* Status Toggle Quick Buttons */}
                  <div className="flex items-center gap-1 bg-[#FAF7F2] p-1 rounded-xl border border-[#E2D9C8]">
                    <button
                      onClick={() => toggleProductStatus(product.id, 'published')}
                      title="Set to Published"
                      className={`px-2.5 py-1 rounded text-[11px] font-bold transition-all ${
                        product.status === 'published' ? 'bg-emerald-700 text-white shadow-sm' : 'text-[#8A7A6E] hover:text-[#231812]'
                      }`}
                    >
                      Publish
                    </button>
                    <button
                      onClick={() => toggleProductStatus(product.id, 'draft')}
                      title="Set to Draft"
                      className={`px-2.5 py-1 rounded text-[11px] font-bold transition-all ${
                        product.status === 'draft' ? 'bg-amber-700 text-white shadow-sm' : 'text-[#8A7A6E] hover:text-[#231812]'
                      }`}
                    >
                      Draft
                    </button>
                    <button
                      onClick={() => toggleProductStatus(product.id, 'hidden')}
                      title="Hide from Public View"
                      className={`px-2.5 py-1 rounded text-[11px] font-bold transition-all ${
                        product.status === 'hidden' ? 'bg-rose-700 text-white shadow-sm' : 'text-[#8A7A6E] hover:text-[#231812]'
                      }`}
                    >
                      Hide
                    </button>
                  </div>

                  {/* Action Icons */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleEdit(product)}
                      className="p-2 rounded-lg bg-white border border-[#E2D9C8] hover:border-[#A8763E] text-[#231812] hover:text-[#A8763E] transition-colors"
                      title="Edit Product"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => duplicateProduct(product.id)}
                      className="p-2 rounded-lg bg-white border border-[#E2D9C8] hover:border-[#A8763E] text-[#231812] hover:text-[#A8763E] transition-colors"
                      title="Duplicate as Draft"
                    >
                      <Copy className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleDelete(product.id, product.name)}
                      className="p-2 rounded-lg bg-white border border-rose-200 hover:bg-rose-50 text-rose-700 transition-colors"
                      title="Delete Product"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
