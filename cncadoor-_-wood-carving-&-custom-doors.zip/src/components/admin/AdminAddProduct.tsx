import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductItem, ProductType, ProductStatus } from '../../types';
import { 
  Package, 
  Sparkles, 
  CheckCircle2, 
  Eye, 
  Save, 
  UploadCloud, 
  Trash2, 
  ArrowLeft, 
  EyeOff, 
  Layers, 
  Ruler, 
  TreePine, 
  AlertCircle,
  Plus,
  X,
  Clock,
  ArrowRight
} from 'lucide-react';

export const AdminAddProduct: React.FC = () => {
  const { 
    addProduct, 
    updateProduct, 
    deleteProduct, 
    editingProduct, 
    setEditingProduct, 
    draftProductInCreation, 
    setDraftProductInCreation,
    setActiveAdminTab 
  } = useStore();

  // Step state: 'select-type' | 'edit-form' | 'review-preview'
  const [step, setStep] = useState<'select-type' | 'edit-form' | 'review-preview'>(() => {
    if (editingProduct) return 'edit-form';
    if (draftProductInCreation) return 'edit-form';
    return 'select-type';
  });

  const [selectedType, setSelectedType] = useState<ProductType>(
    editingProduct?.type || draftProductInCreation?.type || 'ready-made'
  );

  const [formData, setFormData] = useState<Partial<ProductItem>>({
    name: '',
    type: 'ready-made',
    category: 'Ready-made Doors',
    status: 'draft',
    price: '',
    originalPrice: '',
    priceLabel: 'Direct Workshop Price',
    inStockCount: 1,
    woodType: '100% Solid Teak Wood (Grade A)',
    dimensionsNote: '81" H x 36" W x 1.75" Thickness (Standard)',
    carvingStyle: 'Precision High-Relief CNC with Artisan Detailing',
    leadTime: 'In Stock (Ships in 24-48 hrs)',
    description: '',
    highlights: ['Kiln-seasoned anti-warp certified timber', 'Ready for on-site hanging & hardware mounting'],
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
    additionalImages: []
  });

  const [newHighlight, setNewHighlight] = useState('');
  const [showNotification, setShowNotification] = useState<{ message: string; type: 'success' | 'info' | 'warn' } | null>(null);

  // Sync with editing product or draft in context
  useEffect(() => {
    if (editingProduct) {
      setFormData(editingProduct);
      setSelectedType(editingProduct.type);
      setStep('edit-form');
    } else if (draftProductInCreation) {
      setFormData(prev => ({ ...prev, ...draftProductInCreation }));
      setSelectedType(draftProductInCreation.type || 'ready-made');
      setStep('edit-form');
    }
  }, [editingProduct, draftProductInCreation]);

  const presetImages = [
    { label: 'Lotus Heritage Teak Door', url: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Temple Sanctum Pooja Double Shutter', url: 'https://images.unsplash.com/photo-1548625361-195fe5795df5?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Acanthus Botanical Carved Panel', url: 'https://images.unsplash.com/photo-1509644851169-2acc08aa25b5?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Modern Fluted Geometric Shutter', url: 'https://images.unsplash.com/photo-1517581177682-a085bb7ffb15?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Chettinad Pillar Frame Set', url: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Artisan Bespoke CAD Carving', url: 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1200&q=80' }
  ];

  const handleSelectType = (type: ProductType) => {
    setSelectedType(type);
    setFormData(prev => ({
      ...prev,
      type,
      category: type === 'ready-made' ? 'Ready-made Doors' : 'Main Entrance Doors',
      price: type === 'ready-made' ? '₹45,000' : 'Price on Request / from ₹55,000',
      leadTime: type === 'ready-made' ? 'In Stock (Ships in 24-48 hrs)' : '12-18 Business Days Crafting Time',
      priceLabel: type === 'ready-made' ? 'Direct Workshop Price' : 'Custom Estimate Range'
    }));
    setStep('edit-form');
  };

  const handleAddHighlight = () => {
    if (!newHighlight.trim()) return;
    setFormData(prev => ({
      ...prev,
      highlights: [...(prev.highlights || []), newHighlight.trim()]
    }));
    setNewHighlight('');
  };

  const handleRemoveHighlight = (index: number) => {
    setFormData(prev => ({
      ...prev,
      highlights: (prev.highlights || []).filter((_, i) => i !== index)
    }));
  };

  const handleSaveDraft = () => {
    if (!formData.name?.trim()) {
      alert('Please enter at least a Product Name to save draft');
      return;
    }

    if (editingProduct) {
      updateProduct(editingProduct.id, { ...formData, status: 'draft' });
      setShowNotification({ message: 'Product draft updated successfully!', type: 'info' });
    } else {
      const created = addProduct({
        name: formData.name,
        type: selectedType,
        category: formData.category || 'Ready-made Doors',
        status: 'draft',
        price: formData.price,
        originalPrice: formData.originalPrice,
        priceLabel: formData.priceLabel,
        inStockCount: formData.inStockCount,
        woodType: formData.woodType || 'Solid Teak Wood',
        dimensionsNote: formData.dimensionsNote || 'Standard Dimensions',
        carvingStyle: formData.carvingStyle,
        leadTime: formData.leadTime,
        description: formData.description || 'Crafted with master woodworking precision in Adoor.',
        highlights: formData.highlights || [],
        imageUrl: formData.imageUrl || presetImages[0].url,
        additionalImages: formData.additionalImages || [],
        featured: formData.featured || false
      });
      setEditingProduct(created);
      setShowNotification({ message: 'Saved as Draft! You can review or edit before publishing.', type: 'info' });
    }

    setTimeout(() => {
      setShowNotification(null);
    }, 4000);
  };

  const handlePublish = () => {
    if (!formData.name?.trim()) {
      alert('Please provide a product title before publishing.');
      return;
    }

    if (editingProduct) {
      updateProduct(editingProduct.id, { ...formData, status: 'published' });
      setShowNotification({ message: '🎉 Product Published live on website!', type: 'success' });
    } else {
      addProduct({
        name: formData.name,
        type: selectedType,
        category: formData.category || 'Ready-made Doors',
        status: 'published',
        price: formData.price,
        originalPrice: formData.originalPrice,
        priceLabel: formData.priceLabel,
        inStockCount: formData.inStockCount,
        woodType: formData.woodType || 'Solid Teak Wood',
        dimensionsNote: formData.dimensionsNote || 'Standard Dimensions',
        carvingStyle: formData.carvingStyle,
        leadTime: formData.leadTime,
        description: formData.description || 'Crafted with master woodworking precision in Adoor.',
        highlights: formData.highlights || [],
        imageUrl: formData.imageUrl || presetImages[0].url,
        additionalImages: formData.additionalImages || [],
        featured: formData.featured || false
      });
      setShowNotification({ message: '🎉 New Product Published live on CNCADOOR!', type: 'success' });
    }

    setTimeout(() => {
      setEditingProduct(null);
      setDraftProductInCreation(null);
      setActiveAdminTab('products');
    }, 1500);
  };

  const handleHideUnpublish = () => {
    if (editingProduct) {
      updateProduct(editingProduct.id, { status: 'hidden' });
      setShowNotification({ message: 'Product hidden/unpublished from public view.', type: 'warn' });
      setTimeout(() => {
        setEditingProduct(null);
        setActiveAdminTab('products');
      }, 1500);
    }
  };

  const handleDelete = () => {
    if (editingProduct && window.confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
      deleteProduct(editingProduct.id);
      setEditingProduct(null);
      setActiveAdminTab('products');
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-5xl mx-auto pb-12">
      
      {/* Toast Notification */}
      {showNotification && (
        <div className={`p-4 rounded-xl border flex items-center justify-between shadow-lg text-sm ${
          showNotification.type === 'success'
            ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
            : showNotification.type === 'warn'
            ? 'bg-amber-50 border-amber-300 text-amber-800'
            : 'bg-blue-50 border-blue-300 text-blue-800'
        }`}>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            <span className="font-semibold">{showNotification.message}</span>
          </div>
          <button onClick={() => setShowNotification(null)}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header & Flow Indicator */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2D9C8] pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#8A7A6E] mb-1">
            <span>Admin</span>
            <span>/</span>
            <span className="font-semibold text-[#A8763E]">
              {editingProduct ? 'Edit Existing Product' : 'Add New Product'}
            </span>
          </div>
          <h1 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#231812]">
            {editingProduct ? `Editing: ${editingProduct.name}` : 'Create & Publish Product'}
          </h1>
        </div>

        {/* 3-Step Flow Pills */}
        <div className="flex items-center gap-2 text-xs">
          <div className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 ${
            step === 'select-type' ? 'bg-[#2B1810] text-white' : 'bg-emerald-100 text-emerald-800'
          }`}>
            <span>1. Choose Type</span>
          </div>
          <span className="text-[#8A7A6E]">→</span>
          <div className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 ${
            step === 'edit-form' ? 'bg-[#2B1810] text-white' : step === 'review-preview' ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-400'
          }`}>
            <span>2. Details</span>
          </div>
          <span className="text-[#8A7A6E]">→</span>
          <div className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 ${
            step === 'review-preview' ? 'bg-[#A8763E] text-white' : 'bg-gray-100 text-gray-400'
          }`}>
            <span>3. Review & Publish</span>
          </div>
        </div>
      </div>

      {/* STEP 1: SELECT TYPE */}
      {step === 'select-type' && (
        <div className="space-y-6">
          <div className="text-center max-w-xl mx-auto mb-8">
            <h2 className="font-serif-luxury text-2xl font-bold text-[#231812] mb-2">
              What type of product are you adding?
            </h2>
            <p className="text-sm text-[#57473B]">
              Choose whether this is an in-stock ready-for-pickup item or a customizable commission offering.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
            {/* Option 1: Ready-made */}
            <div 
              onClick={() => handleSelectType('ready-made')}
              className="bg-white border-2 border-[#E2D9C8] hover:border-[#A8763E] rounded-2xl p-8 cursor-pointer group transition-all duration-300 shadow-sm hover:shadow-xl flex flex-col justify-between"
            >
              <div>
                <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Package className="w-7 h-7" />
                </div>
                <div className="inline-block px-2.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[11px] font-bold uppercase mb-2">
                  In-Stock Inventory
                </div>
                <h3 className="font-serif-luxury text-2xl font-bold text-[#231812] mb-3 group-hover:text-[#A8763E] transition-colors">
                  Ready-Made Product
                </h3>
                <p className="text-xs sm:text-sm text-[#57473B] leading-relaxed mb-6">
                  Pre-crafted finished doors, pooja mandapams, and wall panels in stock at your workshop. Features fixed pricing, instant stock count, and direct customer workshop pickup.
                </p>
              </div>

              <div className="pt-4 border-t border-[#E2D9C8] flex items-center justify-between text-xs font-bold text-[#A8763E]">
                <span>Set Up Ready Product</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Option 2: Customized */}
            <div 
              onClick={() => handleSelectType('customized')}
              className="bg-white border-2 border-[#E2D9C8] hover:border-[#A8763E] rounded-2xl p-8 cursor-pointer group transition-all duration-300 shadow-sm hover:shadow-xl flex flex-col justify-between"
            >
              <div>
                <div className="w-14 h-14 rounded-2xl bg-amber-50 text-[#A8763E] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Sparkles className="w-7 h-7" />
                </div>
                <div className="inline-block px-2.5 py-0.5 rounded bg-amber-100 text-[#A8763E] text-[11px] font-bold uppercase mb-2">
                  Bespoke Commission
                </div>
                <h3 className="font-serif-luxury text-2xl font-bold text-[#231812] mb-3 group-hover:text-[#A8763E] transition-colors">
                  Customized Door / Carving
                </h3>
                <p className="text-xs sm:text-sm text-[#57473B] leading-relaxed mb-6">
                  Custom designs carved to customer specifications, architectural drawings, or reference photos. Features price estimates, wood selection, and custom lead time.
                </p>
              </div>

              <div className="pt-4 border-t border-[#E2D9C8] flex items-center justify-between text-xs font-bold text-[#A8763E]">
                <span>Set Up Custom Offering</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: EDIT FORM */}
      {step === 'edit-form' && (
        <div className="bg-white rounded-2xl border border-[#E2D9C8] p-6 sm:p-10 shadow-sm space-y-8">
          
          {/* Top Switcher Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#FAF7F2] rounded-xl border border-[#E2D9C8]">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#8A7A6E]">Product Mode:</span>
              <button
                type="button"
                onClick={() => handleSelectType('ready-made')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedType === 'ready-made' ? 'bg-[#2B1810] text-[#FAF7F2]' : 'bg-white text-[#57473B] border border-[#E2D9C8]'
                }`}
              >
                Ready-Made
              </button>
              <button
                type="button"
                onClick={() => handleSelectType('customized')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedType === 'customized' ? 'bg-[#2B1810] text-[#FAF7F2]' : 'bg-white text-[#57473B] border border-[#E2D9C8]'
                }`}
              >
                Customized
              </button>
            </div>

            {editingProduct && (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-[#8A7A6E]">Current Status:</span>
                <span className={`px-2.5 py-0.5 rounded font-bold uppercase text-[10px] ${
                  editingProduct.status === 'published' ? 'bg-emerald-100 text-emerald-800' : editingProduct.status === 'hidden' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                }`}>
                  {editingProduct.status}
                </span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            
            {/* Product Name */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                Product Title / Name *
              </label>
              <input
                type="text"
                value={formData.name || ''}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder={selectedType === 'ready-made' ? 'e.g., Heritage Lotus Teak Entrance Door (In-Stock)' : 'e.g., Imperial Double Entrance Door Commission'}
                className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-sm font-semibold text-[#231812]"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                Category
              </label>
              <select
                value={formData.category || 'Ready-made Doors'}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-sm text-[#231812] bg-white"
              >
                {selectedType === 'ready-made' ? (
                  <>
                    <option value="Ready-made Doors">Ready-made Doors</option>
                    <option value="Pooja Mandapams">Pooja Mandapams</option>
                    <option value="Carved Wall Panels">Carved Wall Panels</option>
                    <option value="Contemporary Wooden Doors">Contemporary Wooden Doors</option>
                  </>
                ) : (
                  <>
                    <option value="Main Entrance Doors">Main Entrance Doors</option>
                    <option value="Traditional Doors">Traditional Doors</option>
                    <option value="Carved Doors">Carved Doors</option>
                    <option value="Temple-Inspired Designs">Temple-Inspired Designs</option>
                    <option value="Contemporary Wooden Doors">Contemporary Wooden Doors</option>
                    <option value="Custom Designs">Custom Designs</option>
                  </>
                )}
              </select>
            </div>

            {/* Timber Type */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                Wood / Timber Species
              </label>
              <input
                type="text"
                value={formData.woodType || ''}
                onChange={(e) => setFormData({ ...formData, woodType: e.target.value })}
                placeholder="e.g. 100% Solid Teak Wood / Kerala Anjili / Rosewood"
                className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-sm text-[#231812]"
              />
            </div>

            {/* Price */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                {selectedType === 'ready-made' ? 'Price (₹) *' : 'Estimated Price Range'}
              </label>
              <input
                type="text"
                value={formData.price || ''}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                placeholder={selectedType === 'ready-made' ? '₹46,500' : 'From ₹65,000 / Price on Request'}
                className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-sm font-semibold text-[#231812]"
              />
            </div>

            {/* Original Price (for Discount / Comparison) */}
            {selectedType === 'ready-made' && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                  Original / MRP Price (₹) (Optional Strikethrough)
                </label>
                <input
                  type="text"
                  value={formData.originalPrice || ''}
                  onChange={(e) => setFormData({ ...formData, originalPrice: e.target.value })}
                  placeholder="₹52,000"
                  className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-sm text-[#231812]"
                />
              </div>
            )}

            {/* Stock Count */}
            {selectedType === 'ready-made' && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                  Available In-Stock Count
                </label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={formData.inStockCount || 1}
                  onChange={(e) => setFormData({ ...formData, inStockCount: parseInt(e.target.value) || 1 })}
                  className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-sm text-[#231812]"
                />
              </div>
            )}

            {/* Dimensions Note */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                Dimensions / Sizing Note
              </label>
              <input
                type="text"
                value={formData.dimensionsNote || ''}
                onChange={(e) => setFormData({ ...formData, dimensionsNote: e.target.value })}
                placeholder="e.g. 81 in H x 36 in W x 1.75 in Thickness or Custom Sizing"
                className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-sm text-[#231812]"
              />
            </div>

            {/* Lead Time */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                Availability / Crafting Lead Time
              </label>
              <input
                type="text"
                value={formData.leadTime || ''}
                onChange={(e) => setFormData({ ...formData, leadTime: e.target.value })}
                placeholder={selectedType === 'ready-made' ? 'Ready for Workshop Pickup (Adoor)' : '10-15 Days (Crafted for Workshop Pickup)'}
                className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-sm text-[#231812]"
              />
            </div>

            {/* Description */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                Description & Craftsmanship Details
              </label>
              <textarea
                rows={3}
                value={formData.description || ''}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe the carving motifs, polish, wood grain, and design aesthetics..."
                className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-sm text-[#231812]"
              />
            </div>

            {/* Highlights List */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812] mb-2">
                Key Features & Highlights
              </label>
              <div className="flex gap-2 mb-3">
                <input
                  type="text"
                  value={newHighlight}
                  onChange={(e) => setNewHighlight(e.target.value)}
                  placeholder="Add a key feature (e.g. Pre-seasoned anti-warp teak)..."
                  className="flex-1 px-4 py-2.5 rounded-xl border border-[#E2D9C8] text-sm"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddHighlight();
                    }
                  }}
                />
                <button
                  type="button"
                  onClick={handleAddHighlight}
                  className="px-4 py-2.5 rounded-xl bg-[#2B1810] text-white text-xs font-bold uppercase tracking-wider"
                >
                  Add
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {formData.highlights?.map((h, i) => (
                  <span key={i} className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-[#FAF7F2] border border-[#E2D9C8] text-xs text-[#231812]">
                    <span>{h}</span>
                    <button type="button" onClick={() => handleRemoveHighlight(i)} className="text-[#8A7A6E] hover:text-rose-600">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Image URL & Preset Selection */}
            <div className="sm:col-span-2 space-y-3">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#231812]">
                Product Image URL
              </label>
              <input
                type="url"
                value={formData.imageUrl || ''}
                onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                placeholder="https://images.unsplash.com/..."
                className="w-full px-4 py-3 rounded-xl border border-[#E2D9C8] focus:border-[#A8763E] focus:outline-none text-xs font-mono text-[#231812]"
              />

              {/* Quick Pick Workshop Photos */}
              <div className="space-y-1.5">
                <span className="text-[11px] text-[#8A7A6E] font-medium block">
                  Or select from high-res workshop catalog presets:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
                  {presetImages.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setFormData({ ...formData, imageUrl: preset.url })}
                      className={`relative aspect-[4/3] rounded-lg overflow-hidden border-2 transition-all ${
                        formData.imageUrl === preset.url ? 'border-[#A8763E] ring-2 ring-[#A8763E]/30' : 'border-transparent opacity-75 hover:opacity-100'
                      }`}
                    >
                      <img src={preset.url} alt={preset.label} className="w-full h-full object-cover" />
                      <div className="absolute inset-x-0 bottom-0 bg-black/60 text-[9px] text-white p-1 truncate text-center">
                        {preset.label}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

          </div>

          {/* Action Bar (Save Draft, Review, Publish, Delete, Hide) */}
          <div className="pt-6 border-t border-[#E2D9C8] flex flex-wrap items-center justify-between gap-4">
            
            {/* Left: Delete or Hide buttons */}
            <div className="flex items-center gap-2">
              {editingProduct && (
                <>
                  <button
                    type="button"
                    onClick={handleHideUnpublish}
                    className="px-4 py-2.5 rounded-xl border border-amber-300 bg-amber-50 text-amber-800 text-xs font-bold flex items-center gap-1.5 hover:bg-amber-100 transition-colors"
                  >
                    <EyeOff className="w-4 h-4" />
                    <span>Unpublish / Hide</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDelete}
                    className="px-4 py-2.5 rounded-xl border border-rose-300 bg-rose-50 text-rose-800 text-xs font-bold flex items-center gap-1.5 hover:bg-rose-100 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Delete</span>
                  </button>
                </>
              )}
            </div>

            {/* Right: Save Draft, Review, Publish */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleSaveDraft}
                className="px-5 py-2.5 rounded-xl bg-white border border-[#A8763E] text-[#A8763E] hover:bg-[#FAF7F2] text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>Save Draft</span>
              </button>

              <button
                type="button"
                onClick={() => setStep('review-preview')}
                className="px-5 py-2.5 rounded-xl bg-[#FAF7F2] border border-[#2B1810] text-[#231812] hover:bg-[#EADCC9]/50 text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors shadow-sm"
              >
                <Eye className="w-4 h-4 text-[#A8763E]" />
                <span>Review Customer Preview</span>
              </button>

              <button
                type="button"
                onClick={handlePublish}
                className="px-6 py-2.5 rounded-xl bg-[#2B1810] hover:bg-[#A8763E] text-[#FAF7F2] text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all shadow-md active:scale-95"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Publish to Website</span>
              </button>
            </div>

          </div>

        </div>
      )}

      {/* STEP 3: REVIEW / LIVE PREVIEW */}
      {step === 'review-preview' && (
        <div className="space-y-6">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center justify-between text-xs text-amber-900">
            <div className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-amber-700" />
              <span>
                <strong>Live Preview Mode:</strong> This is exactly how customers will see this item on the public website.
              </span>
            </div>
            <button
              onClick={() => setStep('edit-form')}
              className="font-bold underline uppercase tracking-wider text-[#A8763E]"
            >
              Back to Edit
            </button>
          </div>

          {/* Preview Card */}
          <div className="max-w-md mx-auto bg-white rounded-2xl border border-[#E2D9C8] overflow-hidden shadow-xl">
            <div className="relative aspect-[4/3] bg-black/5">
              <img
                src={formData.imageUrl || presetImages[0].url}
                alt={formData.name || 'Preview'}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-3 left-3 bg-emerald-700 text-white px-2.5 py-1 rounded text-[11px] font-bold uppercase">
                {formData.leadTime || (selectedType === 'ready-made' ? 'In Stock' : 'Custom Commission')}
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#A8763E]">
                  {formData.category}
                </span>
                <h3 className="font-serif-luxury text-xl font-bold text-[#231812]">
                  {formData.name || 'Untitled Door'}
                </h3>
              </div>

              <p className="text-xs text-[#57473B]">
                {formData.description || 'No description provided.'}
              </p>

              <div className="space-y-1.5 p-3 rounded-xl bg-[#FAF7F2] text-xs text-[#57473B] border border-[#E2D9C8]">
                <div><strong>Wood:</strong> {formData.woodType}</div>
                <div><strong>Size:</strong> {formData.dimensionsNote}</div>
              </div>

              <div className="flex items-baseline justify-between pt-2">
                <div>
                  <span className="font-serif-luxury text-2xl font-bold text-[#231812]">
                    {formData.price || 'Price on Request'}
                  </span>
                  {formData.originalPrice && (
                    <span className="text-xs text-[#8A7A6E] line-through ml-2">
                      {formData.originalPrice}
                    </span>
                  )}
                </div>
                <span className="px-3 py-1 rounded-lg bg-[#25D366] text-white text-xs font-bold">
                  WhatsApp Order
                </span>
              </div>
            </div>
          </div>

          {/* Review Decision Buttons */}
          <div className="flex items-center justify-center gap-4 pt-6">
            <button
              onClick={() => setStep('edit-form')}
              className="px-6 py-3 rounded-xl bg-white border border-[#E2D9C8] hover:border-[#A8763E] text-xs font-bold uppercase tracking-wider text-[#231812]"
            >
              ← Edit Details
            </button>
            <button
              onClick={handleSaveDraft}
              className="px-6 py-3 rounded-xl bg-white border border-[#A8763E] text-[#A8763E] text-xs font-bold uppercase tracking-wider"
            >
              Save as Draft
            </button>
            <button
              onClick={handlePublish}
              className="px-8 py-3 rounded-xl bg-[#2B1810] hover:bg-[#A8763E] text-white text-xs font-bold uppercase tracking-widest shadow-lg flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Looks Good — Publish Now</span>
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
