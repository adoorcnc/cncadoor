import React from 'react';
import { useStore } from '../../context/StoreContext';
import { 
  Package, 
  ShoppingBag, 
  MessageSquare, 
  Sparkles, 
  TrendingUp, 
  Plus, 
  Clock, 
  Eye, 
  CheckCircle2, 
  ArrowUpRight,
  PhoneCall,
  Image as ImageIcon,
  History,
  Shield,
  FileText
} from 'lucide-react';

export const AdminOverview: React.FC = () => {
  const { 
    products, 
    publishedProducts, 
    readyMadeProducts, 
    customizedProducts, 
    enquiries, 
    activityLogs,
    setActiveAdminTab,
    setEditingProduct,
    setDraftProductInCreation
  } = useStore();

  const draftProducts = products.filter(p => p.status === 'draft');
  const hiddenProducts = products.filter(p => p.status === 'hidden');
  const newEnquiries = enquiries.filter(e => e.status === 'New');
  const customRequests = enquiries.filter(e => e.type === 'custom_request');
  const readyMadeOrders = enquiries.filter(e => e.type === 'ready_made_order');

  const handleStartAddProduct = (type: 'ready-made' | 'customized') => {
    setEditingProduct(null);
    setDraftProductInCreation({
      type,
      name: '',
      category: type === 'ready-made' ? 'Ready-made Doors' : 'Main Entrance Doors',
      status: 'draft',
      woodType: 'Solid Teak Wood',
      dimensionsNote: '',
      description: '',
      highlights: [],
      imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80'
    });
    setActiveAdminTab('add-product');
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#2B1810] to-[#42261A] rounded-2xl p-6 sm:p-8 text-[#FAF7F2] shadow-md border border-[#A8763E]/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FAF7F2]/10 border border-[#FAF7F2]/20 text-xs text-[#D4AF37] font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Owner & Business Dashboard</span>
          </div>
          <h1 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-white">
            Welcome to CNCADOOR Workshop Admin
          </h1>
          <p className="text-xs sm:text-sm text-[#D7CCC8] mt-1 max-w-2xl leading-relaxed">
            Manage your ready-made stock, customized door catalogue, customer quote inquiries, and workshop orders in one unified system.
          </p>
        </div>

        {/* Quick Add Product Buttons */}
        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => handleStartAddProduct('ready-made')}
            className="px-4 py-2.5 rounded-xl bg-[#A8763E] hover:bg-[#8F6232] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-transform active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add Ready-Made</span>
          </button>

          <button
            onClick={() => handleStartAddProduct('customized')}
            className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Customized</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        
        {/* Total Published Products */}
        <div 
          onClick={() => setActiveAdminTab('products')}
          className="bg-white border border-[#E2D9C8] hover:border-[#A8763E] rounded-2xl p-5 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-[#8A7A6E] uppercase tracking-wider">Live Catalog</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Package className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="font-serif-luxury text-3xl font-bold text-[#231812]">
              {publishedProducts.length}
            </span>
            <span className="text-xs text-emerald-700 font-medium bg-emerald-50 px-2 py-0.5 rounded">
              Published
            </span>
          </div>
          <div className="mt-2 text-xs text-[#8A7A6E] flex items-center gap-2">
            <span>{readyMadeProducts.length} Ready-made</span>
            <span>•</span>
            <span>{customizedProducts.length} Custom</span>
          </div>
        </div>

        {/* Drafts & Hidden */}
        <div 
          onClick={() => setActiveAdminTab('products')}
          className="bg-white border border-[#E2D9C8] hover:border-[#A8763E] rounded-2xl p-5 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-[#8A7A6E] uppercase tracking-wider">Drafts & Hidden</span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="font-serif-luxury text-3xl font-bold text-[#231812]">
              {draftProducts.length + hiddenProducts.length}
            </span>
            <span className="text-xs text-amber-700 font-medium bg-amber-50 px-2 py-0.5 rounded">
              Unpublished
            </span>
          </div>
          <div className="mt-2 text-xs text-[#8A7A6E] flex items-center gap-2">
            <span>{draftProducts.length} Drafts</span>
            <span>•</span>
            <span>{hiddenProducts.length} Hidden</span>
          </div>
        </div>

        {/* New Enquiries */}
        <div 
          onClick={() => setActiveAdminTab('orders')}
          className="bg-white border border-[#E2D9C8] hover:border-[#A8763E] rounded-2xl p-5 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-[#8A7A6E] uppercase tracking-wider">New Inquiries</span>
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <MessageSquare className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="font-serif-luxury text-3xl font-bold text-[#231812]">
              {newEnquiries.length}
            </span>
            <span className="text-xs text-rose-700 font-medium bg-rose-50 px-2 py-0.5 rounded animate-pulse">
              Needs Reply
            </span>
          </div>
          <div className="mt-2 text-xs text-[#8A7A6E]">
            {enquiries.length} Total orders & quotes in log
          </div>
        </div>

        {/* Custom Design Requests */}
        <div 
          onClick={() => setActiveAdminTab('custom-requests')}
          className="bg-white border border-[#E2D9C8] hover:border-[#A8763E] rounded-2xl p-5 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-[#8A7A6E] uppercase tracking-wider">Custom Requests</span>
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="font-serif-luxury text-3xl font-bold text-[#231812]">
              {customRequests.length}
            </span>
            <span className="text-xs text-indigo-700 font-medium bg-indigo-50 px-2 py-0.5 rounded">
              Image / CAD Specs
            </span>
          </div>
          <div className="mt-2 text-xs text-[#8A7A6E]">
            {readyMadeOrders.length} Ready-made orders
          </div>
        </div>

      </div>

      {/* Main Grid: Recent Enquiries + Quick Management */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left 2 Cols: Recent Enquiries */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-[#E2D9C8] p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="font-serif-luxury text-xl font-bold text-[#231812]">
                Recent Inquiries & Orders
              </h2>
              <p className="text-xs text-[#8A7A6E]">Incoming customer requirements and direct orders</p>
            </div>
            <button
              onClick={() => setActiveAdminTab('orders')}
              className="text-xs font-bold uppercase tracking-wider text-[#A8763E] hover:text-[#231812] flex items-center gap-1"
            >
              <span>View All ({enquiries.length})</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {enquiries.length === 0 ? (
            <div className="text-center py-12 text-sm text-[#8A7A6E]">
              No inquiries logged yet. They will appear here when customers submit forms or WhatsApp inquiries.
            </div>
          ) : (
            <div className="divide-y divide-[#E2D9C8]/60">
              {enquiries.slice(0, 5).map((enq) => (
                <div key={enq.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-[#FAF7F2] p-3 rounded-xl transition-colors">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-[#231812]">{enq.customerName}</span>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        enq.status === 'New' 
                          ? 'bg-rose-100 text-rose-800' 
                          : enq.status === 'Quotation Sent'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {enq.status}
                      </span>
                      <span className="text-[11px] text-[#8A7A6E]">
                        {new Date(enq.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-xs text-[#57473B] font-medium">
                      {enq.productTitle} • <span className="text-[#A8763E]">{enq.woodPreference || 'Teak Wood'}</span>
                    </p>
                    <p className="text-xs text-[#8A7A6E] line-clamp-1">
                      {enq.requirement}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <a
                      href={`https://wa.me/91${enq.phone}?text=Hello%20${encodeURIComponent(enq.customerName)},%20regarding%20your%20CNCADOOR%20quote%20request%20for%20${encodeURIComponent(enq.productTitle)}...`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-[#25D366] text-white text-xs font-bold flex items-center gap-1 shadow-sm hover:bg-[#20b858]"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                    <a
                      href={`tel:${enq.phone}`}
                      className="px-3 py-1.5 rounded-lg bg-white border border-[#E2D9C8] text-[#231812] text-xs font-bold flex items-center gap-1 hover:border-[#A8763E]"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-[#A8763E]" />
                      <span>Call</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Col: Quick Product Management shortcuts */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-[#E2D9C8] p-6 shadow-sm">
            <h3 className="font-serif-luxury text-lg font-bold text-[#231812] mb-3">
              Owner Action Center
            </h3>
            <p className="text-xs text-[#57473B] mb-6 leading-relaxed">
              As the business owner and seller, easily post new inventory, edit prices, or hide items from the public website instantly.
            </p>

            <div className="space-y-3">
              <button
                onClick={() => handleStartAddProduct('ready-made')}
                className="w-full p-3.5 rounded-xl bg-[#FAF7F2] hover:bg-[#EADCC9]/50 border border-[#E2D9C8] text-left transition-colors flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-xs text-[#231812] flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-[#A8763E]" />
                    <span>Post Ready-Made Door / Panel</span>
                  </div>
                  <div className="text-[11px] text-[#8A7A6E]">In-stock price, dimensions, photos</div>
                </div>
                <Plus className="w-4 h-4 text-[#A8763E]" />
              </button>

              <button
                onClick={() => handleStartAddProduct('customized')}
                className="w-full p-3.5 rounded-xl bg-[#FAF7F2] hover:bg-[#EADCC9]/50 border border-[#E2D9C8] text-left transition-colors flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-xs text-[#231812] flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-[#A8763E]" />
                    <span>Add Custom Design Offering</span>
                  </div>
                  <div className="text-[11px] text-[#8A7A6E]">Estimated quote range, CAD options</div>
                </div>
                <Plus className="w-4 h-4 text-[#A8763E]" />
              </button>

              <button
                onClick={() => setActiveAdminTab('products')}
                className="w-full p-3.5 rounded-xl bg-[#FAF7F2] hover:bg-[#EADCC9]/50 border border-[#E2D9C8] text-left transition-colors flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-xs text-[#231812] flex items-center gap-1.5">
                    <Eye className="w-4 h-4 text-[#A8763E]" />
                    <span>Manage / Hide Existing Products</span>
                  </div>
                  <div className="text-[11px] text-[#8A7A6E]">Publish, unpublish, draft, or delete</div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#A8763E]" />
              </button>

              <button
                onClick={() => setActiveAdminTab('settings')}
                className="w-full p-3.5 rounded-xl bg-[#FAF7F2] hover:bg-[#EADCC9]/50 border border-[#E2D9C8] text-left transition-colors flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-xs text-[#231812]">Website Contact & Phone Settings</div>
                  <div className="text-[11px] text-[#8A7A6E]">Update WhatsApp, workshop timings</div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#A8763E]" />
              </button>
            </div>
          </div>

          {/* Recent Administrative Activity Log Card */}
          <div className="bg-white rounded-2xl border border-[#E2D9C8] p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-[#A8763E]" />
                <h3 className="font-serif-luxury text-base font-bold text-[#231812]">
                  Recent Activity Audit
                </h3>
              </div>
              <button
                onClick={() => setActiveAdminTab('activity-log')}
                className="text-[11px] font-bold text-[#A8763E] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>View Full Log</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-xs text-[#57473B] leading-relaxed">
              Recent recorded operations on doors, quote statuses, and administrative access.
            </p>

            <div className="space-y-2.5">
              {activityLogs.slice(0, 4).map((log) => (
                <div 
                  key={log.id} 
                  onClick={() => setActiveAdminTab('activity-log')}
                  className="p-2.5 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8]/80 hover:border-[#A8763E] transition-colors cursor-pointer group"
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-bold text-xs text-[#231812] group-hover:text-[#A8763E] transition-colors line-clamp-1">
                      {log.title}
                    </span>
                    <span className="text-[10px] text-[#8A7A6E] shrink-0 font-medium">
                      {new Date(log.timestamp).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#57473B] line-clamp-1 mt-0.5">
                    {log.details}
                  </p>
                  <div className="flex items-center gap-2 mt-1 text-[10px] text-[#8A7A6E]">
                    <span className="font-semibold text-[#8F6232]">{log.performedBy}</span>
                    {log.meta?.badgeText && (
                      <>
                        <span>•</span>
                        <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 font-medium">
                          {log.meta.badgeText}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setActiveAdminTab('activity-log')}
              className="w-full py-2 rounded-xl bg-[#FAF7F2] hover:bg-[#EADCC9]/50 border border-[#E2D9C8] text-xs font-bold text-[#231812] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>Explore All {activityLogs.length} Logged Entries</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#A8763E]" />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
