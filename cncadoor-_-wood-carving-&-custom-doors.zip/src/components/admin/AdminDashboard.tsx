import React from 'react';
import { useStore } from '../../context/StoreContext';
import { useAuth } from '../../context/AuthContext';
import { AdminTab } from '../../types';
import { AdminOverview } from './AdminOverview';
import { AdminAddProduct } from './AdminAddProduct';
import { AdminProductsList } from './AdminProductsList';
import { AdminOrdersEnquiries } from './AdminOrdersEnquiries';
import { AdminCustomRequests } from './AdminCustomRequests';
import { AdminGalleryManager } from './AdminGalleryManager';
import { AdminSettings } from './AdminSettings';
import { AdminActivityLog } from './AdminActivityLog';
import { 
  LayoutDashboard, 
  PlusCircle, 
  Package, 
  ShoppingBag, 
  Sparkles, 
  Image as ImageIcon, 
  Settings, 
  ExternalLink, 
  Globe, 
  LogOut,
  Layers,
  ChevronRight,
  Clock,
  Columns,
  Store,
  History
} from 'lucide-react';

interface AdminDashboardProps {
  onReturnToPublicSite: () => void;
  isSplitPane?: boolean;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  onReturnToPublicSite,
  isSplitPane = false 
}) => {
  const { 
    activeAdminTab, 
    setActiveAdminTab, 
    products, 
    enquiries, 
    activityLogs,
    setIsAdminMode,
    adminDualViewMode,
    setAdminDualViewMode,
    setEditingProduct,
    setDraftProductInCreation 
  } = useStore();
  const { logout, user } = useAuth();

  const newEnquiriesCount = enquiries.filter(e => e.status === 'New').length;
  const draftCount = products.filter(p => p.status === 'draft').length;

  const navItems: { id: AdminTab; label: string; icon: React.ReactNode; badge?: string | number; badgeColor?: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'add-product', label: 'Add Product', icon: <PlusCircle className="w-4 h-4" /> },
    { id: 'products', label: 'Products', icon: <Package className="w-4 h-4" />, badge: products.length },
    { 
      id: 'orders', 
      label: 'Orders / Enquiries', 
      icon: <ShoppingBag className="w-4 h-4" />, 
      badge: newEnquiriesCount > 0 ? newEnquiriesCount : undefined,
      badgeColor: 'bg-rose-500 text-white'
    },
    { id: 'custom-requests', label: 'Custom Requests', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'gallery', label: 'Gallery', icon: <ImageIcon className="w-4 h-4" /> },
    { 
      id: 'activity-log', 
      label: 'Activity Log', 
      icon: <History className="w-4 h-4" />,
      badge: activityLogs.length > 0 ? activityLogs.length : undefined
    },
    { id: 'settings', label: 'Website Settings', icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <div className={`min-h-screen bg-[#F7F4EE] text-[#231812] flex flex-col font-sans ${isSplitPane ? 'min-h-full' : ''}`}>
      
      {/* Top Admin Bar - only shown when not embedded in split pane */}
      {!isSplitPane && (
        <header className="bg-[#2B1810] text-[#FAF7F2] border-b border-[#A8763E]/30 sticky top-0 z-40 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            
            {/* Brand & Admin Badge */}
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#A8763E] text-white flex items-center justify-center font-serif-luxury font-bold text-lg shadow-sm">
                C
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-serif-luxury font-bold tracking-wider text-base text-white">CNCADOOR</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest bg-[#A8763E] text-white">
                    Owner Admin
                  </span>
                </div>
                <span className="text-[10px] text-[#D7CCC8] tracking-widest font-mono block">
                  Direct Workshop Management • adoorcnc@gmail.com
                </span>
              </div>
            </div>

            {/* Quick Dual View Actions */}
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setAdminDualViewMode('split')}
                className="px-3.5 py-2 rounded-xl bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 border border-[#D4AF37]/40 text-[#D4AF37] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                title="View Admin Panel and Live Storefront Side-by-Side"
              >
                <Columns className="w-4 h-4 text-[#D4AF37]" />
                <span className="hidden sm:inline">Both Sides (Split)</span>
                <span className="sm:hidden">Split</span>
              </button>

              <button
                onClick={() => setAdminDualViewMode('storefront')}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-[#FAF7F2] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                title="Switch to full customer storefront"
              >
                <Store className="w-4 h-4 text-[#D4AF37]" />
                <span>Store Front</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-70" />
              </button>
            </div>

          </div>
        </header>
      )}

      {/* Main Layout Container */}
      <div className={`flex-1 w-full mx-auto flex flex-col md:flex-row ${
        isSplitPane 
          ? 'px-3 sm:px-4 py-4 gap-4 max-w-full' 
          : 'max-w-7xl px-4 sm:px-6 lg:px-8 py-8 gap-8'
      }`}>
        
        {/* Left Navigation Sidebar */}
        <aside className={`${isSplitPane ? 'w-full md:w-56' : 'w-full md:w-64'} flex-shrink-0`}>
          <div className="bg-white rounded-2xl border border-[#E2D9C8] p-4 shadow-sm sticky top-20 space-y-5">
            
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[#8A7A6E] px-3 mb-2 block font-mono">
                Admin Navigation
              </span>
              <nav className="space-y-1">
                {navItems.map((item) => {
                  const isActive = activeAdminTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        if (item.id === 'add-product' && activeAdminTab !== 'add-product') {
                          setEditingProduct(null);
                          setDraftProductInCreation(null);
                        }
                        setActiveAdminTab(item.id);
                      }}
                      className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-wider transition-all duration-200 cursor-pointer ${
                        isActive
                          ? 'bg-[#2B1810] text-[#FAF7F2] shadow-sm'
                          : 'text-[#57473B] hover:bg-[#FAF7F2] hover:text-[#231812]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className={isActive ? 'text-[#D4AF37]' : 'text-[#A8763E]'}>
                          {item.icon}
                        </span>
                        <span>{item.label}</span>
                      </div>

                      {item.badge !== undefined && (
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          item.badgeColor || (isActive ? 'bg-white/20 text-white' : 'bg-[#FAF7F2] text-[#8A7A6E] border border-[#E2D9C8]')
                        }`}>
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Quick Status Box */}
            <div className="p-3 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] text-xs space-y-2">
              <div className="flex items-center justify-between text-[#8A7A6E]">
                <span>Total Live Catalog:</span>
                <span className="font-bold text-[#231812]">{products.filter(p => p.status === 'published').length}</span>
              </div>
              <div className="flex items-center justify-between text-[#8A7A6E]">
                <span>Drafts / Unpublished:</span>
                <span className="font-bold text-amber-800">{draftCount}</span>
              </div>
              <div className="flex items-center justify-between text-[#8A7A6E]">
                <span>Unaddressed Leads:</span>
                <span className="font-bold text-rose-700">{newEnquiriesCount}</span>
              </div>
            </div>

            {/* Dual Mode Switcher in Sidebar */}
            <div className="pt-1 space-y-2 border-t border-[#E8E1D5]">
              <span className="text-[10px] uppercase font-bold tracking-widest text-[#8A7A6E] block font-mono">
                View Switcher
              </span>

              <button
                onClick={() => setAdminDualViewMode('split')}
                className={`w-full py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  adminDualViewMode === 'split'
                    ? 'bg-[#D4AF37] text-[#231812] border-[#D4AF37] shadow-xs'
                    : 'bg-[#FAF5EE] hover:bg-[#F2ECE1] border-[#A8763E]/40 text-[#231812]'
                }`}
              >
                <Columns className="w-3.5 h-3.5 text-[#A8763E]" />
                <span>Both Sides (Split)</span>
              </button>

              <button
                onClick={() => setAdminDualViewMode('storefront')}
                className="w-full py-2 px-3 rounded-xl border border-[#E2D9C8] hover:border-[#A8763E] text-xs font-bold text-[#57473B] hover:text-[#231812] flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Store className="w-3.5 h-3.5 text-[#A8763E]" />
                <span>Open Store Front</span>
              </button>
            </div>

            {/* Sign Out Button */}
            <button
              onClick={() => {
                logout();
                setAdminDualViewMode('storefront');
              }}
              className="w-full py-2 rounded-xl text-xs font-medium text-rose-600 hover:bg-rose-50 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out Admin</span>
            </button>

          </div>
        </aside>

        {/* Right Content Area */}
        <main className="flex-1 min-w-0">
          {activeAdminTab === 'dashboard' && <AdminOverview />}
          {activeAdminTab === 'add-product' && <AdminAddProduct />}
          {activeAdminTab === 'products' && <AdminProductsList />}
          {activeAdminTab === 'orders' && <AdminOrdersEnquiries />}
          {activeAdminTab === 'custom-requests' && <AdminCustomRequests />}
          {activeAdminTab === 'gallery' && <AdminGalleryManager />}
          {activeAdminTab === 'activity-log' && <AdminActivityLog />}
          {activeAdminTab === 'settings' && <AdminSettings />}
        </main>

      </div>

    </div>
  );
};
