import React from 'react';
import { BUSINESS_CONFIG } from '../data/config';
import { Phone, MessageSquare, Mail, MapPin, Clock, Navigation, ArrowRight } from 'lucide-react';

interface ContactSectionProps {
  onStartProject: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onStartProject }) => {
  const handleWhatsAppClick = (num: string) => {
    const encoded = encodeURIComponent(BUSINESS_CONFIG.whatsappMessage);
    window.open(`https://wa.me/91${num}?text=${encoded}`, '_blank');
  };

  return (
    <section id="contact-section" className="py-20 bg-[#FAF7F2] text-[#231812] relative border-b border-[#E8E1D5]">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase tracking-[0.22em] text-[#A8763E] font-bold mb-3">
            Get in Touch
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-normal text-[#231812] mb-4">
            Visit & Contact CNCADOOR
          </h2>
          <div className="w-16 h-[2px] bg-[#A8763E] mx-auto mb-4" />
          <p className="text-[#57473B] text-sm sm:text-base font-light leading-relaxed">
            Reach out directly for custom door sizing, bespoke wood carving consultations, timber selection, or visit our workshop in Kerala.
          </p>
        </div>

        {/* Contact Info Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          
          {/* Card 1: Direct Phone Lines */}
          <div className="bg-white border border-[#E8E1D5] rounded-2xl p-8 flex flex-col justify-between hover:border-[#A8763E] transition-all shadow-sm">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] flex items-center justify-center text-[#A8763E] mb-6">
                <Phone className="w-6 h-6" />
              </div>
              <h3 className="font-serif-luxury text-xl font-medium text-[#231812] mb-2">
                Phone Contact
              </h3>
              <p className="text-xs text-[#57473B] font-light mb-6">
                Speak directly with our master craftsmen and consultation team.
              </p>

              <div className="space-y-3">
                {BUSINESS_CONFIG.phones.map((phone, idx) => (
                  <a
                    key={idx}
                    href={`tel:${phone}`}
                    className="flex items-center justify-between p-3 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] hover:border-[#A8763E] text-sm text-[#231812] group transition-colors"
                  >
                    <span className="font-mono font-medium">{phone}</span>
                    <span className="text-xs text-[#A8763E] font-bold group-hover:underline">Line {idx + 1} Call →</span>
                  </a>
                ))}
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-[#E8E1D5] text-[11px] text-[#7A6E63] flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-[#A8763E]" />
              <span>Available {BUSINESS_CONFIG.openingHours}</span>
            </div>
          </div>

          {/* Card 2: WhatsApp & Email */}
          <div className="bg-white border border-[#E8E1D5] rounded-2xl p-8 flex flex-col justify-between hover:border-[#A8763E] transition-all shadow-sm">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#E8F8EE] border border-[#25D366]/30 flex items-center justify-center text-[#16A34A] mb-6">
                <MessageSquare className="w-6 h-6 text-[#16A34A]" />
              </div>
              <h3 className="font-serif-luxury text-xl font-medium text-[#231812] mb-2">
                WhatsApp & Email
              </h3>
              <p className="text-xs text-[#57473B] font-light mb-6">
                Send photos, CAD drawings, or ask questions on WhatsApp.
              </p>

              <div className="space-y-3">
                {BUSINESS_CONFIG.whatsapps.map((wa, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleWhatsAppClick(wa)}
                    className="w-full flex items-center justify-between p-3 rounded-xl bg-[#E8F8EE] border border-[#25D366]/30 hover:border-[#16A34A] text-sm text-[#15803D] group text-left transition-colors"
                  >
                    <span className="font-mono font-semibold">{wa}</span>
                    <span className="text-xs text-[#15803D] font-bold group-hover:underline">Chat Line {idx + 1} →</span>
                  </button>
                ))}

                <a
                  href={`mailto:${BUSINESS_CONFIG.email}`}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] hover:border-[#A8763E] text-sm text-[#231812] group transition-colors"
                >
                  <span className="truncate text-xs sm:text-sm font-medium">{BUSINESS_CONFIG.email}</span>
                  <Mail className="w-4 h-4 text-[#A8763E] flex-shrink-0" />
                </a>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-[#E8E1D5] text-[11px] text-[#15803D] font-medium">
              <span>Instant response on WhatsApp</span>
            </div>
          </div>

          {/* Card 3: Address & Working Hours */}
          <div className="bg-white border border-[#E8E1D5] rounded-2xl p-8 flex flex-col justify-between hover:border-[#A8763E] transition-all shadow-sm">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] flex items-center justify-center text-[#A8763E] mb-6">
                <MapPin className="w-6 h-6" />
              </div>
              <h3 className="font-serif-luxury text-xl font-medium text-[#231812] mb-2">
                Location & Hours
              </h3>
              
              <div className="p-4 bg-[#FAF7F2] rounded-xl border border-[#E2D9C8] mb-4">
                <span className="text-[11px] uppercase tracking-wider text-[#A8763E] block mb-1 font-semibold">Workshop Address:</span>
                <p className="text-xs text-[#57473B] leading-relaxed">
                  {BUSINESS_CONFIG.address}
                </p>
              </div>

              <div className="p-4 bg-[#FAF7F2] rounded-xl border border-[#E2D9C8] mb-6">
                <span className="text-[11px] uppercase tracking-wider text-[#A8763E] block mb-1 font-semibold">Working Hours:</span>
                <p className="text-xs font-mono font-medium text-[#57473B]">
                  {BUSINESS_CONFIG.openingHours}
                </p>
              </div>
            </div>

            <a
              href={BUSINESS_CONFIG.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 rounded-lg bg-[#A8763E] hover:bg-[#91632F] text-white text-xs uppercase tracking-widest font-bold flex items-center justify-center gap-2 transition-all shadow-sm"
            >
              <Navigation className="w-4 h-4" />
              <span>Get Directions</span>
            </a>
          </div>

        </div>

        {/* Interactive Google Map & Direction Box */}
        <div className="bg-white border border-[#E8E1D5] rounded-2xl overflow-hidden shadow-sm mb-16">
          <div className="p-6 bg-[#FAF7F2] border-b border-[#E8E1D5] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-serif-luxury text-xl font-medium text-[#231812]">
                Find Us on Google Maps
              </h3>
              <p className="text-xs text-[#57473B] font-light mt-1">
                Adoor, Pathanamthitta-691523, Kerala, India
              </p>
            </div>
            <a
              href={BUSINESS_CONFIG.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold bg-[#A8763E] text-white hover:bg-[#91632F] flex items-center gap-2 shadow-sm transition-colors"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Open in Google Maps App</span>
            </a>
          </div>

          <div className="relative w-full h-80 bg-[#FAF7F2]">
            <iframe
              title="CNCADOOR Workshop Map Location"
              src="https://maps.google.com/maps?q=Adoor,Pathanamthitta,Kerala,India&t=&z=14&ie=UTF8&iwloc=&output=embed"
              className="w-full h-full border-0"
              loading="lazy"
            />
          </div>
        </div>

        {/* Large "START YOUR PROJECT" CTA */}
        <div className="bg-white rounded-2xl p-8 sm:p-14 text-center border border-[#E2D9C8] shadow-md relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto">
            <h3 className="font-serif-luxury text-3xl sm:text-4xl font-normal text-[#231812] mb-4">
              Ready to Craft Your Custom Door or Wood Carving?
            </h3>
            <p className="text-sm sm:text-base text-[#57473B] mb-8 font-light leading-relaxed">
              Contact our workshop today with your idea, architectural drawings, or dimension requirements.
            </p>
            <button
              id="start-project-large-cta"
              onClick={onStartProject}
              className="px-10 py-4 rounded-lg text-sm uppercase tracking-[0.22em] font-bold bg-[#A8763E] text-white hover:bg-[#91632F] transition-all shadow-md active:scale-95 inline-flex items-center gap-3"
            >
              <span>START YOUR PROJECT</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
