import React from 'react';
import { QuoteSection } from './QuoteSection';
import { X } from 'lucide-react';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDoorType?: string;
  initialDesignTitle?: string;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({
  isOpen,
  onClose,
  initialDoorType,
  initialDesignTitle
}) => {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div 
        className="relative max-w-3xl w-full my-8 bg-white border border-[#E8E1D5] rounded-2xl overflow-hidden shadow-2xl animate-fadeIn text-[#231812]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="bg-[#FAF7F2] border-b border-[#E8E1D5] px-6 py-4 flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase tracking-widest text-[#A8763E] font-semibold">
              CNCADOOR Wood Carving & Door Studio
            </div>
            <h2 className="font-serif-luxury text-xl font-normal text-[#231812]">
              Bespoke Quotation & Sizing Inquiry
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white hover:bg-[#FAF7F2] text-[#57473B] hover:text-[#231812] flex items-center justify-center transition-colors border border-[#E2D9C8] shadow-xs"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 max-h-[80vh] overflow-y-auto">
          <QuoteSection 
            initialDoorType={initialDoorType}
            initialDesignTitle={initialDesignTitle}
            onSuccessClose={onClose}
            isModal={true}
          />
        </div>
      </div>
    </div>
  );
};
