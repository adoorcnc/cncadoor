import React, { useState } from 'react';
import { 
  X, 
  Download, 
  FileText, 
  Printer, 
  CheckCircle2, 
  Layers, 
  Sparkles, 
  MapPin, 
  MessageSquare, 
  TreePine,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Package
} from 'lucide-react';
import { BUSINESS_CONFIG, DOORS_DATA, DOOR_CATEGORIES } from '../data/config';
import { INITIAL_PRODUCTS } from '../data/products';
import { generateCatalogPdf } from '../utils/generateCatalogPdf';

interface CatalogBrochureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenQuoteWithItem?: (doorName: string) => void;
}

export const CatalogBrochureModal: React.FC<CatalogBrochureModalProps> = ({
  isOpen,
  onClose,
  onOpenQuoteWithItem,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadPdf = async () => {
    try {
      setIsGenerating(true);
      await generateCatalogPdf({
        categoryFilter: selectedCategory,
      });
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (error) {
      console.error('Failed to generate catalog PDF', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const filteredDoors = selectedCategory === 'All'
    ? DOORS_DATA
    : DOORS_DATA.filter((door) => door.category === selectedCategory);

  const handleWhatsAppInquiry = (doorName?: string) => {
    const text = doorName
      ? `Hello CNCADOOR, I downloaded your Door Collections Catalog and would like to inquire about "${doorName}". I understand finished doors are for customer pickup at your Adoor workshop.`
      : `Hello CNCADOOR, I downloaded your Door Collections Catalog and would like to get a sizing and price estimate for a custom entrance door.`;
    
    const phone = BUSINESS_CONFIG.whatsapps[0] || '8301851820';
    window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div 
        className="relative bg-white rounded-2xl w-full max-w-5xl shadow-2xl overflow-hidden border border-[#E2D9C8] my-8 flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="bg-[#FAF7F2] border-b border-[#E2D9C8] px-5 sm:px-8 py-4 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#A8763E] text-white flex items-center justify-center shadow-xs">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif-luxury text-lg sm:text-xl font-bold text-[#231812]">
                  Door Collections Catalog & Brochure
                </h3>
                <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#FAF5EE] text-[#A8763E] border border-[#A8763E]/30">
                  PDF Specification
                </span>
              </div>
              <p className="text-xs text-[#7A6E63]">
                Solid teak entrance doors, pooja mandapams & precision architectural carvings
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadPdf}
              disabled={isGenerating}
              id="modal-pdf-download-btn"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#A8763E] hover:bg-[#91632F] text-white text-xs font-bold uppercase tracking-wider transition-all shadow-sm active:scale-95 disabled:opacity-75 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isGenerating ? 'Generating PDF...' : 'Download PDF'}</span>
            </button>

            <button
              onClick={handlePrint}
              title="Print Brochure"
              className="hidden sm:flex p-2 rounded-lg text-[#57473B] hover:text-[#231812] hover:bg-white border border-[#E2D9C8] transition-colors"
            >
              <Printer className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              id="modal-close-catalog-btn"
              className="p-2 rounded-lg text-[#57473B] hover:text-[#231812] hover:bg-white border border-[#E2D9C8] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Download Success Notice */}
        {downloadSuccess && (
          <div className="bg-[#E8F8EE] border-b border-[#C3E6D0] px-6 py-2.5 flex items-center justify-between text-xs text-[#166534] animate-fadeIn flex-shrink-0">
            <div className="flex items-center gap-2 font-medium">
              <CheckCircle2 className="w-4 h-4 text-[#16A34A]" />
              <span>PDF Catalog downloaded successfully! File saved to your downloads folder.</span>
            </div>
            <button 
              onClick={() => handleWhatsAppInquiry()}
              className="font-bold underline text-[#15803D] hover:text-[#166534] ml-4 flex items-center gap-1"
            >
              <span>Have a question? Inquire on WhatsApp</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Scrollable Body Content */}
        <div className="overflow-y-auto p-5 sm:p-8 space-y-6 flex-1 text-[#231812]">
          
          {/* Workshop Pickup Notice Banner */}
          <div className="bg-[#FFF9F2] border border-[#F3DFC1] rounded-xl p-4 flex items-start gap-3 shadow-xs">
            <div className="w-8 h-8 rounded-lg bg-[#A8763E] text-white flex items-center justify-center flex-shrink-0 mt-0.5">
              <MapPin className="w-4 h-4" />
            </div>
            <div className="text-xs">
              <span className="font-bold text-[#A8763E] uppercase tracking-wider block mb-0.5">
                Workshop Policy: Direct Customer Collection (No Delivery Service)
              </span>
              <p className="text-[#57473B] leading-relaxed">
                All finished doors, carved mandapams, and architectural wall panels are manufactured for <strong>direct customer pickup at our Adoor workshop (Pathanamthitta, Kerala)</strong>. Our workshop team assists with heavy loading and multi-layer protective packaging.
              </p>
            </div>
          </div>

          {/* Catalog Quick Highlights Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-[#FAF7F2] p-3 rounded-xl border border-[#E8E1D5]">
              <div className="text-[#A8763E] font-bold text-sm">9+ Core Designs</div>
              <div className="text-[#7A6E63]">Entrance & Temple Styles</div>
            </div>
            <div className="bg-[#FAF7F2] p-3 rounded-xl border border-[#E8E1D5]">
              <div className="text-[#A8763E] font-bold text-sm">Grade-A Teak Timber</div>
              <div className="text-[#7A6E63]">100% Kiln-Seasoned</div>
            </div>
            <div className="bg-[#FAF7F2] p-3 rounded-xl border border-[#E8E1D5]">
              <div className="text-[#A8763E] font-bold text-sm">25-40mm 3D Relief</div>
              <div className="text-[#7A6E63]">CNC + Hand Sculpting</div>
            </div>
            <div className="bg-[#FAF7F2] p-3 rounded-xl border border-[#E8E1D5]">
              <div className="text-[#A8763E] font-bold text-sm">Direct Workshop Rate</div>
              <div className="text-[#7A6E63]">Custom Sizing Available</div>
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-[#E8E1D5]">
            <div className="flex items-center gap-1.5 text-xs text-[#57473B]">
              <Layers className="w-4 h-4 text-[#A8763E]" />
              <span className="font-semibold">Filter Collection:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {DOOR_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-full text-xs transition-colors font-medium ${
                    selectedCategory === cat
                      ? 'bg-[#A8763E] text-white shadow-xs'
                      : 'bg-[#FAF7F2] text-[#57473B] hover:bg-[#F0EBE1] border border-[#E2D9C8]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Door Items Grid */}
          <div className="space-y-4">
            <h4 className="font-serif-luxury text-base font-bold text-[#231812] flex items-center gap-2">
              <span>Collection Door Models</span>
              <span className="text-xs font-sans font-normal text-[#7A6E63]">
                ({filteredDoors.length} model{filteredDoors.length === 1 ? '' : 's'})
              </span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredDoors.map((door, index) => (
                <div 
                  key={door.id}
                  className="bg-[#FAF7F2] border border-[#E2D9C8] rounded-xl p-4 flex flex-col sm:flex-row gap-4 hover:border-[#A8763E] transition-colors group"
                >
                  <img
                    src={door.imageUrl}
                    alt={door.name}
                    className="w-full sm:w-28 h-36 object-cover rounded-lg border border-[#E8E1D5] flex-shrink-0"
                    loading="lazy"
                  />
                  <div className="flex-1 flex flex-col justify-between text-xs">
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#A8763E] bg-white px-2 py-0.5 rounded border border-[#E8E1D5]">
                          {door.category}
                        </span>
                        <span className="text-[10px] font-mono text-[#7A6E63]">#{index + 1}</span>
                      </div>
                      <h5 className="font-serif-luxury text-sm font-bold text-[#231812] group-hover:text-[#A8763E] transition-colors mb-1.5">
                        {door.name}
                      </h5>
                      <p className="text-[#57473B] text-[11px] line-clamp-2 mb-2 font-light leading-relaxed">
                        {door.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#E8E1D5] space-y-1 text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-[#7A6E63]">Timber:</span>
                        <span className="font-semibold text-[#231812] truncate max-w-[170px]">{door.woodType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#7A6E63]">Carving:</span>
                        <span className="font-semibold text-[#231812] truncate max-w-[170px]">{door.carvingStyle}</span>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <button
                          onClick={() => {
                            if (onOpenQuoteWithItem) onOpenQuoteWithItem(door.name);
                            onClose();
                          }}
                          className="text-[#A8763E] hover:underline font-bold text-[11px] flex items-center gap-1"
                        >
                          <span>Get Sizing Quote</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleWhatsAppInquiry(door.name)}
                          className="text-[#16A34A] hover:underline font-semibold text-[11px] flex items-center gap-1"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>WhatsApp</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* In-Stock Ready-Made Inventory Highlights */}
          <div className="pt-4 border-t border-[#E8E1D5] space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-serif-luxury text-base font-bold text-[#231812] flex items-center gap-2">
                <Package className="w-4 h-4 text-[#A8763E]" />
                <span>In-Stock Ready-Made Inventory (Immediate Workshop Pickup)</span>
              </h4>
              <span className="text-xs text-[#16A34A] font-semibold bg-[#E8F8EE] px-2.5 py-0.5 rounded-full">
                Zero Lead Time
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              {INITIAL_PRODUCTS.slice(0, 3).map((prod) => (
                <div key={prod.id} className="bg-white border border-[#E2D9C8] rounded-xl p-3.5 space-y-2 shadow-xs">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-[#231812] text-xs line-clamp-1">{prod.name}</span>
                    <span className="font-bold text-[#A8763E] text-xs whitespace-nowrap ml-2">{prod.price}</span>
                  </div>
                  <p className="text-[11px] text-[#7A6E63] line-clamp-2">{prod.description}</p>
                  <div className="text-[10px] text-[#57473B] pt-1 border-t border-[#E8E1D5] flex items-center justify-between">
                    <span>{prod.dimensionsNote}</span>
                    <span className="text-[#16A34A] font-semibold">{prod.inStockCount} in stock</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Technical Specifications Summary Box */}
          <div className="bg-[#FAF5EE] border border-[#E2D9C8] rounded-xl p-5 space-y-3 text-xs">
            <div className="flex items-center gap-2 text-[#A8763E] font-bold uppercase tracking-wider text-xs">
              <TreePine className="w-4 h-4" />
              <span>Timber & Carving Technical Specifications</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-[#57473B]">
              <div>
                <span className="font-bold text-[#231812] block mb-1">Grade-A Kerala Teak</span>
                <p className="text-[11px] leading-relaxed font-light">
                  Seasoned in-house to 10-12% moisture content to completely eliminate warping and seasonal wood joint movement.
                </p>
              </div>
              <div>
                <span className="font-bold text-[#231812] block mb-1">Precision 3D CNC Routing</span>
                <p className="text-[11px] leading-relaxed font-light">
                  Machined with multi-axis industrial CNC routers up to 40mm relief depth, followed by hand-feathered detailing.
                </p>
              </div>
              <div>
                <span className="font-bold text-[#231812] block mb-1">Workshop Pickup Policy</span>
                <p className="text-[11px] leading-relaxed font-light">
                  Direct customer collection at Adoor workshop. Heavy vehicle loading assistance and protective foam wrap included.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Sticky Footer CTA */}
        <div className="bg-[#FAF7F2] border-t border-[#E2D9C8] px-5 sm:px-8 py-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 flex-shrink-0">
          <div className="text-xs text-[#57473B] flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#A8763E]" />
            <span>Printed and digital catalogs are freely distributable for architectural and homeowner planning.</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => handleWhatsAppInquiry()}
              className="flex-1 sm:flex-none px-4 py-2 rounded-lg bg-[#25D366] hover:bg-[#1ebd5a] text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WhatsApp Inquiry</span>
            </button>

            <button
              onClick={handleDownloadPdf}
              disabled={isGenerating}
              className="flex-1 sm:flex-none px-5 py-2 rounded-lg bg-[#A8763E] hover:bg-[#91632F] text-white text-xs font-bold uppercase tracking-wider transition-all shadow-sm flex items-center justify-center gap-2 disabled:opacity-75"
            >
              <Download className="w-4 h-4" />
              <span>{isGenerating ? 'Downloading PDF...' : 'Download PDF Catalog'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
