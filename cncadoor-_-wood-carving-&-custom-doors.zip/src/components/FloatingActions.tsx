import React, { useState } from 'react';
import { BUSINESS_CONFIG } from '../data/config';
import { MessageSquare, Phone, X } from 'lucide-react';

export const FloatingActions: React.FC = () => {
  const [showCallSelector, setShowCallSelector] = useState(false);

  const handleWhatsAppClick = () => {
    const encoded = encodeURIComponent(BUSINESS_CONFIG.whatsappMessage);
    const targetPhone = BUSINESS_CONFIG.whatsapps[0];
    window.open(`https://wa.me/91${targetPhone}?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3">
      
      {/* Call Lines Popover if multiple numbers */}
      {showCallSelector && (
        <div className="bg-white border border-[#E2D9C8] rounded-xl p-3 shadow-xl animate-fadeIn w-56 text-left mb-1">
          <div className="flex items-center justify-between pb-2 border-b border-[#E2D9C8] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#A8763E]">
              Direct Dial
            </span>
            <button 
              onClick={() => setShowCallSelector(false)}
              className="text-[#8A7A6E] hover:text-[#231812]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-1.5">
            {BUSINESS_CONFIG.phones.map((phone, idx) => (
              <a
                key={idx}
                href={`tel:${phone}`}
                onClick={() => setShowCallSelector(false)}
                className="flex items-center justify-between p-2 rounded-lg bg-[#FAF7F2] hover:bg-[#F4EFE6] text-xs text-[#231812] font-mono border border-[#E2D9C8] transition-colors"
              >
                <span className="font-semibold">{phone}</span>
                <span className="text-[10px] text-[#A8763E] font-medium">Line {idx + 1}</span>
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Floating Buttons Group */}
      <div className="flex items-center gap-3">
        
        {/* Floating Call Button */}
        <button
          id="floating-call-btn"
          onClick={() => {
            if (BUSINESS_CONFIG.phones.length === 1) {
              window.open(`tel:${BUSINESS_CONFIG.phones[0]}`);
            } else {
              setShowCallSelector(!showCallSelector);
            }
          }}
          className="h-12 px-4 rounded-full bg-[#2B1810] hover:bg-[#A8763E] text-[#FAF7F2] border border-[#2B1810] shadow-lg flex items-center gap-2.5 transition-all hover:scale-105 active:scale-95 group"
          title="Call CNCADOOR"
        >
          <div className="w-6 h-6 rounded-full bg-[#A8763E] group-hover:bg-[#FAF7F2] text-[#FAF7F2] group-hover:text-[#2B1810] flex items-center justify-center transition-colors">
            <Phone className="w-3.5 h-3.5 fill-current" />
          </div>
          <span className="text-xs uppercase tracking-widest font-bold hidden sm:inline">
            CALL NOW
          </span>
        </button>

        {/* Floating WhatsApp Button */}
        <button
          id="floating-whatsapp-btn"
          onClick={handleWhatsAppClick}
          className="h-12 w-12 sm:w-auto sm:px-5 rounded-full bg-[#25D366] hover:bg-[#1EBE5D] text-white shadow-lg flex items-center justify-center gap-2 transition-all hover:scale-108 active:scale-95 group"
          title="Chat on WhatsApp"
          aria-label="Chat on WhatsApp"
        >
          <MessageSquare className="w-5 h-5 fill-current" />
          <span className="text-xs font-bold tracking-wider hidden sm:inline">
            WhatsApp
          </span>
        </button>

      </div>
    </div>
  );
};

