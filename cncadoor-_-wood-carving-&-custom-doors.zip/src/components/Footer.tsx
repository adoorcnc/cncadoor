import React from 'react';
import { BUSINESS_CONFIG } from '../data/config';
import { Phone, Mail, MapPin, Download, FileText, Columns, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useStore } from '../context/StoreContext';
import { generateCatalogPdf } from '../utils/generateCatalogPdf';

interface FooterProps {
  setActiveTab: (tab: string) => void;
  onSelectCategory?: (category: string) => void;
  onOpenQuote: () => void;
  onOpenAdmin?: () => void;
  onOpenCatalog?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab, onSelectCategory, onOpenAdmin, onOpenCatalog }) => {
  const { isAdmin, openAuthModal } = useAuth();
  const { setAdminDualViewMode } = useStore();
  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'doors', label: 'Doors' },
    { id: 'carving', label: 'Wood Carving' },
    { id: 'custom-designs', label: 'Custom Designs' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact' },
  ];

  const serviceLinks = [
    { label: 'Main Entrance Doors', type: 'doors', cat: 'Main Entrance Doors' },
    { label: 'Traditional Kerala Doors', type: 'doors', cat: 'Traditional Doors' },
    { label: 'Artistic Carved Doors', type: 'doors', cat: 'Carved Doors' },
    { label: 'Temple & Pooja Doors', type: 'doors', cat: 'Temple-Inspired Designs' },
    { label: 'Custom Wood Carvings', type: 'carving', cat: 'Custom Designs' },
  ];

  const handleServiceClick = (item: { type: string; cat: string }) => {
    setActiveTab(item.type);
    if (onSelectCategory) {
      onSelectCategory(item.cat);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#FAF7F2] text-[#231812] border-t border-[#E8E1D5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8">
          
          {/* Column 1: Brand & Logo (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <div 
              onClick={() => handleNavClick('home')}
              className="cursor-pointer flex items-center space-x-3 group"
            >
              <div className="w-9 h-9 border-2 border-[#A8763E] rounded-sm flex items-center justify-center p-1 relative shadow-sm bg-white">
                <div className="w-4 h-6 border border-[#A8763E] rounded-t-xs flex items-center justify-end pr-0.5">
                  <div className="w-1 h-1 rounded-full bg-[#A8763E]" />
                </div>
              </div>
              <div>
                <div className="font-serif-luxury text-xl font-bold tracking-[0.12em] text-[#A8763E] leading-none">
                  {BUSINESS_CONFIG.name}
                </div>
                <div className="text-[9px] tracking-[0.22em] uppercase text-[#7A6E63] font-medium mt-1">
                  {BUSINESS_CONFIG.subtitle}
                </div>
              </div>
            </div>

            <p className="text-xs text-[#57473B] leading-relaxed font-light max-w-sm pt-2">
              Specialized in handcrafted solid wooden doors, intricate CNC wood carvings, temple pooja doors, and precision architectural woodcraft for fine residential spaces.
            </p>

            {/* Social Icons */}
            <div className="flex items-center space-x-3 pt-3">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full border border-[#D5CBC0] bg-white hover:border-[#A8763E] hover:text-[#A8763E] text-[#57473B] flex items-center justify-center text-xs transition-colors shadow-xs"
                aria-label="Facebook"
              >
                f
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full border border-[#D5CBC0] bg-white hover:border-[#A8763E] hover:text-[#A8763E] text-[#57473B] flex items-center justify-center text-xs transition-colors shadow-xs"
                aria-label="Instagram"
              >
                ig
              </a>
              <a
                href={`https://wa.me/91${BUSINESS_CONFIG.whatsapps[0]}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full border border-[#D5CBC0] bg-white hover:border-[#25D366] hover:text-[#16A34A] text-[#57473B] flex items-center justify-center text-xs transition-colors shadow-xs"
                aria-label="WhatsApp"
              >
                wa
              </a>
            </div>
            {/* Download PDF Catalog Brochure CTA */}
            <div className="pt-2">
              <button
                id="footer-download-catalog-btn"
                onClick={() => {
                  if (onOpenCatalog) onOpenCatalog();
                  else generateCatalogPdf();
                }}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-white hover:bg-[#FAF5EE] border border-[#E2D9C8] hover:border-[#A8763E] text-[#231812] text-xs font-semibold transition-all shadow-xs group cursor-pointer"
                title="Download Summarized PDF Catalog of Current Door Collections"
              >
                <FileText className="w-4 h-4 text-[#A8763E] group-hover:scale-110 transition-transform" />
                <span>Download PDF Catalog</span>
                <Download className="w-3.5 h-3.5 text-[#A8763E]" />
              </button>
            </div>
          </div>

          {/* Column 2: Quick Links (2 cols) */}
          <div className="lg:col-span-2">
            <h4 className="font-serif-luxury text-xs font-bold uppercase tracking-[0.16em] text-[#A8763E] mb-5">
              QUICK LINKS
            </h4>
            <ul className="space-y-2.5 text-xs text-[#57473B]">
              {navLinks.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => handleNavClick(link.id)}
                    className="hover:text-[#A8763E] transition-colors font-light cursor-pointer"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
              <li>
                <button
                  id="footer-quicklink-catalog-btn"
                  onClick={() => {
                    if (onOpenCatalog) onOpenCatalog();
                    else generateCatalogPdf();
                  }}
                  className="hover:text-[#8D5F2D] transition-colors font-medium text-[#A8763E] flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-[#A8763E]" />
                  <span>PDF Catalog</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Services (3 cols) */}
          <div className="lg:col-span-3">
            <h4 className="font-serif-luxury text-xs font-bold uppercase tracking-[0.16em] text-[#A8763E] mb-5">
              OUR SERVICES
            </h4>
            <ul className="space-y-2.5 text-xs text-[#57473B]">
              {serviceLinks.map((item, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => handleServiceClick(item)}
                    className="hover:text-[#A8763E] transition-colors text-left font-light"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Contact Us (3 cols) */}
          <div className="lg:col-span-3">
            <h4 className="font-serif-luxury text-xs font-bold uppercase tracking-[0.16em] text-[#A8763E] mb-5">
              CONTACT US
            </h4>
            <div className="space-y-3 text-xs text-[#57473B] font-light">
              <div className="flex items-center gap-2.5">
                <Phone className="w-3.5 h-3.5 text-[#A8763E] flex-shrink-0" />
                <a href={`tel:${BUSINESS_CONFIG.phones[0]}`} className="hover:text-[#A8763E]">
                  +91 {BUSINESS_CONFIG.phones[0]}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-3.5 h-3.5 text-[#A8763E] flex-shrink-0" />
                <a href={`mailto:${BUSINESS_CONFIG.email}`} className="hover:text-[#A8763E]">
                  {BUSINESS_CONFIG.email}
                </a>
              </div>

              <div className="flex items-start gap-2.5">
                <MapPin className="w-3.5 h-3.5 text-[#A8763E] flex-shrink-0 mt-0.5" />
                <span>{BUSINESS_CONFIG.address}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-14 pt-6 border-t border-[#E8E1D5] text-xs text-[#7A6E63] font-light flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 justify-center md:justify-start">
            {/* Created by primeNEST Watermark badge */}
            <div 
              id="footer-watermark-primenest"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1F1610]/95 hover:bg-[#1F1610] text-[#E8E1D5] border border-[#D4AF37]/40 shadow-sm text-[11px] font-medium tracking-wide transition-all duration-300 hover:scale-105 active:scale-95 group select-none cursor-default"
              title="Website designed & developed by primeNEST"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />
              <span className="text-[#A8988B] text-[10px] uppercase tracking-wider font-light">
                Created by
              </span>
              <span className="font-serif-luxury font-bold tracking-wider text-xs text-[#FAF7F2] group-hover:text-[#D4AF37] transition-colors">
                prime<span className="text-[#D4AF37]">NEST</span>
              </span>
            </div>

            <span>&copy; {new Date().getFullYear()} CNCADOOR. All Rights Reserved.</span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-[#7A6E63]">
            <span>Crafted with Precision & Passion</span>
            <span>•</span>
            {isAdmin ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setAdminDualViewMode('split')}
                  className="text-[#D4AF37] hover:text-[#B38F17] font-bold transition-colors cursor-pointer flex items-center gap-1 bg-[#231812] px-2 py-0.5 rounded text-[10px]"
                  title="View Store Front and Admin Panel simultaneously"
                >
                  <Columns className="w-3 h-3 text-[#D4AF37]" />
                  <span>Both Sides (Split)</span>
                </button>
                <span>•</span>
                <button
                  onClick={() => setAdminDualViewMode('admin')}
                  className="text-[#A8763E] hover:text-[#8D5F2D] font-medium transition-colors cursor-pointer"
                >
                  Admin Panel
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  openAuthModal('Sign in to access workshop administration.');
                }}
                className="text-[#A8763E] hover:text-[#8D5F2D] font-medium transition-colors cursor-pointer"
              >
                Workshop Portal
              </button>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};
