import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  X, 
  Trash2, 
  FileText, 
  Send, 
  LogOut, 
  Heart, 
  Clock, 
  User
} from 'lucide-react';
import { BUSINESS_CONFIG } from '../data/config';

interface ShortlistDrawerProps {
  onOpenQuoteWithItem: (itemTitle: string) => void;
}

export const ShortlistDrawer: React.FC<ShortlistDrawerProps> = ({ onOpenQuoteWithItem }) => {
  const { 
    user, 
    isShortlistDrawerOpen, 
    closeShortlistDrawer, 
    toggleSaveItem, 
    logout,
    openAuthModal
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'saved' | 'quotes' | 'profile'>('saved');

  if (!isShortlistDrawerOpen) return null;

  const savedItems = user?.savedItems || [];
  const quotes = user?.quotes || [];

  const handleWhatsAppCombinedShortlist = () => {
    if (savedItems.length === 0) return;
    const itemList = savedItems.map((item, idx) => `${idx + 1}. ${item.title} (${item.category})`).join('%0A');
    const text = `Hello CNCADOOR, I have shortlisted the following ${savedItems.length} design(s) on your website:%0A${itemList}%0APlease provide timber estimates and carving options.`;
    window.open(`https://wa.me/91${BUSINESS_CONFIG.whatsapps[0]}?text=${text}`, '_blank');
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end animate-fadeIn"
      onClick={closeShortlistDrawer}
    >
      <div 
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col text-[#231812] border-l border-[#E8E1D5] animate-slideLeft"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="bg-[#FAF7F2] p-5 border-b border-[#E8E1D5] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white text-[#A8763E] border border-[#E2D9C8] flex items-center justify-center font-serif-luxury font-bold text-base shadow-xs">
              {user ? user.name.charAt(0).toUpperCase() : <Heart className="w-5 h-5 text-[#A8763E]" />}
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-[#A8763E] font-semibold">
                {user ? user.role || 'Client' : 'Guest Shortlist'}
              </div>
              <h3 className="font-serif-luxury text-base font-normal text-[#231812]">
                {user ? user.name : 'Saved Designs & Carvings'}
              </h3>
            </div>
          </div>

          <button
            onClick={closeShortlistDrawer}
            className="w-8 h-8 rounded-full bg-white hover:bg-[#FAF7F2] text-[#57473B] hover:text-[#231812] flex items-center justify-center transition-colors border border-[#E2D9C8] shadow-xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#E8E1D5] bg-[#FAF7F2] text-xs font-semibold">
          <button
            onClick={() => setActiveTab('saved')}
            className={`flex-1 py-3 px-4 flex items-center justify-center gap-1.5 transition-all border-b-2 ${
              activeTab === 'saved'
                ? 'border-[#A8763E] text-[#A8763E] bg-white font-bold'
                : 'border-transparent text-[#7A6E63] hover:text-[#231812]'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            <span>Shortlist ({savedItems.length})</span>
          </button>

          {user && (
            <button
              onClick={() => setActiveTab('quotes')}
              className={`flex-1 py-3 px-4 flex items-center justify-center gap-1.5 transition-all border-b-2 ${
                activeTab === 'quotes'
                  ? 'border-[#A8763E] text-[#A8763E] bg-white font-bold'
                  : 'border-transparent text-[#7A6E63] hover:text-[#231812]'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Quotes ({quotes.length})</span>
            </button>
          )}

          {user && (
            <button
              onClick={() => setActiveTab('profile')}
              className={`flex-1 py-3 px-4 flex items-center justify-center gap-1.5 transition-all border-b-2 ${
                activeTab === 'profile'
                  ? 'border-[#A8763E] text-[#A8763E] bg-white font-bold'
                  : 'border-transparent text-[#7A6E63] hover:text-[#231812]'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Account</span>
            </button>
          )}
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          
          {/* TAB 1: SAVED SHORTLIST */}
          {activeTab === 'saved' && (
            <div>
              {!user && (
                <div className="mb-4 p-3.5 rounded-xl bg-[#FAF7F2] border border-[#E2D9C8] text-xs text-[#57473B] flex items-center justify-between shadow-xs">
                  <div>
                    <span className="font-semibold text-[#231812] block">Guest Session</span>
                    <span>Sign in to keep items synced permanently.</span>
                  </div>
                  <button
                    onClick={() => openAuthModal('Sign in to sync your shortlisted doors and receive direct workshop quotes.')}
                    className="px-3 py-1.5 rounded-lg bg-[#A8763E] text-white text-[11px] font-bold hover:bg-[#91632F] transition-colors shadow-xs"
                  >
                    Sign In
                  </button>
                </div>
              )}

              {savedItems.length === 0 ? (
                <div className="text-center py-12 px-4">
                  <div className="w-12 h-12 rounded-full bg-[#FAF7F2] border border-[#E2D9C8] flex items-center justify-center mx-auto mb-3 text-[#A8763E]">
                    <Heart className="w-6 h-6" />
                  </div>
                  <h4 className="font-serif-luxury font-normal text-base text-[#231812] mb-1">
                    Your Shortlist is Empty
                  </h4>
                  <p className="text-xs text-[#7A6E63] font-light leading-relaxed max-w-xs mx-auto">
                    Browse our door collections, temple carvings, or gallery and click the heart icon to save designs.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {savedItems.map((item) => (
                    <div 
                      key={item.id}
                      className="p-3 bg-[#FAF7F2] border border-[#E2D9C8] rounded-xl flex gap-3 items-center group hover:border-[#A8763E] transition-all shadow-xs"
                    >
                      <img 
                        src={item.imageUrl} 
                        alt={item.title} 
                        className="w-16 h-16 rounded-lg object-cover border border-[#E2D9C8] flex-shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 min-w-0">
                        <span className="text-[10px] uppercase font-semibold text-[#A8763E] block truncate">
                          {item.category}
                        </span>
                        <h5 className="font-serif-luxury text-sm font-medium text-[#231812] truncate">
                          {item.title}
                        </h5>
                        <div className="mt-1.5 flex items-center gap-2">
                          <button
                            onClick={() => {
                              closeShortlistDrawer();
                              onOpenQuoteWithItem(item.title);
                            }}
                            className="text-[11px] font-semibold text-[#A8763E] hover:underline"
                          >
                            Get Quote →
                          </button>
                        </div>
                      </div>

                      <button
                        onClick={() => toggleSaveItem(item)}
                        className="p-2 text-[#8A7A6E] hover:text-red-500 transition-colors"
                        title="Remove from shortlist"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}

                  <div className="pt-3 space-y-2">
                    <button
                      onClick={handleWhatsAppCombinedShortlist}
                      className="w-full py-3 rounded-xl text-xs uppercase tracking-widest font-bold bg-[#16A34A] hover:bg-[#15803D] text-white shadow-sm flex items-center justify-center gap-2 transition-all"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Send Shortlist to WhatsApp</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: QUOTE HISTORY */}
          {activeTab === 'quotes' && user && (
            <div className="space-y-3">
              {quotes.length === 0 ? (
                <div className="text-center py-12 px-4">
                  <div className="w-12 h-12 rounded-full bg-[#FAF7F2] border border-[#E2D9C8] flex items-center justify-center mx-auto mb-3 text-[#A8763E]">
                    <FileText className="w-6 h-6" />
                  </div>
                  <h4 className="font-serif-luxury font-normal text-base text-[#231812] mb-1">
                    No Quote Inquiries Yet
                  </h4>
                  <p className="text-xs text-[#7A6E63] font-light">
                    Any quote requests you submit on CNCADOOR will be listed here with status updates.
                  </p>
                </div>
              ) : (
                quotes.map((q) => (
                  <div key={q.id} className="p-4 bg-[#FAF7F2] border border-[#E2D9C8] rounded-xl space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono font-bold text-[#A8763E]">{q.id}</span>
                      <span className="text-[#7A6E63]">{q.date}</span>
                    </div>
                    <div className="font-serif-luxury font-medium text-sm text-[#231812]">
                      {q.doorType}
                    </div>
                    {q.woodPreference && (
                      <div className="text-xs text-[#57473B]">
                        Wood: <strong className="text-[#231812]">{q.woodPreference}</strong>
                      </div>
                    )}
                    <div className="pt-2 border-t border-[#E8E1D5] flex items-center justify-between text-xs">
                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#16A34A]">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{q.status}</span>
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 3: PROFILE */}
          {activeTab === 'profile' && user && (
            <div className="space-y-4">
              <div className="p-4 bg-[#FAF7F2] border border-[#E2D9C8] rounded-xl space-y-3">
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-[#A8763E] font-semibold block">Full Name</label>
                  <div className="text-sm font-medium text-[#231812]">{user.name}</div>
                </div>
                {user.email && (
                  <div>
                    <label className="text-[10px] uppercase tracking-wider text-[#A8763E] font-semibold block">Email</label>
                    <div className="text-xs font-medium text-[#57473B]">{user.email}</div>
                  </div>
                )}
                {user.phone && (
                  <div>
                    <label className="text-[10px] uppercase tracking-wider text-[#A8763E] font-semibold block">Phone / WhatsApp</label>
                    <div className="text-xs font-mono text-[#57473B]">{user.phone}</div>
                  </div>
                )}
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-[#A8763E] font-semibold block">Profile Type</label>
                  <div className="text-xs text-[#57473B]">{user.role || 'Homeowner / Architect'}</div>
                </div>
              </div>

              <button
                onClick={() => {
                  logout();
                  closeShortlistDrawer();
                }}
                className="w-full py-2.5 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-[#FAF7F2] border-t border-[#E8E1D5] text-center text-xs text-[#7A6E63]">
          CNCADOOR Wood Carving & Door Studio • Kerala, India
        </div>
      </div>
    </div>
  );
};
