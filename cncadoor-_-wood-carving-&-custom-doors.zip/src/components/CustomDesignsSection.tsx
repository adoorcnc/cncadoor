import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { useAuth } from '../context/AuthContext';
import { ProductItem } from '../types';
import { 
  Sparkles, 
  UploadCloud, 
  Ruler, 
  TreePine, 
  Layers, 
  ArrowRight, 
  CheckCircle2, 
  Heart, 
  Image as ImageIcon,
  Compass,
  FileCheck,
  Hammer
} from 'lucide-react';

interface CustomDesignsSectionProps {
  onRequestCustomQuote: (designTitle?: string) => void;
}

export const CustomDesignsSection: React.FC<CustomDesignsSectionProps> = ({
  onRequestCustomQuote
}) => {
  const { customizedProducts } = useStore();
  const { toggleSaveItem, isItemSaved } = useAuth();
  const [selectedWoodTab, setSelectedWoodTab] = useState<'teak' | 'anjili' | 'rosewood' | 'mahogany'>('teak');

  const woodInfo = {
    teak: {
      name: 'Kiln-Seasoned Teak Wood',
      description: 'The golden sovereign of architectural joinery. Unrivaled dimensional stability, natural teak oil weather resistance, and magnificent grain depth.',
      durability: 'Generational (50+ years)',
      bestFor: 'Grand Main Entrance Double Doors, Coastal Villas, Heritage Facades'
    },
    anjili: {
      name: 'Kerala Wild Anjili Wood (Artocarpus)',
      description: 'Cherished in traditional Kerala temple and Illam architecture for its resilience against moisture, termite resistance, and warm amber patina.',
      durability: 'Very High (40+ years)',
      bestFor: 'Pooja Sanctum Doors, Traditional Kerala Nalukettu Homes, Carved Architraves'
    },
    rosewood: {
      name: 'Selected Indian Rosewood (Eetti)',
      description: 'Deep, dramatic dark chocolate tones with high density and lustrous finishing properties. The ultimate luxury wood for statement doors.',
      durability: 'Extreme Density',
      bestFor: 'High-Relief Medallions, Temple Sanctuaries, Luxury Bedroom Doors'
    },
    mahogany: {
      name: 'Selected Hardwood & Mahogany',
      description: 'Uniform grain, warm reddish-brown undertone, and excellent carving receptivity for contemporary fluted and organic nature reliefs.',
      durability: 'High Stability',
      bestFor: 'Interior Double Leaf Doors, Modern Fluted Panels, Office Partitions'
    }
  };

  const customPillars = [
    {
      icon: <ImageIcon className="w-6 h-6 text-[#A8763E]" />,
      title: 'Any Reference Photo or Sketch',
      desc: 'Bring a Pinterest photo, an architectural blueprint, a CAD drawing, or a sketch of a temple deity. We create a 3D digital simulation before carving.'
    },
    {
      icon: <Ruler className="w-6 h-6 text-[#A8763E]" />,
      title: 'Custom Millimeter Sizing',
      desc: 'No standard restrictions. Whether you need a 9-foot grand pivot doorway, arched transoms, or custom thickness frames, we tailor every dimension.'
    },
    {
      icon: <Hammer className="w-6 h-6 text-[#A8763E]" />,
      title: 'CNC Precision + Hand Detailing',
      desc: 'Our high-torque multi-axis CNC machines carve intricate 3D toolpaths, followed by hours of master artisan hand chisel-feathering and polish.'
    },
    {
      icon: <TreePine className="w-6 h-6 text-[#A8763E]" />,
      title: 'Seasoned Timber Guarantee',
      desc: 'Every custom shutter is fabricated from moisture-meter tested, kiln-seasoned hardwoods to guarantee zero warping or seasonal contraction.'
    }
  ];

  return (
    <section id="custom-designs-section" className="py-20 bg-white relative border-t border-[#E2D9C8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EADCC9]/50 border border-[#A8763E]/30 text-[#A8763E] text-xs uppercase tracking-widest font-bold mb-4">
            <Sparkles className="w-4 h-4 text-[#A8763E]" />
            <span>Bespoke Architectural Woodcraft</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#231812] tracking-tight">
            Custom Wooden Door Designs
          </h2>
          <div className="w-16 h-0.5 bg-[#A8763E] mx-auto mt-4 mb-4" />
          <p className="text-base sm:text-lg text-[#57473B] leading-relaxed">
            Where your vision becomes art. From custom family monograms and sacred deity reliefs to oversized contemporary pivot doors, we engineer bespoke woodwork for discerning homes.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {customPillars.map((pillar, idx) => (
            <div 
              key={idx}
              className="bg-[#FAF7F2] border border-[#E2D9C8] hover:border-[#A8763E] rounded-2xl p-6 transition-all duration-300 shadow-sm hover:shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-white border border-[#E2D9C8] flex items-center justify-center mb-4 shadow-sm">
                  {pillar.icon}
                </div>
                <h3 className="font-serif-luxury text-lg font-bold text-[#231812] mb-2">
                  {pillar.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#57473B] leading-relaxed">
                  {pillar.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Custom Process Flow: From Image to Door */}
        <div className="bg-[#FAF7F2] rounded-3xl p-8 sm:p-12 border border-[#E2D9C8] mb-16 shadow-sm">
          <div className="max-w-3xl mb-8">
            <span className="text-xs uppercase tracking-widest text-[#A8763E] font-bold font-mono">
              The Bespoke Execution Workflow
            </span>
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#231812] mt-1">
              How We Turn Your Idea into a Sculpted Door
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
            <div className="bg-white rounded-2xl p-5 border border-[#E2D9C8] relative">
              <div className="w-8 h-8 rounded-full bg-[#2B1810] text-[#FAF7F2] flex items-center justify-center font-bold text-xs mb-3 font-mono">
                01
              </div>
              <h4 className="font-bold text-[#231812] text-sm mb-1.5 flex items-center gap-1.5">
                <UploadCloud className="w-4 h-4 text-[#A8763E]" />
                <span>Share Reference</span>
              </h4>
              <p className="text-xs text-[#57473B] leading-relaxed">
                Send us a photo, sketch, or architect plan via our quote form or directly on WhatsApp.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-[#E2D9C8] relative">
              <div className="w-8 h-8 rounded-full bg-[#2B1810] text-[#FAF7F2] flex items-center justify-center font-bold text-xs mb-3 font-mono">
                02
              </div>
              <h4 className="font-bold text-[#231812] text-sm mb-1.5 flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-[#A8763E]" />
                <span>3D CAD Model</span>
              </h4>
              <p className="text-xs text-[#57473B] leading-relaxed">
                We generate a precision 3D CAD visualization showing relief depths, frame clearances, and proportions for your sign-off.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-[#E2D9C8] relative">
              <div className="w-8 h-8 rounded-full bg-[#2B1810] text-[#FAF7F2] flex items-center justify-center font-bold text-xs mb-3 font-mono">
                03
              </div>
              <h4 className="font-bold text-[#231812] text-sm mb-1.5 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-[#A8763E]" />
                <span>Wood Selection</span>
              </h4>
              <p className="text-xs text-[#57473B] leading-relaxed">
                Select your preferred timber (Solid Teak, Anjili, Rosewood). Seasoned timber is selected for optimal grain continuity.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-[#E2D9C8] relative">
              <div className="w-8 h-8 rounded-full bg-[#2B1810] text-[#FAF7F2] flex items-center justify-center font-bold text-xs mb-3 font-mono">
                04
              </div>
              <h4 className="font-bold text-[#231812] text-sm mb-1.5 flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-[#A8763E]" />
                <span>Carve & Polish</span>
              </h4>
              <p className="text-xs text-[#57473B] leading-relaxed">
                Precision CNC carving followed by master hand chisel detailing, multi-stage sanding, and PU coating.
              </p>
            </div>
          </div>
        </div>

        {/* Customized Offerings Showcase */}
        <div className="mb-16">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8">
            <div>
              <span className="text-xs uppercase tracking-widest text-[#A8763E] font-bold">Featured Commissions</span>
              <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#231812]">
                Customizable Door Suites
              </h3>
            </div>
            <button
              onClick={() => onRequestCustomQuote('Bespoke Custom Commission')}
              className="mt-4 sm:mt-0 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#A8763E] hover:text-[#231812] transition-colors"
            >
              <span>Submit Custom Requirement</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {customizedProducts.map((product) => (
              <div
                key={product.id}
                className="bg-[#FAF7F2] rounded-2xl border border-[#E2D9C8] hover:border-[#A8763E] overflow-hidden transition-all duration-300 shadow-sm hover:shadow-lg flex flex-col"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-black/5">
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                  <div className="absolute top-3 left-3 bg-[#2B1810]/90 backdrop-blur-sm text-[#FAF7F2] px-3 py-1 rounded text-[11px] font-bold uppercase tracking-wider">
                    Custom Commission
                  </div>

                  <button
                    onClick={() => toggleSaveItem({
                      id: product.id,
                      title: product.name,
                      category: product.category,
                      imageUrl: product.imageUrl,
                      type: 'product',
                      savedAt: new Date().toISOString()
                    }, true)}
                    className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm border border-[#E2D9C8] hover:border-[#A8763E] flex items-center justify-center text-[#231812] hover:text-[#A8763E] transition-all shadow-sm z-10"
                    title={isItemSaved(product.id) ? 'Saved' : 'Save Design'}
                  >
                    <Heart className={`w-4 h-4 ${isItemSaved(product.id) ? 'fill-[#A8763E] text-[#A8763E]' : ''}`} />
                  </button>
                </div>

                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="text-[11px] text-[#A8763E] uppercase tracking-widest font-bold mb-1">
                      {product.category}
                    </div>
                    <h4 className="font-serif-luxury text-xl font-bold text-[#231812] mb-2">
                      {product.name}
                    </h4>
                    <p className="text-xs text-[#57473B] mb-4 leading-relaxed line-clamp-2">
                      {product.description}
                    </p>

                    <div className="space-y-1 text-xs text-[#57473B] mb-4 bg-white p-3 rounded-xl border border-[#E2D9C8]">
                      <div><strong className="text-[#231812]">Wood:</strong> {product.woodType}</div>
                      <div><strong className="text-[#231812]">Lead Time:</strong> {product.leadTime || '10-15 days'}</div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-[#E2D9C8] flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase text-[#8A7A6E] block font-semibold">Estimate</span>
                      <span className="font-serif-luxury text-base font-bold text-[#A8763E]">{product.price || 'Price on Request'}</span>
                    </div>

                    <button
                      onClick={() => onRequestCustomQuote(product.name)}
                      className="px-4 py-2.5 rounded-lg bg-[#2B1810] hover:bg-[#A8763E] text-[#FAF7F2] text-xs font-bold uppercase tracking-wider transition-colors shadow-sm"
                    >
                      Inquire Custom Build
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Timber Guide Interactive Component */}
        <div className="bg-[#FAF7F2] border border-[#E2D9C8] rounded-3xl p-8 sm:p-12 mb-16">
          <div className="max-w-2xl mb-8">
            <span className="text-xs uppercase tracking-widest text-[#A8763E] font-bold font-mono">
              Raw Materials & Timber Science
            </span>
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#231812] mt-1">
              Select Your Preferred Wood Species
            </h3>
            <p className="text-sm text-[#57473B] mt-2">
              We source sustainable, government-certified timbers seasoned in our kiln to ensure long-term durability in Kerala&apos;s climate.
            </p>
          </div>

          {/* Timber Selection Tabs */}
          <div className="flex flex-wrap gap-2 mb-6">
            {(['teak', 'anjili', 'rosewood', 'mahogany'] as const).map((key) => (
              <button
                key={key}
                onClick={() => setSelectedWoodTab(key)}
                className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold capitalize transition-all ${
                  selectedWoodTab === key
                    ? 'bg-[#2B1810] text-[#FAF7F2] shadow-sm'
                    : 'bg-white text-[#57473B] border border-[#E2D9C8] hover:border-[#A8763E]'
                }`}
              >
                {key === 'teak' ? 'Teak Wood (Thekk)' : key === 'anjili' ? 'Anjili Wood (Ayani)' : key === 'rosewood' ? 'Rosewood (Eetti)' : 'Hardwood / Mahogany'}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#E2D9C8]">
            <h4 className="font-serif-luxury text-xl font-bold text-[#231812] mb-2">
              {woodInfo[selectedWoodTab].name}
            </h4>
            <p className="text-sm text-[#57473B] leading-relaxed mb-6">
              {woodInfo[selectedWoodTab].description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#E2D9C8]">
                <span className="text-[#8A7A6E] font-semibold uppercase tracking-wider block mb-1">Durability Rating</span>
                <span className="font-bold text-[#231812] text-sm">{woodInfo[selectedWoodTab].durability}</span>
              </div>
              <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#E2D9C8]">
                <span className="text-[#8A7A6E] font-semibold uppercase tracking-wider block mb-1">Recommended Applications</span>
                <span className="font-bold text-[#231812] text-sm">{woodInfo[selectedWoodTab].bestFor}</span>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Box */}
        <div className="text-center bg-gradient-to-br from-[#FAF7F2] via-[#F5EFE6] to-[#FAF7F2] text-[#231812] p-10 sm:p-14 rounded-3xl shadow-sm relative overflow-hidden border border-[#E2D9C8]">
          <h3 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-[#231812] mb-3">
            Have a Specific Door Design or Reference Photo?
          </h3>
          <p className="text-sm sm:text-base text-[#57473B] max-w-2xl mx-auto mb-8 leading-relaxed">
            Upload your picture or blueprint through our quote request form. Our craftsmen will calculate the wood requirement and share a transparent 3D design estimate within 24 hours.
          </p>
          <button
            onClick={() => onRequestCustomQuote('Custom Reference Photo Carving')}
            className="px-8 py-4 rounded-xl bg-[#A8763E] hover:bg-[#91632F] text-white font-bold text-xs sm:text-sm uppercase tracking-widest shadow-md inline-flex items-center gap-2 transition-transform active:scale-95"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Request Custom Design Quote</span>
          </button>
        </div>

      </div>
    </section>
  );
};
