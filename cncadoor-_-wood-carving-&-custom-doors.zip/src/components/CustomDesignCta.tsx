import React from 'react';

interface CustomDesignCtaProps {
  onSendDesign: () => void;
  onRequestQuote: () => void;
}

export const CustomDesignCta: React.FC<CustomDesignCtaProps> = ({ onRequestQuote }) => {
  return (
    <section className="relative py-28 overflow-hidden bg-[#100F0E] text-white">
      {/* Moody Dark Wooden Room Background with armchair & interior credenza */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=2200&q=80"
          alt="Dark Moody Architectural Interior with Teak Armchair"
          className="w-full h-full object-cover object-center filter brightness-45 contrast-110"
          referrerPolicy="no-referrer"
        />
        {/* Soft radial overlay for center focus */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/85" />
        <div className="absolute inset-0 bg-radial-at-c from-black/20 via-black/50 to-black/80" />
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center flex flex-col items-center">
        
        <h2 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-normal text-white tracking-normal mb-4">
          Have Your Own Design in Mind?
        </h2>

        <p className="text-sm sm:text-base text-[#D4CCC2] max-w-2xl mx-auto leading-relaxed mb-8 font-light">
          Share your ideas with us and we&apos;ll help you turn them into something beautiful.
        </p>

        <button
          id="cta-request-quote-btn"
          onClick={onRequestQuote}
          className="px-8 py-3.5 rounded-md text-xs uppercase tracking-[0.16em] font-bold bg-[#C59B4B] hover:bg-[#B38737] text-[#121212] transition-all duration-300 shadow-xl active:scale-95"
        >
          REQUEST A QUOTE
        </button>

      </div>
    </section>
  );
};

