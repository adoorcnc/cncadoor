import React, { useState, useMemo } from 'react';
import { DOORS_DATA, DOOR_CATEGORIES } from '../data/config';
import { DoorItem } from '../types';
import { Search, ArrowRight, Heart, Download, FileText } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { generateCatalogPdf } from '../utils/generateCatalogPdf';

interface OurDoorsProps {
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  onRequestQuote: (doorName?: string, doorType?: string) => void;
  onOpenCatalog?: () => void;
}

export const OurDoors: React.FC<OurDoorsProps> = ({ 
  selectedCategory, 
  setSelectedCategory,
  onRequestQuote,
  onOpenCatalog
}) => {
  const { toggleSaveItem, isItemSaved } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDoorForDetail, setSelectedDoorForDetail] = useState<DoorItem | null>(null);

  const filteredDoors = useMemo(() => {
    return DOORS_DATA.filter((door) => {
      const matchesCategory = selectedCategory === 'All' || door.category === selectedCategory;
      const matchesSearch = searchQuery === '' || 
        door.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        door.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (door.woodType && door.woodType.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  const handleToggleHeart = (e: React.MouseEvent, door: DoorItem) => {
    e.stopPropagation();
    toggleSaveItem({
      id: door.id,
      title: door.name,
      category: door.category,
      imageUrl: door.imageUrl,
      type: 'door',
      savedAt: new Date().toISOString(),
    }, true);
  };

  return (
    <section id="our-doors-section" className="py-20 bg-[#FAF7F2] text-[#231812] relative border-b border-[#E8E1D5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs uppercase tracking-[0.22em] text-[#A8763E] font-bold mb-3">
            Handcrafted Door Catalogue
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-normal text-[#231812] mb-4">
            Our Doors
          </h2>
          <div className="w-16 h-[2px] bg-[#A8763E] mx-auto mb-4" />
          <p className="text-[#57473B] text-sm sm:text-base font-light leading-relaxed">
            Every door is custom manufactured from high-grade seasoned timber, carved with precision, and tailored to the exact architectural specifications of your space.
          </p>
        </div>

        {/* Category Filters Bar & Search */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-4 mb-12 bg-white p-3.5 rounded-xl border border-[#E8E1D5] shadow-sm">
          
          {/* Filter Pills */}
          <div className="flex flex-wrap gap-2 justify-center lg:justify-start w-full lg:w-auto">
            {DOOR_CATEGORIES.map((category) => {
              const isActive = selectedCategory === category;
              return (
                <button
                  key={category}
                  id={`door-cat-${category.replace(/\s+/g, '-').toLowerCase()}`}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-lg text-xs uppercase tracking-wider font-semibold transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-[#A8763E] text-white shadow-sm font-bold'
                      : 'bg-[#FAF7F2] text-[#57473B] hover:text-[#231812] hover:bg-[#F2EAE0] border border-[#E2D9C8]'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>

          {/* Search & PDF Catalog Action */}
          <div className="flex items-center gap-2 w-full lg:w-auto">
            <div className="relative flex-1 lg:w-60">
              <Search className="w-4 h-4 text-[#8A7A6E] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search wood or style..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-[#FAF7F2] border border-[#E2D9C8] rounded-lg text-xs text-[#231812] placeholder-[#8A7A6E] focus:outline-none focus:border-[#A8763E]"
              />
            </div>

            <button
              id="our-doors-download-catalog-btn"
              onClick={() => {
                if (onOpenCatalog) onOpenCatalog();
                else generateCatalogPdf({ categoryFilter: selectedCategory });
              }}
              title="Download PDF Catalog & Brochure"
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-[#FAF5EE] hover:bg-[#F2ECE1] border border-[#A8763E]/40 hover:border-[#A8763E] text-[#A8763E] rounded-lg text-xs font-semibold whitespace-nowrap transition-colors shadow-xs cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-[#A8763E]" />
              <span className="hidden sm:inline">PDF Catalog</span>
              <Download className="w-3 h-3 text-[#A8763E]" />
            </button>
          </div>
        </div>

        {/* Doors Grid */}
        {filteredDoors.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-xl border border-[#E8E1D5]">
            <p className="text-base text-[#57473B] mb-4">No door designs match your search filter.</p>
            <button
              onClick={() => { setSelectedCategory('All'); setSearchQuery(''); }}
              className="px-4 py-2 text-xs uppercase tracking-wider font-bold bg-[#A8763E] text-white rounded-md shadow-sm"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredDoors.map((door) => (
              <div
                key={door.id}
                id={`door-item-${door.id}`}
                className="bg-white border border-[#E8E1D5] rounded-xl overflow-hidden flex flex-col hover:border-[#A8763E] transition-all duration-300 shadow-sm hover:shadow-lg group"
              >
                {/* Door Photo Container */}
                <div 
                  className="relative aspect-[4/5] overflow-hidden bg-[#FAF7F2] cursor-pointer"
                  onClick={() => setSelectedDoorForDetail(door)}
                >
                  <img
                    src={door.imageUrl}
                    alt={door.name}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Category Chip */}
                  <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm border border-[#E8E1D5] px-3 py-1 rounded text-[11px] font-semibold tracking-wide text-[#A8763E] shadow-sm">
                    {door.category}
                  </div>

                  {/* Save to Shortlist Heart Button */}
                  <button
                    id={`save-door-${door.id}`}
                    onClick={(e) => handleToggleHeart(e, door)}
                    className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm border border-[#E2D9C8] hover:border-[#A8763E] flex items-center justify-center text-[#57473B] hover:text-[#A8763E] transition-all z-10 shadow-sm"
                    title={isItemSaved(door.id) ? 'Saved in Shortlist' : 'Save to Shortlist'}
                    aria-label="Save door to shortlist"
                  >
                    <Heart className={`w-4 h-4 ${isItemSaved(door.id) ? 'fill-[#A8763E] text-[#A8763E]' : ''}`} />
                  </button>

                  {/* Detail Quick View Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30 backdrop-blur-[1px]">
                    <span className="px-4 py-2 rounded-md bg-white border border-[#A8763E] text-xs uppercase tracking-widest text-[#A8763E] font-bold shadow-lg">
                      View Specifications
                    </span>
                  </div>
                </div>

                {/* Door Card Details */}
                <div className="p-6 flex flex-col flex-grow justify-between bg-white">
                  <div>
                    <h3 className="font-serif-luxury text-lg font-medium text-[#231812] group-hover:text-[#A8763E] transition-colors mb-2">
                      {door.name}
                    </h3>
                    <p className="text-xs text-[#6B5E53] font-light leading-relaxed mb-4 line-clamp-2">
                      {door.description}
                    </p>

                    {/* Wood / Material Info */}
                    {door.woodType && (
                      <div className="bg-[#FAF7F2] border border-[#E8E1D5] rounded-lg p-2.5 mb-4 text-[11px]">
                        <span className="text-[#A8763E] font-semibold uppercase tracking-wider block mb-0.5">Wood / Material:</span>
                        <span className="text-[#3F332A]">{door.woodType}</span>
                      </div>
                    )}
                  </div>

                  {/* Pricing Notice & Request Quote Action */}
                  <div className="pt-4 border-t border-[#E8E1D5]">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <span className="text-[10px] uppercase tracking-wider text-[#7A6E63] block">Pricing</span>
                        <span className="font-serif-luxury text-base font-bold text-[#A8763E]">Price on Request</span>
                      </div>
                      <span className="text-[10px] text-[#7A6E63] italic max-w-[130px] text-right">
                        Based on size, timber & carving depth
                      </span>
                    </div>

                    <button
                      id={`quote-btn-${door.id}`}
                      onClick={() => onRequestQuote(door.name, door.category)}
                      className="w-full py-2.5 rounded-md text-xs uppercase tracking-[0.14em] font-bold bg-[#A8763E] hover:bg-[#91632F] text-white transition-all flex items-center justify-center gap-2 shadow-sm active:scale-95"
                    >
                      <span>REQUEST A QUOTE</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                </div>
              </div>
            ))}
          </div>
        )}

        {/* Door Detailed Modal */}
        {selectedDoorForDetail && (
          <div 
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setSelectedDoorForDetail(null)}
          >
            <div 
              className="bg-white border border-[#E8E1D5] max-w-2xl w-full rounded-xl overflow-hidden shadow-2xl animate-fadeIn text-[#231812]"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative aspect-[16/10] bg-[#FAF7F2]">
                <img
                  src={selectedDoorForDetail.imageUrl}
                  alt={selectedDoorForDetail.name}
                  className="w-full h-full object-cover object-center"
                  referrerPolicy="no-referrer"
                />
                <button
                  onClick={() => setSelectedDoorForDetail(null)}
                  className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/90 text-[#231812] border border-[#E2D9C8] flex items-center justify-center hover:bg-[#A8763E] hover:text-white transition-colors shadow-sm"
                >
                  ✕
                </button>
              </div>

              <div className="p-6">
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#A8763E] mb-1 font-semibold">
                  <span>{selectedDoorForDetail.category}</span>
                </div>
                <h3 className="font-serif-luxury text-2xl font-normal text-[#231812] mb-3">
                  {selectedDoorForDetail.name}
                </h3>
                <p className="text-sm text-[#57473B] font-light leading-relaxed mb-6">
                  {selectedDoorForDetail.description}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 bg-[#FAF7F2] p-4 rounded-lg border border-[#E8E1D5] text-xs">
                  <div>
                    <span className="text-[#A8763E] font-semibold block mb-1">Wood / Material Option:</span>
                    <span className="text-[#3F332A]">{selectedDoorForDetail.woodType || 'Selected Seasoned Hardwood / Teak'}</span>
                  </div>
                  <div>
                    <span className="text-[#A8763E] font-semibold block mb-1">Dimensions:</span>
                    <span className="text-[#3F332A]">{selectedDoorForDetail.dimensionsNote || 'Custom manufactured to required frame size'}</span>
                  </div>
                  {selectedDoorForDetail.carvingStyle && (
                    <div className="sm:col-span-2">
                      <span className="text-[#A8763E] font-semibold block mb-1">Carving Style:</span>
                      <span className="text-[#3F332A]">{selectedDoorForDetail.carvingStyle}</span>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-[#E8E1D5]">
                  <div>
                    <span className="text-[11px] text-[#7A6E63] uppercase tracking-wider block">Quotation</span>
                    <span className="font-serif-luxury text-lg font-bold text-[#A8763E]">Price on Request</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        const d = selectedDoorForDetail;
                        toggleSaveItem({
                          id: d.id,
                          title: d.name,
                          category: d.category,
                          imageUrl: d.imageUrl,
                          type: 'door',
                          savedAt: new Date().toISOString(),
                        }, true);
                      }}
                      className={`px-4 py-2.5 rounded-lg text-xs font-semibold border transition-all flex items-center gap-1.5 ${
                        isItemSaved(selectedDoorForDetail.id)
                          ? 'bg-[#FAF5EE] text-[#A8763E] border-[#A8763E]'
                          : 'bg-white text-[#57473B] border-[#D5CBC0] hover:border-[#A8763E]'
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${isItemSaved(selectedDoorForDetail.id) ? 'fill-[#A8763E] text-[#A8763E]' : ''}`} />
                      <span>{isItemSaved(selectedDoorForDetail.id) ? 'Saved' : 'Save Design'}</span>
                    </button>

                    <button
                      onClick={() => {
                        const d = selectedDoorForDetail;
                        setSelectedDoorForDetail(null);
                        onRequestQuote(d.name, d.category);
                      }}
                      className="px-6 py-2.5 rounded-lg text-xs uppercase tracking-widest font-bold bg-[#A8763E] hover:bg-[#91632F] text-white shadow-sm transition-colors"
                    >
                      REQUEST A QUOTE
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
