import React from 'react';

interface HeroProps {
  onExploreDoors: () => void;
  onRequestQuote: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreDoors, onRequestQuote }) => {
  return (
    <section className="relative min-h-[85vh] lg:min-h-[92vh] flex items-center justify-center overflow-hidden bg-[#0F0E0D]">
      {/* Cinematic Dark Villa Entrance Background with warm lighting */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=2200&q=85"
          alt="Luxury Architectural Wooden Door and Warm Interior"
          className="w-full h-full object-cover object-center filter brightness-65"
          referrerPolicy="no-referrer"
        />
        {/* Subtle dark gradient overlays to ensure razor-sharp typographic contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-black/45 to-black/60" />
        <div className="absolute inset-0 bg-radial-at-c from-transparent via-black/30 to-black/75" />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 text-center flex flex-col items-center">
        
        {/* Headline matching the exact model image */}
        <h1 className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl font-bold tracking-[0.04em] text-white max-w-4xl leading-[1.12] mb-6 uppercase drop-shadow-md">
          DESIGNING SPACES, <br />
          CRAFTING COMFORT
        </h1>

        {/* Subtitle matching the model theme */}
        <p className="text-sm sm:text-base md:text-lg text-[#DDD5CA] max-w-2xl font-light tracking-wide leading-relaxed mb-10">
          Handcrafted solid wooden doors and precision CNC wood carvings crafted to perfection for your dream space.
        </p>

        {/* Action Buttons matching the model theme */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto">
          <button
            id="hero-explore-doors-btn"
            onClick={onExploreDoors}
            className="w-full sm:w-auto px-8 py-3.5 rounded-md text-xs uppercase tracking-[0.16em] font-bold bg-[#C59B4B] hover:bg-[#B38737] text-[#121212] transition-all duration-300 shadow-xl active:scale-95 flex items-center justify-center gap-2"
          >
            VIEW DESIGNS
          </button>

          <button
            id="hero-request-quote-btn"
            onClick={onRequestQuote}
            className="w-full sm:w-auto px-8 py-3.5 rounded-md text-xs uppercase tracking-[0.16em] font-semibold bg-transparent hover:bg-white/10 text-white border border-white/40 hover:border-white transition-all duration-300 shadow-sm active:scale-95 flex items-center justify-center gap-2 backdrop-blur-xs"
          >
            GET A QUOTE
          </button>
        </div>

      </div>
    </section>
  );
};

