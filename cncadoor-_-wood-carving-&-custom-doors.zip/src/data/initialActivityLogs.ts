import { ActivityLogItem } from '../types';

export const INITIAL_ACTIVITY_LOGS: ActivityLogItem[] = [
  {
    id: 'act-101',
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(), // 12 mins ago
    category: 'users',
    action: 'user_login',
    title: 'Owner Admin Session Verified',
    details: 'Master administrative access granted for adoorcnc@gmail.com with Owner/Admin privileges.',
    performedBy: 'adoorcnc@gmail.com (Owner)',
    targetId: 'usr_admin_master',
    targetName: 'adoorcnc@gmail.com',
    severity: 'success',
    meta: {
      newValue: 'Admin Dual-View Active',
      badgeText: 'Auth Verified'
    }
  },
  {
    id: 'act-102',
    timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(), // 45 mins ago
    category: 'doors',
    action: 'door_status_changed',
    title: 'Door Published to Storefront',
    details: 'Heritage Lotus Teak Entrance Door (In-Stock) changed status from Draft to Published.',
    performedBy: 'adoorcnc@gmail.com',
    targetId: 'prod-rm-1',
    targetName: 'Heritage Lotus Teak Entrance Door',
    severity: 'success',
    meta: {
      previousValue: 'draft',
      newValue: 'published',
      badgeText: 'Status Change'
    }
  },
  {
    id: 'act-103',
    timestamp: new Date(Date.now() - 1000 * 60 * 110).toISOString(), // ~1.8 hours ago
    category: 'quotes',
    action: 'quote_status_changed',
    title: 'Quote Status Updated: Quotation Sent',
    details: 'Updated quote inquiry #ENQ-101 for Rajesh Nair (Double Teak Door). Cost estimate of ₹68,000 sent via WhatsApp.',
    performedBy: 'adoorcnc@gmail.com',
    targetId: 'enq-101',
    targetName: 'Rajesh Nair (Enquiry #101)',
    severity: 'info',
    meta: {
      previousValue: 'New',
      newValue: 'Quotation Sent',
      badgeText: 'Estimate Sent'
    }
  },
  {
    id: 'act-104',
    timestamp: new Date(Date.now() - 1000 * 60 * 220).toISOString(), // ~3.5 hours ago
    category: 'doors',
    action: 'door_updated',
    title: 'Door Inventory & Price Adjusted',
    details: 'Updated stock count (2 units) and promotional workshop direct price (₹46,500) for Heritage Lotus Teak Entrance Door.',
    performedBy: 'adoorcnc@gmail.com',
    targetId: 'prod-rm-1',
    targetName: 'Heritage Lotus Teak Entrance Door',
    severity: 'info',
    meta: {
      previousValue: '₹52,000',
      newValue: '₹46,500 (Direct Workshop Price)',
      badgeText: 'Price Update'
    }
  },
  {
    id: 'act-105',
    timestamp: new Date(Date.now() - 1000 * 60 * 360).toISOString(), // 6 hours ago
    category: 'quotes',
    action: 'quote_received',
    title: 'New Custom Door Quote Received',
    details: 'New quote submission from Dr. Anjali Menon for Traditional Kerala Pillar Frame Door with custom brass cladding requirement.',
    performedBy: 'System / Public Website',
    targetId: 'enq-102',
    targetName: 'Dr. Anjali Menon (Quote Request)',
    severity: 'warning',
    meta: {
      newValue: 'New Pending Enquiry',
      badgeText: 'Lead Captured'
    }
  },
  {
    id: 'act-106',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 14).toISOString(), // 14 hours ago
    category: 'doors',
    action: 'door_created',
    title: 'New Ready-Made Product Catalogued',
    details: 'Added "Carved Teak Pooja Room Double Shutter (Pair)" with 3 units in stock at ₹34,800 direct pickup.',
    performedBy: 'adoorcnc@gmail.com',
    targetId: 'prod-rm-2',
    targetName: 'Carved Teak Pooja Room Double Shutter',
    severity: 'success',
    meta: {
      newValue: 'Published Ready-Made',
      badgeText: 'Catalog Add'
    }
  },
  {
    id: 'act-107',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(), // Yesterday
    category: 'settings',
    action: 'setting_updated',
    title: 'Workshop Contact & Broadcast Updated',
    details: 'Updated primary workshop direct WhatsApp line to +91 83018 51820 and updated homepage announcement banner.',
    performedBy: 'adoorcnc@gmail.com',
    targetId: 'config_workshop_contact',
    targetName: 'Business Profile Config',
    severity: 'neutral',
    meta: {
      newValue: 'Announcement Banner Active',
      badgeText: 'Settings Sync'
    }
  },
  {
    id: 'act-108',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 32).toISOString(), // Yesterday
    category: 'users',
    action: 'user_status_changed',
    title: 'Client Account Shortlist Synchronized',
    details: 'Client profile shortlisted 3 teak entrance models and initialized direct phone callback request.',
    performedBy: 'Client Session',
    targetId: 'usr_client_82',
    targetName: 'Sunil Kumar (Kottayam)',
    severity: 'info',
    meta: {
      newValue: '3 Saved Items Synced',
      badgeText: 'Customer Action'
    }
  }
];
