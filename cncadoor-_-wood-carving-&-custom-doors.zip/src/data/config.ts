import { BusinessConfig, DoorItem, CarvingPattern, ProcessStep, GalleryItem, FeaturedProject } from '../types';

export const BUSINESS_CONFIG: BusinessConfig = {
  name: 'CNCADOOR',
  subtitle: 'WOOD CARVING & DOOR DESIGN',
  tagline: 'Designing Spaces, Crafting Character — Handcrafted solid wooden doors and precision CNC wood carvings crafted to perfection.',
  phones: ['9876543210', '8301851820'],
  whatsapps: ['9876543210', '8301851820'],
  email: 'info@cncadoor.com',
  address: 'Kochi & Adoor, Kerala, India',
  locationDetails: 'Adoor & Kochi, Kerala',
  openingHours: '9:00am - 8:00pm',
  googleMapsUrl: 'https://maps.app.goo.gl/qvqmjgfBkN3FyUM79',
  whatsappMessage: 'Hello CNCADOOR, I would like to inquire about your custom wooden doors and precision wood carving services.',
};

export const DOOR_CATEGORIES = [
  'All',
  'Traditional Doors',
  'Carved Doors',
  'Main Entrance Doors',
  'Temple-Inspired Designs',
  'Contemporary Wooden Doors',
  'Custom Designs'
] as const;

export const DOORS_DATA: DoorItem[] = [
  {
    id: 'door-1',
    name: 'Imperial Heritage Carved Double Door',
    category: 'Main Entrance Doors',
    description: 'Majestic main entrance double doors featuring deep architectural floral relief carvings, ornamental architrave border, and solid timber construction.',
    woodType: 'Solid Teak Wood / Selected Hardwood',
    dimensionsNote: 'Customizable to standard & grand villa entrance dimensions',
    carvingStyle: 'High-relief traditional ornamental carving',
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
    featured: true
  },
  {
    id: 'door-2',
    name: 'Temple Motif Pooja & Sanctum Door',
    category: 'Temple-Inspired Designs',
    description: 'Sacred architectural wooden door crafted with traditional mandala geometric paneling, sacred floral medallions, and brass stud accent ready recesses.',
    woodType: 'Premium Teak / Anjili / Rosewood Options',
    dimensionsNote: 'Single & Double shutter specifications available',
    carvingStyle: 'Heritage Temple relief & rosette symmetry',
    imageUrl: 'https://images.unsplash.com/photo-1548625361-195fe5795df5?auto=format&fit=crop&w=1200&q=80',
    featured: true
  },
  {
    id: 'door-3',
    name: 'Royal Chettinad Traditional Entrance Door',
    category: 'Traditional Doors',
    description: 'Classic South Indian heritage styling featuring intricate multi-layered carved framing, pillared side trims, and traditional heavy jamb reliefs.',
    woodType: 'Aged Solid Teak / Country Hardwood',
    dimensionsNote: 'Grand entrance heights & heavy frame profiles',
    carvingStyle: 'Traditional Kerala & Chettinad architecture',
    imageUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80',
    featured: true
  },
  {
    id: 'door-4',
    name: 'Botanical Vine & Acanthus Carved Panel Door',
    category: 'Carved Doors',
    description: 'Artistic wooden door with flowing organic acanthus vine motifs sculptured across vertical stiles with raised center panels.',
    woodType: 'Solid Teak / Mahogany / Walnut Finish',
    dimensionsNote: 'Available for entrance or statement interior rooms',
    carvingStyle: 'Botanical high-definition relief carving',
    imageUrl: 'https://images.unsplash.com/photo-1509644851169-2acc08aa25b5?auto=format&fit=crop&w=1200&q=80',
    featured: true
  },
  {
    id: 'door-5',
    name: 'Modern Fluted & Geometric Entrance Door',
    category: 'Contemporary Wooden Doors',
    description: 'A seamless bridge between timeless woodcraft and modern architecture. Features precision fluted linear grooves, offset handle recess, and textured panels.',
    woodType: 'Natural Grain Teak / Hardwood with Natural Oil Polish',
    dimensionsNote: 'Custom pivot or hinged door configurations',
    carvingStyle: 'Precision architectural CNC fluting & geometric detailing',
    imageUrl: 'https://images.unsplash.com/photo-1517581177682-a085bb7ffb15?auto=format&fit=crop&w=1200&q=80',
    featured: false
  },
  {
    id: 'door-6',
    name: 'Artisan Custom Client-Designed Shutter',
    category: 'Custom Designs',
    description: 'Bespoke custom shutter manufactured directly from client reference sketches, integrating custom family emblems and architectural motifs.',
    woodType: 'Client Selected Wood (Teak, Jackfruit wood, Mahogany, etc.)',
    dimensionsNote: 'Bespoke exact site measurements',
    carvingStyle: 'Full custom design 2D/3D carving & hand finishing',
    imageUrl: 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1200&q=80',
    featured: true
  },
  {
    id: 'door-7',
    name: 'Lotus Medallion Classical Entrance Shutter',
    category: 'Carved Doors',
    description: 'Stunning nine-panel door featuring centered blooming lotus carvings and decorative border banding with natural wood grain highlighting.',
    woodType: 'Solid Teak Wood',
    dimensionsNote: 'Customizable shutter thickness and frame depth',
    carvingStyle: 'Lotus floral medallion & step panel molding',
    imageUrl: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?auto=format&fit=crop&w=1200&q=80',
    featured: false
  },
  {
    id: 'door-8',
    name: 'Grand Manor Arch Carved Wooden Shutter',
    category: 'Main Entrance Doors',
    description: 'Arched top entrance doorway with custom ornamental spandrels, heavy lower panel reliefs, and antique bronze fitting compatibility.',
    woodType: 'Kiln-seasoned Hardwood / Premium Teak',
    dimensionsNote: 'Round arch, segmental arch, or square frame designs',
    carvingStyle: 'Arched frame ornamental relief',
    imageUrl: 'https://images.unsplash.com/photo-1549492423-400259a2e574?auto=format&fit=crop&w=1200&q=80',
    featured: false
  },
  {
    id: 'door-9',
    name: 'Minimalist Linear Geometric Solid Shutter',
    category: 'Contemporary Wooden Doors',
    description: 'Understated elegance celebrating the raw depth of timber grain paired with subtle geometric incised patterns and brass inlay accents.',
    woodType: 'Natural Teak with Matte/Satin PU Finish',
    dimensionsNote: 'Standard & oversize single leaf options',
    carvingStyle: 'Clean linear grooving & micro-beveling',
    imageUrl: 'https://images.unsplash.com/photo-1582582621959-48d27397dc69?auto=format&fit=crop&w=1200&q=80',
    featured: false
  }
];

export const CARVING_PATTERNS: CarvingPattern[] = [
  {
    id: 'carve-trad',
    title: 'Traditional Carving',
    category: 'Traditional Carving',
    description: 'Heritage motifs rooted in traditional architectural woodcraft. Includes ornate temple architraves, mythical beast medallions, kalasam flourishes, and sacred geometry that bestow grand dignity upon any doorway.',
    details: [
      'Deep 3D relief carving depths up to 25mm-40mm',
      'Classical architectural proportions and border trims',
      'Temple sanctum pooja door traditional carvings',
      'Heritage pillar and threshold detailing'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1548625361-195fe5795df5?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'carve-floral',
    title: 'Floral & Nature Motifs',
    category: 'Floral & Nature Motifs',
    description: 'Graceful botanical carvings inspired by the natural world — cascading acanthus leaves, blooming lotus rosettes, swirling vines, and delicate floral borders sculpted with organic rhythm.',
    details: [
      'Continuous running vine borders on stiles and rails',
      'Multi-petaled blooming lotus center rosettes',
      'Tree of life and botanical panel sculptures',
      'Hand-finished petal feathering and textured leaf veins'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1509644851169-2acc08aa25b5?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'carve-geo',
    title: 'Geometric & Ornamental Patterns',
    category: 'Geometric Patterns',
    description: 'Crisp, structured symmetry marrying timeless mathematical precision with the warm depth of natural timber. Ideal for both contemporary residences and ornate heritage interiors.',
    details: [
      'Intricate Islamic & Moorish latticework / Jali panels',
      'Diamond lattice, herringbone, and multi-tier step relief',
      'Modern fluted and acoustic rhythmic timber grooving',
      'Sharp chamfered edges with shadow-line depth'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1517581177682-a085bb7ffb15?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'carve-custom',
    title: 'Custom & Bespoke Carving',
    category: 'Custom Carving',
    description: 'Provide your own drawings, CAD files, architect sketches, or photographic references. We translate your custom vision into precision wood carving with master craftsmanship.',
    details: [
      'Client sketch / reference image translation',
      'Custom family crests, monogram reliefs, and murals',
      'Tailored depth, scale, and wood selection consultation',
      'Sample carving review prior to full door execution'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1000&q=80'
  }
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    step: '01',
    title: 'Design',
    description: 'Understand the customer\'s idea and requirements.',
    details: 'We begin by reviewing your architectural style, doorway dimensions, and design references (photos, sketches, or CAD drawings).'
  },
  {
    step: '02',
    title: 'Selection',
    description: 'Select the appropriate wood/material according to the project.',
    details: 'We help you choose the ideal timber (such as premium Teak, Anjili, Rosewood, or selected Hardwoods) based on structural stability and grain character.'
  },
  {
    step: '03',
    title: 'Carving',
    description: 'Create the required decorative details and patterns.',
    details: 'Our skilled craftsmen execute the intricate motifs utilizing advanced precision CNC carving combined with artisanal detailing.'
  },
  {
    step: '04',
    title: 'Finishing',
    description: 'Complete sanding, detailing, polishing/staining, and finishing as applicable.',
    details: 'Careful progressive sanding, edge softening, grain enhancement, and application of high-durability natural wood stains and protective sealants.'
  },
  {
    step: '05',
    title: 'Workshop Inspection & Pickup',
    description: 'Customer collects the finished door directly from our Adoor workshop.',
    details: 'Pre-handover quality inspection, heavy protective packaging, and vehicle loading assistance directly at our workshop. Please note we do not provide delivery service.'
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g-1',
    title: 'Intricate Floral Door Medallion Carving',
    category: 'CARVING',
    description: 'Deep relief carving on seasoned solid teak wood showing exquisite petal layering.',
    woodType: 'Solid Teak',
    aspectRatio: 'square',
    imageUrl: 'https://images.unsplash.com/photo-1548625361-195fe5795df5?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'g-2',
    title: 'Grand Villa Entrance Double Door Shutter',
    category: 'DOORS',
    description: 'Magnificent arched entrance door installed with solid brass antique pull handles.',
    woodType: 'Teak Hardwood',
    aspectRatio: 'tall',
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'g-3',
    title: 'Hand-Finished Timber Acanthus Leaf Close-Up',
    category: 'DETAILS',
    description: 'Macro focus on precision chiseling and smooth grain transition in natural wood.',
    woodType: 'Natural Hardwood',
    aspectRatio: 'wide',
    imageUrl: 'https://images.unsplash.com/photo-1509644851169-2acc08aa25b5?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'g-4',
    title: 'Heritage South Indian Entrance Frame & Shutter',
    category: 'COMPLETED WORK',
    description: 'Completed site installation of traditional Kerala style carved main door.',
    woodType: 'Seasoned Teak',
    aspectRatio: 'tall',
    imageUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'g-5',
    title: 'Decorative Architectural Wood Ceiling & Wall Panel',
    category: 'CARVING',
    description: 'Custom acoustic and decorative geometric paneling with deep shadow reveals.',
    woodType: 'Solid Wood Panel',
    aspectRatio: 'wide',
    imageUrl: 'https://images.unsplash.com/photo-1517581177682-a085bb7ffb15?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'g-6',
    title: 'Custom Client Design Carving in Progress',
    category: 'DETAILS',
    description: 'Artisan refining contours and wood texture before final polishing.',
    woodType: 'High-density timber',
    aspectRatio: 'square',
    imageUrl: 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'g-7',
    title: 'Traditional Temple Shrine Wooden Door Shutter',
    category: 'DOORS',
    description: 'Symmetrical traditional pooja room doors with brass fixture recesses.',
    woodType: 'Selected Teak Wood',
    aspectRatio: 'tall',
    imageUrl: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'g-8',
    title: 'Antique Finish Wood Grain & Carved Border',
    category: 'DETAILS',
    description: 'Subtle antique hand-rubbed finish revealing the natural timber character.',
    woodType: 'Aged Teak',
    aspectRatio: 'wide',
    imageUrl: 'https://images.unsplash.com/photo-1582582621959-48d27397dc69?auto=format&fit=crop&w=1000&q=80'
  },
  {
    id: 'g-9',
    title: 'Residential Architectural Entrance Installation',
    category: 'COMPLETED WORK',
    description: 'Contemporary architectural residence featuring bespoke CNCADOOR main entrance.',
    woodType: 'Solid Hardwood & Teak',
    aspectRatio: 'tall',
    imageUrl: 'https://images.unsplash.com/photo-1549492423-400259a2e574?auto=format&fit=crop&w=1000&q=80'
  }
];

export const FEATURED_PROJECTS: FeaturedProject[] = [
  {
    id: 'fp-1',
    title: 'Elegant Wooden Entrance',
    description: 'Grand bespoke teak entrance door paired with architectural wall sconces, stone steps, and natural exterior planters.',
    woodType: 'Seasoned Solid Teak',
    location: 'Trivandrum',
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Solid teak grand scale', 'Precision architectural fluting', 'Custom brass hardware']
  },
  {
    id: 'fp-2',
    title: 'Modern Kitchen Setup',
    description: 'Custom handcrafted solid teak dining table, matching upholstered chairs, and warm wood cabinetry with ambient pendant lighting.',
    woodType: 'Solid Teak & Oak Finish',
    location: 'Kochi',
    imageUrl: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1200&q=80',
    highlights: ['6-Seater custom dining table', 'Solid wood kitchen cabinets', 'Natural food-grade oil seal']
  },
  {
    id: 'fp-3',
    title: 'Living Room Interior',
    description: 'Architectural vertical wooden wall paneling with integrated TV media console, floating shelves, and warm interior lighting.',
    woodType: 'Premium Teak & Hardwood',
    location: 'Calicut',
    imageUrl: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Acoustic slatted wood wall', 'Floating media console unit', 'Concealed wire management']
  }
];

export const CATEGORY_BAR_ITEMS = [
  {
    id: 'main-doors',
    title: 'MAIN DOORS',
    subtitle: 'Strong. Secure. Beautiful.',
    type: 'doors',
    category: 'Main Entrance Doors',
  },
  {
    id: 'traditional-doors',
    title: 'TRADITIONAL DOORS',
    subtitle: 'Heritage elegance in solid timber.',
    type: 'doors',
    category: 'Traditional Doors',
  },
  {
    id: 'carved-doors',
    title: 'CARVED DOORS',
    subtitle: 'Intricate artistic relief carving.',
    type: 'doors',
    category: 'Carved Doors',
  },
  {
    id: 'temple-pooja',
    title: 'TEMPLE & POOJA DOORS',
    subtitle: 'Sacred motifs & divine woodcraft.',
    type: 'doors',
    category: 'Temple-Inspired Designs',
  },
  {
    id: 'custom-designs',
    title: 'CUSTOM DESIGNS',
    subtitle: 'Your idea, our craftsmanship.',
    type: 'custom',
    category: 'Custom Designs',
  },
];

export const WHY_CNCADOOR = [
  {
    title: 'QUALITY MATERIALS',
    description: 'We use only the best materials for long lasting durability.',
  },
  {
    title: 'EXPERT CRAFTSMANSHIP',
    description: 'Skilled craftsmen with years of experience and attention to detail.',
  },
  {
    title: 'CUSTOM SOLUTIONS',
    description: 'Every piece is customized to match your space and requirements.',
  },
  {
    title: 'DIRECT WORKSHOP PICKUP',
    description: 'Finished products are collected directly from our workshop. No delivery service is provided.',
  }
];

export const SPECIALTIES_DATA = [
  {
    id: 'spec-1',
    title: 'Carved Wooden Doors',
    description: 'Intricately detailed wooden doors designed to create a distinctive entrance with rich decorative carvings and balanced proportion.',
    imageUrl: 'https://images.unsplash.com/photo-1509644851169-2acc08aa25b5?auto=format&fit=crop&w=800&q=80',
    categoryTarget: 'Carved Doors' as const
  },
  {
    id: 'spec-2',
    title: 'Main Entrance Doors',
    description: 'Statement entrance doors crafted to complement traditional and contemporary architecture, engineered for grandeur and durability.',
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80',
    categoryTarget: 'Main Entrance Doors' as const
  },
  {
    id: 'spec-3',
    title: 'Custom Wood Carving',
    description: 'Custom carving created according to the customer\'s preferred design, pattern, sketches, and architectural requirements.',
    imageUrl: 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=800&q=80',
    categoryTarget: 'Custom Designs' as const
  },
  {
    id: 'spec-4',
    title: 'Decorative Wood Panels',
    description: 'Detailed wooden panels and architectural elements for homes, feature walls, sanctums, and luxury interiors.',
    imageUrl: 'https://images.unsplash.com/photo-1517581177682-a085bb7ffb15?auto=format&fit=crop&w=800&q=80',
    categoryTarget: 'Traditional Doors' as const
  }
];
