export interface BusinessConfig {
  name: string;
  subtitle: string;
  tagline: string;
  phones: string[];
  whatsapps: string[];
  email: string;
  address: string;
  locationDetails: string;
  openingHours: string;
  googleMapsUrl: string;
  whatsappMessage: string;
  announcement?: string;
  announcementActive?: boolean;
}

export type ProductType = 'ready-made' | 'customized';
export type ProductStatus = 'published' | 'draft' | 'hidden';

export type DoorCategory = 
  | 'All'
  | 'Traditional Doors'
  | 'Carved Doors'
  | 'Main Entrance Doors'
  | 'Temple-Inspired Designs'
  | 'Contemporary Wooden Doors'
  | 'Ready-made Doors'
  | 'Pooja Mandapams'
  | 'Carved Wall Panels'
  | 'Custom Designs';

export interface ProductItem {
  id: string;
  name: string;
  type: ProductType;
  category: string;
  status: ProductStatus;
  price?: string;
  originalPrice?: string;
  priceLabel?: string;
  inStockCount?: number;
  woodType: string;
  dimensionsNote: string;
  carvingStyle?: string;
  leadTime?: string;
  description: string;
  highlights: string[];
  imageUrl: string;
  additionalImages?: string[];
  featured?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DoorItem {
  id: string;
  name: string;
  category: DoorCategory;
  description: string;
  woodType?: string;
  dimensionsNote?: string;
  carvingStyle?: string;
  imageUrl: string;
  featured?: boolean;
}

export interface CarvingPattern {
  id: string;
  title: string;
  category: 'Traditional Carving' | 'Floral & Nature Motifs' | 'Geometric Patterns' | 'Custom Carving';
  description: string;
  details: string[];
  imageUrl: string;
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
  details: string;
}

export type GalleryFilter = 'ALL' | 'DOORS' | 'CARVING' | 'DETAILS' | 'COMPLETED WORK' | 'CUSTOM';

export interface GalleryItem {
  id: string;
  title: string;
  category: GalleryFilter;
  imageUrl: string;
  description?: string;
  woodType?: string;
  aspectRatio?: 'tall' | 'wide' | 'square';
}

export interface FeaturedProject {
  id: string;
  title: string;
  description: string;
  woodType?: string;
  location?: string;
  imageUrl: string;
  highlights?: string[];
}

export interface QuoteFormData {
  name: string;
  phoneNumber: string;
  email?: string;
  requirement: string;
  doorType: string;
  approximateSize?: string;
  woodPreference?: string;
  designDescription: string;
  referenceImageName?: string;
  referenceImageData?: string;
  preferredContactMethod: 'WhatsApp' | 'Phone';
  productType?: 'ready-made' | 'customized' | 'general';
  productId?: string;
}

export type EnquiryStatus = 
  | 'New'
  | 'In Review'
  | 'Contacted'
  | 'Quotation Sent'
  | 'Order Confirmed'
  | 'In Production'
  | 'Completed'
  | 'Cancelled';

export interface EnquiryRecord {
  id: string;
  customerName: string;
  phone: string;
  email?: string;
  type: 'custom_request' | 'ready_made_order' | 'quote_inquiry';
  productTitle: string;
  doorType: string;
  woodPreference?: string;
  approximateSize?: string;
  requirement: string;
  designDescription?: string;
  referenceImageName?: string;
  referenceImageData?: string;
  status: EnquiryStatus;
  preferredContactMethod: 'WhatsApp' | 'Phone';
  estimatedPrice?: string;
  adminNotes?: string;
  createdAt: string;
}

export interface SavedItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  type: 'door' | 'carving' | 'gallery' | 'project' | 'product';
  savedAt: string;
}

export interface UserQuoteRecord {
  id: string;
  date: string;
  doorType: string;
  requirement: string;
  approximateSize?: string;
  woodPreference?: string;
  status: 'Inquiry Submitted' | 'Workshop Review' | 'Estimate Ready';
}

export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  role?: string;
  avatar?: string;
  isAdminVerified?: boolean;
  savedItems: SavedItem[];
  quotes: UserQuoteRecord[];
}

export type PublicNavTab = 
  | 'home' 
  | 'our-doors' 
  | 'wood-carving' 
  | 'ready-made' 
  | 'custom-designs' 
  | 'gallery' 
  | 'about-us' 
  | 'contact' 
  | 'quote';

export type AdminTab = 
  | 'dashboard' 
  | 'add-product' 
  | 'products' 
  | 'orders' 
  | 'custom-requests' 
  | 'gallery' 
  | 'activity-log'
  | 'settings';

export type AdminDualViewMode = 'storefront' | 'admin' | 'split';

export type ActivityLogCategory = 'doors' | 'quotes' | 'users' | 'settings';

export type ActivityLogAction = 
  | 'door_created'
  | 'door_updated'
  | 'door_status_changed'
  | 'door_duplicated'
  | 'door_deleted'
  | 'quote_received'
  | 'quote_status_changed'
  | 'quote_notes_added'
  | 'quote_deleted'
  | 'user_login'
  | 'user_logout'
  | 'user_status_changed'
  | 'setting_updated'
  | 'admin_note';

export interface ActivityLogItem {
  id: string;
  timestamp: string; // ISO string
  category: ActivityLogCategory;
  action: ActivityLogAction;
  title: string;
  details: string;
  performedBy: string; // e.g. "adoorcnc@gmail.com (Owner)"
  targetId?: string;
  targetName?: string;
  severity?: 'info' | 'success' | 'warning' | 'neutral';
  meta?: {
    previousValue?: string;
    newValue?: string;
    badgeText?: string;
  };
}

