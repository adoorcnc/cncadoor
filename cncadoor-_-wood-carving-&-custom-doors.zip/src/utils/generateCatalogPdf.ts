import { jsPDF } from 'jspdf';
import { BUSINESS_CONFIG, DOORS_DATA } from '../data/config';
import { INITIAL_PRODUCTS } from '../data/products';

export interface CatalogPdfOptions {
  includePrices?: boolean;
  categoryFilter?: string;
}

/**
 * Generates and downloads a branded PDF catalog & brochure
 * for CNCADOOR solid wood doors and architectural CNC carvings.
 */
export const generateCatalogPdf = async (options: CatalogPdfOptions = {}): Promise<void> => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 14;
  const contentWidth = pageWidth - margin * 2; // 182 mm
  let currentY = margin;

  // Colors
  const primaryBrown = [43, 24, 16]; // #2B1810
  const teakGold = [168, 118, 62];    // #A8763E
  const darkTeak = [141, 95, 45];     // #8D5F2D
  const textDark = [35, 24, 18];      // #231812
  const textMuted = [122, 110, 99];   // #7A6E63
  const bgCream = [250, 247, 242];    // #FAF7F2
  const borderCream = [226, 217, 200];// #E2D9C8

  // Helper to add running page header & footer
  const addPageDecorations = (pageNum: number, totalPages: number) => {
    // Top running header line
    doc.setDrawColor(borderCream[0], borderCream[1], borderCream[2]);
    doc.setLineWidth(0.4);
    doc.line(margin, 12, pageWidth - margin, 12);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(teakGold[0], teakGold[1], teakGold[2]);
    doc.text('CNCADOOR', margin, 9);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    doc.text('Solid Wooden Doors & CNC Architectural Carvings Catalog', margin + 22, 9);
    doc.text(`Adoor & Kochi, Kerala | +91 ${BUSINESS_CONFIG.whatsapps[0]}`, pageWidth - margin, 9, { align: 'right' });

    // Bottom running footer
    doc.setDrawColor(borderCream[0], borderCream[1], borderCream[2]);
    doc.line(margin, pageHeight - 12, pageWidth - margin, pageHeight - 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    doc.text('Workshop Collection Only • No Delivery Service • Loading Assistance at Adoor Workshop', margin, pageHeight - 7.5);

    doc.setFont('helvetica', 'bold');
    doc.text(`Page ${pageNum} of ${totalPages}`, pageWidth - margin, pageHeight - 7.5, { align: 'right' });
  };

  const checkPageBreak = (neededHeight: number): void => {
    if (currentY + neededHeight > pageHeight - 18) {
      doc.addPage();
      currentY = 18;
    }
  };

  // ==========================================
  // PAGE 1: COVER & WORKSHOP DIRECTORY
  // ==========================================

  // Hero Header Banner
  doc.setFillColor(primaryBrown[0], primaryBrown[1], primaryBrown[2]);
  doc.roundedRect(margin, currentY, contentWidth, 38, 2, 2, 'F');

  // Gold accent bar
  doc.setFillColor(teakGold[0], teakGold[1], teakGold[2]);
  doc.rect(margin, currentY, 3.5, 38, 'F');

  // Brand Name
  doc.setFont('times', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(255, 255, 255);
  doc.text('CNCADOOR', margin + 8, currentY + 13);

  // Subtitle
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(teakGold[0], teakGold[1], teakGold[2]);
  doc.text('SOLID WOODEN DOORS & PRECISION ARCHITECTURAL WOOD CARVINGS', margin + 8, currentY + 20);

  // Tagline / Location
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(230, 225, 218);
  doc.text('Official Collection Catalog & Architectural Specification Guide • Kerala, India', margin + 8, currentY + 27);
  doc.text(`Phone: +91 ${BUSINESS_CONFIG.phones.join(' / +91 ')}  •  Email: ${BUSINESS_CONFIG.email}`, margin + 8, currentY + 33);

  currentY += 44;

  // Workshop Pickup Notice (Mandatory user requirement highlighted prominently)
  doc.setFillColor(bgCream[0], bgCream[1], bgCream[2]);
  doc.setDrawColor(teakGold[0], teakGold[1], teakGold[2]);
  doc.setLineWidth(0.6);
  doc.roundedRect(margin, currentY, contentWidth, 18, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(darkTeak[0], darkTeak[1], darkTeak[2]);
  doc.text('IMPORTANT WORKSHOP POLICY: DIRECT CUSTOMER PICKUP ONLY (NO DELIVERY)', margin + 4, currentY + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  const pickupNotice = 'All doors and custom carvings are manufactured for direct customer collection at our workshop in Adoor, Pathanamthitta, Kerala. Customers arrange their own transport; our workshop team provides protective wrap packaging and heavy vehicle loading assistance.';
  const pickupLines = doc.splitTextToSize(pickupNotice, contentWidth - 8);
  doc.text(pickupLines, margin + 4, currentY + 11);

  currentY += 24;

  // Catalog Overview Box
  doc.setFont('times', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(primaryBrown[0], primaryBrown[1], primaryBrown[2]);
  doc.text('The Door Collections', margin, currentY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
  doc.text('Explore our curated portfolio of hand-detailed CNC carved doors, pooja room sanctum shutters, and contemporary entrance pieces.', margin, currentY + 5);

  currentY += 10;

  // Filter items if requested
  const doorsToRender = options.categoryFilter && options.categoryFilter !== 'All'
    ? DOORS_DATA.filter(d => d.category === options.categoryFilter)
    : DOORS_DATA;

  // Render each door in an architectural spec card
  doorsToRender.forEach((door, index) => {
    checkPageBreak(38);

    // Card background
    doc.setFillColor(bgCream[0], bgCream[1], bgCream[2]);
    doc.setDrawColor(borderCream[0], borderCream[1], borderCream[2]);
    doc.setLineWidth(0.3);
    doc.roundedRect(margin, currentY, contentWidth, 34, 1.5, 1.5, 'FD');

    // Number tag
    doc.setFillColor(teakGold[0], teakGold[1], teakGold[2]);
    doc.roundedRect(margin + 3, currentY + 3, 14, 5.5, 1, 1, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(255, 255, 255);
    doc.text(`#${(index + 1).toString().padStart(2, '0')}`, margin + 10, currentY + 7, { align: 'center' });

    // Category Pill
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(teakGold[0], teakGold[1], teakGold[2]);
    doc.text(door.category.toUpperCase(), margin + 20, currentY + 7);

    // Door Title
    doc.setFont('times', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(door.name, margin + 4, currentY + 14);

    // Description
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    const descLines = doc.splitTextToSize(door.description, contentWidth - 8);
    doc.text(descLines.slice(0, 2), margin + 4, currentY + 19);

    // Divider
    doc.setDrawColor(borderCream[0], borderCream[1], borderCream[2]);
    doc.setLineWidth(0.2);
    doc.line(margin + 4, currentY + 25, margin + contentWidth - 4, currentY + 25);

    // Specs row
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(darkTeak[0], darkTeak[1], darkTeak[2]);
    doc.text('Timber:', margin + 4, currentY + 30);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(door.woodType, margin + 16, currentY + 30);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(darkTeak[0], darkTeak[1], darkTeak[2]);
    doc.text('Carving Style:', margin + 95, currentY + 30);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(door.carvingStyle, margin + 115, currentY + 30);

    currentY += 37;
  });

  // ==========================================
  // IN-STOCK READY-MADE PRODUCTS SECTION
  // ==========================================
  checkPageBreak(50);

  doc.setFont('times', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(primaryBrown[0], primaryBrown[1], primaryBrown[2]);
  doc.text('In-Stock Ready-Made Inventory (Direct Workshop Pickup)', margin, currentY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
  doc.text('Pre-crafted and kiln-seasoned units available immediately for pickup at our Adoor workshop.', margin, currentY + 5);

  currentY += 10;

  INITIAL_PRODUCTS.forEach((prod) => {
    checkPageBreak(30);

    doc.setFillColor(255, 255, 255);
    doc.setDrawColor(borderCream[0], borderCream[1], borderCream[2]);
    doc.setLineWidth(0.3);
    doc.roundedRect(margin, currentY, contentWidth, 26, 1.5, 1.5, 'FD');

    // Title & Badge
    doc.setFont('times', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(prod.name, margin + 4, currentY + 7);

    // Price tag
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(darkTeak[0], darkTeak[1], darkTeak[2]);
    doc.text(prod.price, pageWidth - margin - 4, currentY + 7, { align: 'right' });

    // Stock & Availability
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(16, 130, 60); // Green
    doc.text(`In Stock: ${prod.inStockCount || 1} unit(s) • ${prod.leadTime || 'Immediate Pickup'}`, margin + 4, currentY + 12);

    // Specs
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(`Timber: ${prod.woodType}   |   Dimensions: ${prod.dimensionsNote}`, margin + 4, currentY + 17);
    doc.text(`Carving: ${prod.carvingStyle}   |   Collection: Adoor Workshop`, margin + 4, currentY + 22);

    currentY += 29;
  });

  // ==========================================
  // TIMBER & CRAFTSMANSHIP SPECIFICATION GUIDE
  // ==========================================
  checkPageBreak(75);

  doc.setFillColor(primaryBrown[0], primaryBrown[1], primaryBrown[2]);
  doc.roundedRect(margin, currentY, contentWidth, 68, 2, 2, 'F');

  doc.setFont('times', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(255, 255, 255);
  doc.text('CNCADOOR Timber Selection & Technical Standards', margin + 6, currentY + 9);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(230, 222, 214);
  doc.text('Every door leaf is constructed with anti-warp engineering and kiln-seasoned Kerala timber.', margin + 6, currentY + 15);

  // 3 Timber Columns
  const colW = (contentWidth - 16) / 3;
  
  // Col 1: Teak Wood
  doc.setFillColor(35, 18, 12);
  doc.roundedRect(margin + 4, currentY + 20, colW, 42, 1, 1, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(teakGold[0], teakGold[1], teakGold[2]);
  doc.text('Grade-A Teak Wood', margin + 7, currentY + 26);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(240, 236, 230);
  const teakText = '• 100% Solid Kiln-Seasoned\n• Natural insect & weather resistance\n• Rich golden-brown grain patina\n• Standard 1.5" - 2.0" entrance depth';
  doc.text(teakText, margin + 7, currentY + 31);

  // Col 2: Heritage Carving
  doc.setFillColor(35, 18, 12);
  doc.roundedRect(margin + 4 + colW + 4, currentY + 20, colW, 42, 1, 1, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(teakGold[0], teakGold[1], teakGold[2]);
  doc.text('CNC + Hand Craftsmanship', margin + 7 + colW + 4, currentY + 26);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(240, 236, 230);
  const cncText = '• 0.05mm high-precision CNC routers\n• Hand-sculpted relief feathering\n• 25mm to 40mm relief carve depth\n• Dual-side or single-side designs';
  doc.text(cncText, margin + 7 + colW + 4, currentY + 31);

  // Col 3: Bespoke Commission
  doc.setFillColor(35, 18, 12);
  doc.roundedRect(margin + 4 + (colW + 4) * 2, currentY + 20, colW, 42, 1, 1, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(teakGold[0], teakGold[1], teakGold[2]);
  doc.text('Custom Architectural Work', margin + 7 + (colW + 4) * 2, currentY + 26);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(240, 236, 230);
  const customText = '• CAD & architectural drawings\n• Traditional Temple Sanctums\n• Mandapam pooja doors with bells\n• Bespoke family crests & motifs';
  doc.text(customText, margin + 7 + (colW + 4) * 2, currentY + 31);

  currentY += 75;

  // How to Order & Inquire
  checkPageBreak(38);
  doc.setFillColor(bgCream[0], bgCream[1], bgCream[2]);
  doc.setDrawColor(borderCream[0], borderCream[1], borderCream[2]);
  doc.roundedRect(margin, currentY, contentWidth, 30, 2, 2, 'FD');

  doc.setFont('times', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryBrown[0], primaryBrown[1], primaryBrown[2]);
  doc.text('How to Order & Request a Sizing Quote', margin + 6, currentY + 7);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  const steps = [
    '1. Share Doorway Measurements & Chosen Design: Contact us via WhatsApp or Phone.',
    '2. Timber & Carving Approval: Review timber grain selection and custom carving drawings.',
    '3. Precision Production & Finishing: Seasoned wood preparation, CNC relief routing, and hand finishing.',
    '4. Workshop Inspection & Pickup: Inspect your finished doors directly at our Adoor workshop.'
  ];
  steps.forEach((st, i) => {
    doc.text(st, margin + 6, currentY + 13 + i * 4);
  });

  // Apply running header and footer to ALL pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    addPageDecorations(i, totalPages);
  }

  // Download PDF
  const filename = `CNCADOOR-Door-Collections-Catalog-${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(filename);
};
