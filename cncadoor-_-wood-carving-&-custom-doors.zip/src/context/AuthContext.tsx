import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile, SavedItem, UserQuoteRecord, QuoteFormData } from '../types';
import { useStore } from './StoreContext';

interface AuthContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isAuthModalOpen: boolean;
  authPromptReason: string | null;
  authModalDefaultMode: 'client' | 'owner';
  pendingActionItem: SavedItem | null;
  isShortlistDrawerOpen: boolean;
  openAuthModal: (reason?: string, itemToSave?: SavedItem, onComplete?: () => void, mode?: 'client' | 'owner') => void;
  closeAuthModal: () => void;
  openShortlistDrawer: () => void;
  closeShortlistDrawer: () => void;
  login: (userData: { name: string; email?: string; phone?: string; role?: string; password?: string }) => { success: boolean; error?: string };
  logout: () => void;
  toggleSaveItem: (item: SavedItem, promptIfGuest?: boolean) => boolean;
  isItemSaved: (itemId: string) => boolean;
  addQuoteRecord: (quoteData: QuoteFormData) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEY = 'cncadoor_user_session_v1';
const GUEST_SAVED_KEY = 'cncadoor_guest_saved_v1';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { addActivityLog } = useStore();
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [guestSavedItems, setGuestSavedItems] = useState<SavedItem[]>(() => {
    try {
      const stored = localStorage.getItem(GUEST_SAVED_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authPromptReason, setAuthPromptReason] = useState<string | null>(null);
  const [authModalDefaultMode, setAuthModalDefaultMode] = useState<'client' | 'owner'>('client');
  const [pendingActionItem, setPendingActionItem] = useState<SavedItem | null>(null);
  const [pendingCallback, setPendingCallback] = useState<(() => void) | null>(null);
  const [isShortlistDrawerOpen, setIsShortlistDrawerOpen] = useState(false);

  // Sync session
  useEffect(() => {
    try {
      if (user) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch (e) {
      console.error('Failed to sync auth state to localStorage', e);
    }
  }, [user]);

  useEffect(() => {
    try {
      localStorage.setItem(GUEST_SAVED_KEY, JSON.stringify(guestSavedItems));
    } catch (e) {
      console.error('Failed to sync guest items', e);
    }
  }, [guestSavedItems]);

  const openAuthModal = (
    reason?: string, 
    itemToSave?: SavedItem, 
    onComplete?: () => void,
    mode?: 'client' | 'owner'
  ) => {
    setAuthPromptReason(reason || 'Sign in to save custom doors, track quotes, and receive prioritized craftsmanship assistance.');
    if (mode) {
      setAuthModalDefaultMode(mode);
    } else {
      setAuthModalDefaultMode('client');
    }
    if (itemToSave) {
      setPendingActionItem(itemToSave);
    }
    if (onComplete) {
      setPendingCallback(() => onComplete);
    }
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
    setAuthPromptReason(null);
    setPendingActionItem(null);
    setPendingCallback(null);
  };

  const openShortlistDrawer = () => setIsShortlistDrawerOpen(true);
  const closeShortlistDrawer = () => setIsShortlistDrawerOpen(false);

  const login = (userData: { 
    name: string; 
    email?: string; 
    phone?: string; 
    role?: string; 
    password?: string;
  }): { success: boolean; error?: string } => {
    const normalizedEmail = (userData.email || '').trim().toLowerCase();
    const isAdoorEmail = normalizedEmail === 'adoorcnc@gmail.com';

    let isAdminVerified = false;

    // For adoorcnc@gmail.com: password is required!
    if (isAdoorEmail) {
      const enteredPass = (userData.password || '').trim();
      const customPass = typeof window !== 'undefined' ? localStorage.getItem('cncadoor_admin_password') : null;
      const validPasswords = ['adoorcnc@786'];
      if (customPass) {
        validPasswords.push(customPass.trim());
      }

      if (!enteredPass) {
        return {
          success: false,
          error: 'Password is required for admin authentication.',
        };
      }

      if (!validPasswords.includes(enteredPass)) {
        return {
          success: false,
          error: 'Incorrect password for admin account. Please try again.',
        };
      }

      isAdminVerified = true;
    }

    // Combine guest items into user profile
    const existingSaved = user?.savedItems || [];
    const mergedSaved = [...existingSaved];

    guestSavedItems.forEach((gItem) => {
      if (!mergedSaved.some((m) => m.id === gItem.id)) {
        mergedSaved.push(gItem);
      }
    });

    if (pendingActionItem && !mergedSaved.some((m) => m.id === pendingActionItem.id)) {
      mergedSaved.push(pendingActionItem);
    }

    const assignedRole = isAdminVerified 
      ? 'Owner / Admin' 
      : (userData.role || 'Homeowner / Builder');

    const newUser: UserProfile = {
      id: user?.id || 'usr_' + Date.now().toString(36),
      name: userData.name.trim() || (isAdminVerified ? 'Workshop Owner' : 'Client'),
      email: userData.email || (user?.email ?? ''),
      phone: userData.phone || (user?.phone ?? ''),
      role: assignedRole,
      isAdminVerified,
      savedItems: mergedSaved,
      quotes: user?.quotes || [],
    };

    setUser(newUser);
    setGuestSavedItems([]);
    setIsAuthModalOpen(false);

    if (isAdminVerified) {
      addActivityLog({
        category: 'users',
        action: 'user_login',
        title: 'Owner Admin Session Authenticated',
        details: 'Verified owner login for adoorcnc@gmail.com with Master Admin rights.',
        performedBy: 'adoorcnc@gmail.com (Owner)',
        targetId: newUser.id,
        targetName: 'adoorcnc@gmail.com',
        severity: 'success',
        meta: {
          newValue: 'Role: Owner / Admin',
          badgeText: 'Admin Logged In'
        }
      });
    } else {
      addActivityLog({
        category: 'users',
        action: 'user_login',
        title: `Customer Sign-In: ${newUser.name}`,
        details: `Customer session initialized (${newUser.email || newUser.phone || 'Phone Session'}). Shortlist: ${newUser.savedItems.length} items.`,
        performedBy: newUser.email || newUser.name,
        targetId: newUser.id,
        targetName: newUser.name,
        severity: 'info',
        meta: {
          newValue: newUser.role,
          badgeText: 'Customer Sign-In'
        }
      });
    }

    if (pendingCallback) {
      pendingCallback();
    }
    setPendingActionItem(null);
    setPendingCallback(null);

    return { success: true };
  };

  const isAdmin = Boolean(
    user &&
    user.email?.trim().toLowerCase() === 'adoorcnc@gmail.com' &&
    user.isAdminVerified === true
  );

  const logout = () => {
    if (user) {
      addActivityLog({
        category: 'users',
        action: 'user_logout',
        title: `${user.isAdminVerified ? 'Admin' : 'User'} Signed Out: ${user.name}`,
        details: `${user.isAdminVerified ? 'Workshop owner' : 'Customer'} session terminated safely.`,
        performedBy: user.email || user.name,
        targetId: user.id,
        targetName: user.name,
        severity: 'neutral',
        meta: {
          badgeText: 'Signed Out'
        }
      });
    }
    setUser(null);
  };

  const isItemSaved = (itemId: string): boolean => {
    if (user) {
      return user.savedItems.some((item) => item.id === itemId);
    }
    return guestSavedItems.some((item) => item.id === itemId);
  };

  const toggleSaveItem = (item: SavedItem, promptIfGuest = false): boolean => {
    if (user) {
      const exists = user.savedItems.some((i) => i.id === item.id);
      const updated = exists
        ? user.savedItems.filter((i) => i.id !== item.id)
        : [...user.savedItems, { ...item, savedAt: new Date().toISOString() }];
      
      setUser({ ...user, savedItems: updated });
      return !exists;
    } else {
      // Guest mode
      const exists = guestSavedItems.some((i) => i.id === item.id);
      if (!exists) {
        setGuestSavedItems([...guestSavedItems, { ...item, savedAt: new Date().toISOString() }]);
        if (promptIfGuest) {
          openAuthModal(`You saved "${item.title}". Sign in to access your shortlist across devices and autofill your quote inquiries!`, item);
        }
        return true;
      } else {
        setGuestSavedItems(guestSavedItems.filter((i) => i.id !== item.id));
        return false;
      }
    }
  };

  const addQuoteRecord = (quoteData: QuoteFormData) => {
    const record: UserQuoteRecord = {
      id: 'QT-' + Math.floor(100000 + Math.random() * 900000),
      date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
      doorType: quoteData.doorType,
      requirement: quoteData.requirement || `${quoteData.doorType} Custom Carved Order`,
      approximateSize: quoteData.approximateSize,
      woodPreference: quoteData.woodPreference,
      status: 'Inquiry Submitted',
    };

    if (user) {
      setUser({
        ...user,
        phone: user.phone || quoteData.phoneNumber,
        email: user.email || quoteData.email,
        quotes: [record, ...user.quotes],
      });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isAdmin,
        isAuthModalOpen,
        authPromptReason,
        authModalDefaultMode,
        pendingActionItem,
        isShortlistDrawerOpen,
        openAuthModal,
        closeAuthModal,
        openShortlistDrawer,
        closeShortlistDrawer,
        login,
        logout,
        toggleSaveItem,
        isItemSaved,
        addQuoteRecord,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
