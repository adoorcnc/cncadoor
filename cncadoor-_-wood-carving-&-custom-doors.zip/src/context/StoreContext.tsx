import React, { createContext, useContext, useState, useEffect } from 'react';
import { ProductItem, EnquiryRecord, GalleryItem, BusinessConfig, ProductStatus, AdminTab, AdminDualViewMode, ActivityLogItem } from '../types';
import { INITIAL_PRODUCTS, INITIAL_ENQUIRIES } from '../data/products';
import { GALLERY_ITEMS, BUSINESS_CONFIG } from '../data/config';
import { INITIAL_ACTIVITY_LOGS } from '../data/initialActivityLogs';

interface StoreContextType {
  // Products
  products: ProductItem[];
  publishedProducts: ProductItem[];
  readyMadeProducts: ProductItem[];
  customizedProducts: ProductItem[];
  addProduct: (product: Omit<ProductItem, 'id' | 'createdAt' | 'updatedAt'>) => ProductItem;
  updateProduct: (id: string, updates: Partial<ProductItem>) => void;
  deleteProduct: (id: string) => void;
  toggleProductStatus: (id: string, status: ProductStatus) => void;
  duplicateProduct: (id: string) => void;

  // Enquiries & Orders
  enquiries: EnquiryRecord[];
  addEnquiry: (enquiry: Omit<EnquiryRecord, 'id' | 'createdAt'>) => EnquiryRecord;
  updateEnquiryStatus: (id: string, status: EnquiryRecord['status'], notes?: string) => void;
  deleteEnquiry: (id: string) => void;

  // Gallery
  galleryItems: GalleryItem[];
  addGalleryItem: (item: Omit<GalleryItem, 'id'>) => void;
  deleteGalleryItem: (id: string) => void;

  // Business Config
  businessConfig: BusinessConfig;
  updateBusinessConfig: (updates: Partial<BusinessConfig>) => void;

  // Admin Activity Log
  activityLogs: ActivityLogItem[];
  addActivityLog: (log: Omit<ActivityLogItem, 'id' | 'timestamp'>) => ActivityLogItem;
  clearActivityLogs: () => void;

  // Admin View State
  isAdminMode: boolean;
  setIsAdminMode: (enabled: boolean) => void;
  adminDualViewMode: AdminDualViewMode;
  setAdminDualViewMode: (mode: AdminDualViewMode) => void;
  activeAdminTab: AdminTab;
  setActiveAdminTab: (tab: AdminTab) => void;
  editingProduct: ProductItem | null;
  setEditingProduct: (product: ProductItem | null) => void;
  draftProductInCreation: Partial<ProductItem> | null;
  setDraftProductInCreation: (draft: Partial<ProductItem> | null) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const PRODUCTS_STORAGE_KEY = 'cncadoor_products_v2';
const ENQUIRIES_STORAGE_KEY = 'cncadoor_enquiries_v2';
const GALLERY_STORAGE_KEY = 'cncadoor_gallery_v2';
const CONFIG_STORAGE_KEY = 'cncadoor_config_v2';
const ADMIN_MODE_KEY = 'cncadoor_admin_mode_v2';
const DUAL_VIEW_MODE_KEY = 'cncadoor_dual_view_mode_v2';
const ACTIVITY_LOGS_STORAGE_KEY = 'cncadoor_activity_logs_v2';

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Products State
  const [products, setProducts] = useState<ProductItem[]>(() => {
    try {
      const saved = localStorage.getItem(PRODUCTS_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_PRODUCTS;
  });

  // 2. Enquiries State
  const [enquiries, setEnquiries] = useState<EnquiryRecord[]>(() => {
    try {
      const saved = localStorage.getItem(ENQUIRIES_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_ENQUIRIES;
  });

  // 3. Gallery State
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(() => {
    try {
      const saved = localStorage.getItem(GALLERY_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return GALLERY_ITEMS;
  });

  // 4. Business Config State
  const [businessConfig, setBusinessConfig] = useState<BusinessConfig>(() => {
    try {
      const saved = localStorage.getItem(CONFIG_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      ...BUSINESS_CONFIG,
      announcement: '🌟 Direct Workshop Pricing in Adoor: Custom CNC Wood Carving & Pre-Seasoned Teak Doors',
      announcementActive: true
    };
  });

  // 5. Admin Navigation State (Dual View: Storefront / Admin / Split Both Sides)
  const [adminDualViewMode, setAdminDualViewModeState] = useState<AdminDualViewMode>(() => {
    try {
      const savedMode = localStorage.getItem(DUAL_VIEW_MODE_KEY);
      if (savedMode === 'storefront' || savedMode === 'admin' || savedMode === 'split') {
        return savedMode;
      }
      const savedLegacy = localStorage.getItem(ADMIN_MODE_KEY);
      return savedLegacy === 'true' ? 'admin' : 'storefront';
    } catch {
      return 'storefront';
    }
  });

  const [isAdminMode, setIsAdminModeState] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(ADMIN_MODE_KEY);
      return saved === 'true';
    } catch {
      return false;
    }
  });

  // 6. Admin Activity Log State
  const [activityLogs, setActivityLogs] = useState<ActivityLogItem[]>(() => {
    try {
      const saved = localStorage.getItem(ACTIVITY_LOGS_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_ACTIVITY_LOGS;
  });

  const setAdminDualViewMode = (mode: AdminDualViewMode) => {
    setAdminDualViewModeState(mode);
    setIsAdminModeState(mode === 'admin' || mode === 'split');
    try {
      localStorage.setItem(DUAL_VIEW_MODE_KEY, mode);
      localStorage.setItem(ADMIN_MODE_KEY, String(mode === 'admin' || mode === 'split'));
    } catch {
      // ignore
    }
  };

  const setIsAdminMode = (enabled: boolean) => {
    setIsAdminModeState(enabled);
    const newMode: AdminDualViewMode = enabled ? 'admin' : 'storefront';
    setAdminDualViewModeState(newMode);
    try {
      localStorage.setItem(ADMIN_MODE_KEY, String(enabled));
      localStorage.setItem(DUAL_VIEW_MODE_KEY, newMode);
    } catch {
      // ignore
    }
  };

  const [activeAdminTab, setActiveAdminTab] = useState<AdminTab>('dashboard');
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);
  const [draftProductInCreation, setDraftProductInCreation] = useState<Partial<ProductItem> | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));
    } catch {
      // ignore
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(ENQUIRIES_STORAGE_KEY, JSON.stringify(enquiries));
    } catch {
      // ignore
    }
  }, [enquiries]);

  useEffect(() => {
    try {
      localStorage.setItem(GALLERY_STORAGE_KEY, JSON.stringify(galleryItems));
    } catch {
      // ignore
    }
  }, [galleryItems]);

  useEffect(() => {
    try {
      localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(businessConfig));
    } catch {
      // ignore
    }
  }, [businessConfig]);

  useEffect(() => {
    try {
      localStorage.setItem(ADMIN_MODE_KEY, String(isAdminMode));
    } catch {
      // ignore
    }
  }, [isAdminMode]);

  useEffect(() => {
    try {
      localStorage.setItem(ACTIVITY_LOGS_STORAGE_KEY, JSON.stringify(activityLogs));
    } catch {
      // ignore
    }
  }, [activityLogs]);

  // Activity Log Helper
  const addActivityLog = (logData: Omit<ActivityLogItem, 'id' | 'timestamp'>): ActivityLogItem => {
    const newLog: ActivityLogItem = {
      ...logData,
      id: `act-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString()
    };
    setActivityLogs(prev => [newLog, ...prev]);
    return newLog;
  };

  const clearActivityLogs = () => {
    setActivityLogs([]);
    try {
      localStorage.removeItem(ACTIVITY_LOGS_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  // Derived Products
  const publishedProducts = products.filter(p => p.status === 'published');
  const readyMadeProducts = publishedProducts.filter(p => p.type === 'ready-made');
  const customizedProducts = publishedProducts.filter(p => p.type === 'customized');

  // Product Actions
  const addProduct = (newProd: Omit<ProductItem, 'id' | 'createdAt' | 'updatedAt'>): ProductItem => {
    const item: ProductItem = {
      ...newProd,
      id: `prod-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setProducts(prev => [item, ...prev]);
    addActivityLog({
      category: 'doors',
      action: 'door_created',
      title: `Door Catalogued: ${item.name}`,
      details: `Added new ${item.type === 'ready-made' ? 'Ready-Made Stock' : 'Custom Model'} (${item.category}). Material: ${item.woodType || 'Solid Teak'}, Price: ${item.price || 'Quote on Request'}.`,
      performedBy: 'adoorcnc@gmail.com',
      targetId: item.id,
      targetName: item.name,
      severity: 'success',
      meta: {
        newValue: item.status,
        badgeText: item.type === 'ready-made' ? 'Ready-Made' : 'Custom Door'
      }
    });
    return item;
  };

  const updateProduct = (id: string, updates: Partial<ProductItem>) => {
    setProducts(prev => {
      const existing = prev.find(p => p.id === id);
      const prodName = updates.name || existing?.name || 'Door Item';
      if (!updates.status || Object.keys(updates).length > 1) {
        addActivityLog({
          category: 'doors',
          action: 'door_updated',
          title: `Door Updated: ${prodName}`,
          details: `Modified door specifications, pricing, dimensions, or images.`,
          performedBy: 'adoorcnc@gmail.com',
          targetId: id,
          targetName: prodName,
          severity: 'info',
          meta: {
            badgeText: 'Product Updated'
          }
        });
      }
      return prev.map(p => (p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p));
    });
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => {
      const existing = prev.find(p => p.id === id);
      const prodName = existing?.name || id;
      addActivityLog({
        category: 'doors',
        action: 'door_deleted',
        title: `Door Removed: ${prodName}`,
        details: `Item removed from workshop catalog and active inventory.`,
        performedBy: 'adoorcnc@gmail.com',
        targetId: id,
        targetName: prodName,
        severity: 'warning',
        meta: {
          badgeText: 'Removed'
        }
      });
      return prev.filter(p => p.id !== id);
    });
  };

  const toggleProductStatus = (id: string, status: ProductStatus) => {
    const existing = products.find(p => p.id === id);
    const prodName = existing?.name || 'Door Item';
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, status, updatedAt: new Date().toISOString() } : p))
    );
    addActivityLog({
      category: 'doors',
      action: 'door_status_changed',
      title: `Door Status Changed: ${prodName}`,
      details: `Visibility changed from "${existing?.status || 'unknown'}" to "${status}".`,
      performedBy: 'adoorcnc@gmail.com',
      targetId: id,
      targetName: prodName,
      severity: status === 'published' ? 'success' : 'warning',
      meta: {
        previousValue: existing?.status,
        newValue: status,
        badgeText: status === 'published' ? 'Live on Storefront' : 'Draft / Hidden'
      }
    });
  };

  const duplicateProduct = (id: string) => {
    const existing = products.find(p => p.id === id);
    if (!existing) return;
    const duplicated: ProductItem = {
      ...existing,
      id: `prod-${Date.now()}`,
      name: `${existing.name} (Copy)`,
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setProducts(prev => [duplicated, ...prev]);
    addActivityLog({
      category: 'doors',
      action: 'door_duplicated',
      title: `Door Duplicated: ${existing.name}`,
      details: `Cloned door entry into draft copy "${duplicated.name}" for customization.`,
      performedBy: 'adoorcnc@gmail.com',
      targetId: duplicated.id,
      targetName: duplicated.name,
      severity: 'info',
      meta: {
        previousValue: existing.id,
        newValue: duplicated.id,
        badgeText: 'Draft Copy'
      }
    });
  };

  // Enquiry Actions
  const addEnquiry = (enquiryData: Omit<EnquiryRecord, 'id' | 'createdAt'>): EnquiryRecord => {
    const record: EnquiryRecord = {
      ...enquiryData,
      id: `enq-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setEnquiries(prev => [record, ...prev]);
    addActivityLog({
      category: 'quotes',
      action: 'quote_received',
      title: `New Quote Request: ${record.customerName}`,
      details: `Inquiry for "${record.productTitle}" (${record.woodPreference || 'Teak Wood'}). Phone: ${record.phone}`,
      performedBy: 'Public Website / Customer Lead',
      targetId: record.id,
      targetName: record.customerName,
      severity: 'warning',
      meta: {
        newValue: 'Status: New',
        badgeText: record.type === 'ready_made_order' ? 'Direct Order' : 'Custom Quote'
      }
    });
    return record;
  };

  const updateEnquiryStatus = (id: string, status: EnquiryRecord['status'], notes?: string) => {
    const existing = enquiries.find(e => e.id === id);
    const custName = existing?.customerName || 'Customer';
    setEnquiries(prev =>
      prev.map(e => (e.id === id ? { ...e, status, adminNotes: notes !== undefined ? notes : e.adminNotes } : e))
    );
    addActivityLog({
      category: 'quotes',
      action: notes ? 'quote_notes_added' : 'quote_status_changed',
      title: `Quote #${id.replace('enq-', '')} Updated (${custName})`,
      details: `Status set to "${status}". ${notes ? `Admin note added: "${notes}"` : ''}`,
      performedBy: 'adoorcnc@gmail.com',
      targetId: id,
      targetName: custName,
      severity: status === 'Completed' ? 'success' : 'info',
      meta: {
        previousValue: existing?.status,
        newValue: status,
        badgeText: status
      }
    });
  };

  const deleteEnquiry = (id: string) => {
    const existing = enquiries.find(e => e.id === id);
    setEnquiries(prev => prev.filter(e => e.id !== id));
    addActivityLog({
      category: 'quotes',
      action: 'quote_deleted',
      title: `Quote #${id.replace('enq-', '')} Archived`,
      details: `Enquiry record for ${existing?.customerName || id} removed from active view.`,
      performedBy: 'adoorcnc@gmail.com',
      targetId: id,
      targetName: existing?.customerName,
      severity: 'warning',
      meta: {
        badgeText: 'Archived'
      }
    });
  };

  // Gallery Actions
  const addGalleryItem = (itemData: Omit<GalleryItem, 'id'>) => {
    const newItem: GalleryItem = {
      ...itemData,
      id: `g-${Date.now()}`
    };
    setGalleryItems(prev => [newItem, ...prev]);
    addActivityLog({
      category: 'doors',
      action: 'door_created',
      title: `Gallery Photo Uploaded: ${newItem.title}`,
      details: `Added new workshop photo to "${newItem.category}" gallery section.`,
      performedBy: 'adoorcnc@gmail.com',
      targetId: newItem.id,
      targetName: newItem.title,
      severity: 'info',
      meta: {
        badgeText: 'Gallery Add'
      }
    });
  };

  const deleteGalleryItem = (id: string) => {
    const existing = galleryItems.find(item => item.id === id);
    setGalleryItems(prev => prev.filter(item => item.id !== id));
    addActivityLog({
      category: 'doors',
      action: 'door_deleted',
      title: `Gallery Photo Deleted: ${existing?.title || id}`,
      details: `Removed photo from gallery showcase.`,
      performedBy: 'adoorcnc@gmail.com',
      targetId: id,
      severity: 'warning',
      meta: {
        badgeText: 'Gallery Remove'
      }
    });
  };

  // Config Actions
  const updateBusinessConfig = (updates: Partial<BusinessConfig>) => {
    setBusinessConfig(prev => ({ ...prev, ...updates }));
    addActivityLog({
      category: 'settings',
      action: 'setting_updated',
      title: 'Workshop Settings Updated',
      details: `Updated business profile, workshop phone numbers, or broadcast announcement.`,
      performedBy: 'adoorcnc@gmail.com',
      targetId: 'config_workshop',
      targetName: 'Business Profile',
      severity: 'neutral',
      meta: {
        badgeText: 'Settings Sync'
      }
    });
  };

  return (
    <StoreContext.Provider
      value={{
        products,
        publishedProducts,
        readyMadeProducts,
        customizedProducts,
        addProduct,
        updateProduct,
        deleteProduct,
        toggleProductStatus,
        duplicateProduct,
        enquiries,
        addEnquiry,
        updateEnquiryStatus,
        deleteEnquiry,
        galleryItems,
        addGalleryItem,
        deleteGalleryItem,
        businessConfig,
        updateBusinessConfig,
        activityLogs,
        addActivityLog,
        clearActivityLogs,
        isAdminMode,
        setIsAdminMode,
        adminDualViewMode,
        setAdminDualViewMode,
        activeAdminTab,
        setActiveAdminTab,
        editingProduct,
        setEditingProduct,
        draftProductInCreation,
        setDraftProductInCreation
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
