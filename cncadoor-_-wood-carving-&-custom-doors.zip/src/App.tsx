import React, { useState, useEffect } from 'react';
import { StorefrontLayout } from './components/StorefrontLayout';
import { AdminSplitView } from './components/admin/AdminSplitView';
import { AdminMasterBar } from './components/admin/AdminMasterBar';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { QuoteModal } from './components/QuoteModal';
import { CatalogBrochureModal } from './components/CatalogBrochureModal';
import { AuthModal } from './components/AuthModal';
import { ShortlistDrawer } from './components/ShortlistDrawer';
import { SearchResultItem } from './components/HeaderSearch';
import { useStore } from './context/StoreContext';
import { useAuth } from './context/AuthContext';

export default function App() {
  const { isAdminMode, setIsAdminMode, adminDualViewMode, setAdminDualViewMode } = useStore();
  const { isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedDoorCategory, setSelectedDoorCategory] = useState<string>('All');
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState<boolean>(false);
  const [isCatalogModalOpen, setIsCatalogModalOpen] = useState<boolean>(false);
  const [quoteModalDoorType, setQuoteModalDoorType] = useState<string | undefined>(undefined);
  const [quoteModalDesignTitle, setQuoteModalDesignTitle] = useState<string | undefined>(undefined);
  const [gallerySearchQuery, setGallerySearchQuery] = useState<string>('');
  const [highlightedGalleryItem, setHighlightedGalleryItem] = useState<string | null>(null);

  // Scroll to top on active tab change and guard admin mode
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (isAdminMode && !isAdmin) {
      setIsAdminMode(false);
    }
  }, [activeTab, isAdminMode, isAdmin, setIsAdminMode]);

  const handleOpenQuote = (doorType?: string, designTitle?: string) => {
    setQuoteModalDoorType(doorType);
    setQuoteModalDesignTitle(designTitle);
    setIsQuoteModalOpen(true);
  };

  const handleSpecialtyExplore = (typeOrCategory: string, category?: string) => {
    const type = category ? typeOrCategory : (
      typeOrCategory.toLowerCase().includes('custom') ? 'custom' : 
      typeOrCategory.toLowerCase().includes('carv') ? 'carving' : 'doors'
    );
    const targetCat = category || typeOrCategory;

    if (type === 'custom' || targetCat === 'Custom Designs') {
      setActiveTab('custom-designs');
    } else if (type === 'carving' || targetCat.toLowerCase().includes('carv')) {
      setActiveTab('carving');
    } else {
      setSelectedDoorCategory(targetCat);
      setActiveTab('doors');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectSearchResult = (result: SearchResultItem) => {
    if (result.type === 'door') {
      setActiveTab('doors');
      // If door matches a category, switch to it
      if (result.category.includes('Traditional')) setSelectedDoorCategory('Traditional Doors');
      else if (result.category.includes('Carved')) setSelectedDoorCategory('Carved Doors');
      else if (result.category.includes('Entrance')) setSelectedDoorCategory('Main Entrance Doors');
      else if (result.category.includes('Temple')) setSelectedDoorCategory('Temple-Inspired Designs');
      else if (result.category.includes('Contemporary')) setSelectedDoorCategory('Contemporary Wooden Doors');
      else if (result.category.includes('Custom')) setSelectedDoorCategory('Custom Designs');
      else setSelectedDoorCategory('All');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (result.type === 'carving') {
      setActiveTab('carving');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      // Gallery item
      setHighlightedGalleryItem(result.id);
      setActiveTab('gallery');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSearchInGallery = (query: string) => {
    setGallerySearchQuery(query);
    setActiveTab('gallery');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const storefrontProps = {
    activeTab,
    setActiveTab,
    selectedDoorCategory,
    setSelectedDoorCategory,
    gallerySearchQuery,
    setGallerySearchQuery,
    highlightedGalleryItem,
    onOpenQuote: handleOpenQuote,
    onSelectSearchResult: handleSelectSearchResult,
    onSearchInGallery: handleSearchInGallery,
    onOpenAdmin: () => {
      if (isAdmin) {
        setAdminDualViewMode('split');
      } else {
        setIsAdminMode(true);
      }
    },
    onOpenCatalog: () => setIsCatalogModalOpen(true),
  };

  // 1. Dual View: Both Sides (Store Front + Admin Panel side-by-side)
  if (isAdmin && adminDualViewMode === 'split') {
    return (
      <>
        <AdminSplitView storefrontProps={storefrontProps} />

        {/* Global Modals */}
        <CatalogBrochureModal
          isOpen={isCatalogModalOpen}
          onClose={() => setIsCatalogModalOpen(false)}
          onOpenQuoteWithItem={(itemName) => handleOpenQuote('Main Entrance Door', itemName)}
        />
        <QuoteModal
          isOpen={isQuoteModalOpen}
          onClose={() => setIsQuoteModalOpen(false)}
          initialDoorType={quoteModalDoorType}
          initialDesignTitle={quoteModalDesignTitle}
        />
        <AuthModal 
          onDirectQuote={(itemTitle) => handleOpenQuote('Custom Door', itemTitle)} 
        />
        <ShortlistDrawer 
          onOpenQuoteWithItem={(itemTitle) => handleOpenQuote('Custom Door', itemTitle)} 
        />
      </>
    );
  }

  // 2. Full Admin Panel View (with Master Bar at the top)
  if (isAdmin && adminDualViewMode === 'admin') {
    return (
      <div className="min-h-screen flex flex-col bg-[#F7F4EE]">
        <AdminMasterBar />
        <AdminDashboard 
          onReturnToPublicSite={() => setAdminDualViewMode('storefront')} 
        />

        {/* Global Modals */}
        <CatalogBrochureModal
          isOpen={isCatalogModalOpen}
          onClose={() => setIsCatalogModalOpen(false)}
          onOpenQuoteWithItem={(itemName) => handleOpenQuote('Main Entrance Door', itemName)}
        />
        <QuoteModal
          isOpen={isQuoteModalOpen}
          onClose={() => setIsQuoteModalOpen(false)}
          initialDoorType={quoteModalDoorType}
          initialDesignTitle={quoteModalDesignTitle}
        />
        <AuthModal 
          onDirectQuote={(itemTitle) => handleOpenQuote('Custom Door', itemTitle)} 
        />
        <ShortlistDrawer 
          onOpenQuoteWithItem={(itemTitle) => handleOpenQuote('Custom Door', itemTitle)} 
        />
      </div>
    );
  }

  // 3. Store Front View (If logged in as admin, Master Bar is pinned at the top so they can switch anytime!)
  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#443529] flex flex-col selection:bg-[#A8763E] selection:text-white">
      {isAdmin && <AdminMasterBar />}

      <StorefrontLayout {...storefrontProps} />

      {/* Door Collections Catalog & Brochure Modal */}
      <CatalogBrochureModal
        isOpen={isCatalogModalOpen}
        onClose={() => setIsCatalogModalOpen(false)}
        onOpenQuoteWithItem={(itemName) => handleOpenQuote('Main Entrance Door', itemName)}
      />

      {/* Quote Request Modal */}
      <QuoteModal
        isOpen={isQuoteModalOpen}
        onClose={() => setIsQuoteModalOpen(false)}
        initialDoorType={quoteModalDoorType}
        initialDesignTitle={quoteModalDesignTitle}
      />

      {/* Authentication Modal */}
      <AuthModal 
        onDirectQuote={(itemTitle) => handleOpenQuote('Custom Door', itemTitle)} 
      />

      {/* Shortlist & Profile Drawer */}
      <ShortlistDrawer 
        onOpenQuoteWithItem={(itemTitle) => handleOpenQuote('Custom Door', itemTitle)} 
      />
    </div>
  );
}
